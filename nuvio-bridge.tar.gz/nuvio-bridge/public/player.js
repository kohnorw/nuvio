// The player that runs in the page.
//
// On a desktop there is nothing to hand a stream to: no browser follows a
// custom scheme into VLC, and asking someone to download a file for every
// episode is a poor trade. So the page plays it itself.
//
// A <video> element is doing the work, with its own controls — that is what
// gets fullscreen, Picture-in-Picture, AirPlay on Safari and Cast on Chrome
// for free, and it is what a screen reader and a keyboard already understand.
// Everything around it is queue, subtitles, and what to do when the file is
// something the browser can't decode.
//
// It cannot play everything. MKV — which most releases are — is refused by
// every browser except in the narrow case of H.264 in a WebM-compatible
// container. That is not a bug to work around; it is why VLC stays the
// default on phones, and why a failure here offers the file to VLC instead of
// pretending.

import { device, playLink } from './platform.js';

const $ = (s, root = document) => root.querySelector(s);

let ticket = null;
let index = 0;
let token = null;
let onExit = () => { location.href = '/'; };

export function isWatchRoute() {
  return location.pathname === '/watch';
}

export async function mount(options = {}) {
  const params = new URLSearchParams(location.search);
  token = params.get('t');
  if (options.onExit) onExit = options.onExit;
  if (!token) return fail('No playlist token in that link.');

  show();
  setStatus('Resolving streams…');

  try {
    ticket = await fetch(`/api/ticket/${encodeURIComponent(token)}`, { credentials: 'same-origin' })
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `Could not load that playlist (${res.status})`);
        return data;
      });
  } catch (err) {
    return fail(err.message);
  }

  if (!ticket.items?.length) return fail('That playlist came back empty.');

  document.title = `${ticket.title} — Nuvio`;
  $('#watch-title').textContent = ticket.title;

  if (params.get('copy') === '1') copyLink();

  renderQueue();
  await loadSubtitleMenu();
  play(0);
  return undefined;
}

function show() {
  document.body.classList.add('watching');
  $('#screen-watch').hidden = false;
}

export function unmount() {
  const video = $('#watch-video');
  video.pause();
  video.removeAttribute('src');
  video.load();
  document.body.classList.remove('watching');
  $('#screen-watch').hidden = true;
  document.title = 'Nuvio';
}

// ------------------------------------------------------------- playback

function current() {
  return ticket.items[index];
}

function play(next) {
  index = Math.max(0, Math.min(next, ticket.items.length - 1));
  const item = current();
  const video = $('#watch-video');

  $('#watch-now').textContent = item.title;
  $('#watch-position').textContent = ticket.items.length > 1
    ? `${index + 1} of ${ticket.items.length}`
    : '';
  $('#watch-fallback').hidden = true;
  setStatus('');

  // Starting again from the top of the element, so a previous file's error
  // state and buffered data don't follow this one.
  video.pause();
  video.removeAttribute('src');
  clearTracks(video);
  video.src = item.url;
  video.load();

  if (item.subtitle) addTrack(video, item.subtitle, 'Addon subtitles', true);

  const resumeAt = savedPosition();
  if (resumeAt) {
    video.addEventListener('loadedmetadata', () => { video.currentTime = resumeAt; }, { once: true });
  }

  video.play().catch(() => {
    // Autoplay with sound is blocked until the person has interacted with the
    // page. Arriving here from a tap on Play usually counts, but not always —
    // and a paused first frame with working controls is a fine outcome.
    setStatus('Press play to start.');
  });

  markQueue();
  updateNav();
}

function updateNav() {
  $('#watch-prev').disabled = index === 0;
  $('#watch-next').disabled = index >= ticket.items.length - 1;
  $('#watch-queue-wrap').hidden = ticket.items.length < 2;
}

function setStatus(text) {
  const el = $('#watch-status');
  el.textContent = text;
  el.hidden = !text;
}

function fail(message) {
  show();
  setStatus('');
  $('#watch-title').textContent = 'Nothing to play';
  $('#watch-fallback').hidden = false;
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-actions').innerHTML = '';
  return undefined;
}

// ---------------------------------------------------------------- queue

function renderQueue() {
  const list = $('#watch-queue');
  list.innerHTML = '';
  ticket.items.forEach((item, i) => {
    const row = document.createElement('button');
    row.className = 'queue-item';
    row.innerHTML = '<span class="queue-num"></span><span class="queue-title"></span>';
    row.querySelector('.queue-num').textContent = String(i + 1);
    row.querySelector('.queue-title').textContent = item.title;
    row.addEventListener('click', () => play(i));
    list.append(row);
  });
  markQueue();
}

function markQueue() {
  [...$('#watch-queue').children].forEach((row, i) => {
    row.setAttribute('aria-current', String(i === index));
  });
}

// ------------------------------------------------------------ subtitles

function clearTracks(video) {
  video.querySelectorAll('track').forEach((t) => t.remove());
}

function addTrack(video, src, label, active) {
  const track = document.createElement('track');
  track.kind = 'subtitles';
  track.label = label;
  track.src = src;
  track.default = Boolean(active);
  video.append(track);
  return track;
}

// Every subtitle the addons have for this title, not only the one a language
// preference already picked. Failing quietly is right here — subtitles are a
// nicety and the film is already playing.
async function loadSubtitleMenu() {
  const select = $('#watch-subs');
  const wrap = $('#watch-subs-wrap');
  wrap.hidden = true;

  if (!ticket.type || !ticket.id) return;

  let available = [];
  try {
    available = await fetch(
      `/api/subtitles/${encodeURIComponent(ticket.type)}/${encodeURIComponent(ticket.id)}`,
      { credentials: 'same-origin' },
    ).then((res) => (res.ok ? res.json() : []));
  } catch {
    return;
  }
  if (!available.length) return;

  select.innerHTML = '<option value="">Off</option>';
  for (const sub of available) {
    const option = document.createElement('option');
    option.value = sub.url;
    option.textContent = `${sub.label}${sub.addon ? ` · ${sub.addon}` : ''}`;
    select.append(option);
  }

  select.onchange = () => {
    const video = $('#watch-video');
    clearTracks(video);
    for (const t of video.textTracks) t.mode = 'disabled';
    if (select.value) {
      addTrack(video, select.value, select.selectedOptions[0].textContent, true);
      // A freshly appended track starts disabled in some browsers even with
      // `default` set, so say so explicitly once it exists.
      requestAnimationFrame(() => {
        const last = video.textTracks[video.textTracks.length - 1];
        if (last) last.mode = 'showing';
      });
    }
  };
  wrap.hidden = false;
}

// ------------------------------------------------------- when it can't play

// MEDIA_ERR_SRC_NOT_SUPPORTED is the codec answer; MEDIA_ERR_NETWORK covers a
// blocked mixed-content load and a host that refused us. They need different
// suggestions, so they're told apart rather than lumped into "it didn't work".
function onError() {
  const video = $('#watch-video');
  const code = video.error?.code;
  const item = current();
  const mixed = location.protocol === 'https:' && item.url.startsWith('http://');

  const message = mixed
    ? 'This page is on HTTPS and the stream is plain HTTP, so the browser blocked it.'
    : code === 4
      ? "This browser can't decode this file — MKV and some audio codecs are refused by every browser."
      : 'The stream host stopped answering.';

  showFallback(message, { offerProxy: mixed || code === 2 });
}

function showFallback(message, { offerProxy = false } = {}) {
  const panel = $('#watch-fallback');
  const actions = $('#watch-fallback-actions');
  $('#watch-fallback-message').textContent = message;
  actions.innerHTML = '';
  panel.hidden = false;

  action(actions, 'Open in VLC', () => {
    location.href = `/playlist/${token}.m3u?dl=1`;
  }, 'primary');

  if (device.os === 'android') {
    action(actions, 'Choose an app', () => {
      location.href = playLink('/play', { url: current().url, title: current().title })
        .replace(/target=[^&]*/, 'target=player-chooser');
    });
  }

  if (offerProxy && ticket.proxyAvailable && current().proxyUrl) {
    action(actions, 'Try through the server', () => {
      const video = $('#watch-video');
      video.src = current().proxyUrl;
      video.load();
      video.play().catch(() => {});
      panel.hidden = true;
    });
  } else if (offerProxy && !ticket.proxyAvailable) {
    const note = document.createElement('p');
    note.className = 'watch-note';
    note.textContent = 'Set MEDIA_PROXY=true on the server to route blocked streams through it.';
    actions.append(note);
  }

  action(actions, 'Copy stream link', copyLink);
}

function action(parent, label, handler, kind = '') {
  const button = document.createElement('button');
  button.className = kind === 'primary' ? 'btn-primary' : 'btn-ghost';
  button.textContent = label;
  button.addEventListener('click', handler);
  parent.append(button);
  return button;
}

async function copyLink() {
  const url = current()?.url;
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
    setStatus('Stream link copied. In VLC: File → Open Network Stream.');
  } catch {
    // Clipboard access needs a secure context, which a plain-http LAN address
    // is not. Showing the URL is the next best thing.
    setStatus(url);
  }
}

// ------------------------------------------------------------- positions

function savedPosition() {
  const raw = localStorage.getItem(`nuvio.pos.${token}.${index}`);
  const seconds = Number(raw);
  return Number.isFinite(seconds) && seconds > 30 ? seconds : 0;
}

function rememberPosition() {
  const video = $('#watch-video');
  if (!video.duration || video.currentTime < 30) return;
  // Near the end there is nothing worth resuming to.
  if (video.currentTime > video.duration - 60) {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    return;
  }
  localStorage.setItem(`nuvio.pos.${token}.${index}`, String(Math.floor(video.currentTime)));
}

// ------------------------------------------------------------------ wiring

export function init() {
  const video = $('#watch-video');

  video.addEventListener('error', onError);
  video.addEventListener('ended', () => {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    if (index < ticket.items.length - 1) play(index + 1);
  });

  let lastSave = 0;
  video.addEventListener('timeupdate', () => {
    if (Date.now() - lastSave < 5000) return;
    lastSave = Date.now();
    rememberPosition();
  });

  $('#watch-prev').addEventListener('click', () => play(index - 1));
  $('#watch-next').addEventListener('click', () => play(index + 1));
  $('#watch-back').addEventListener('click', () => {
    rememberPosition();
    unmount();
    onExit();
  });

  // The shortcuts anyone who has used a video player expects. They are skipped
  // while a form control has focus, so typing in the subtitle menu doesn't
  // seek the film.
  document.addEventListener('keydown', (event) => {
    if ($('#screen-watch').hidden) return;
    if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;

    const step = event.shiftKey ? 30 : 10;
    switch (event.key) {
      case ' ': case 'k':
        event.preventDefault();
        if (video.paused) video.play().catch(() => {}); else video.pause();
        break;
      case 'ArrowRight': case 'l': video.currentTime += step; break;
      case 'ArrowLeft': case 'j': video.currentTime -= step; break;
      case 'ArrowUp': video.volume = Math.min(1, video.volume + 0.1); break;
      case 'ArrowDown': video.volume = Math.max(0, video.volume - 0.1); break;
      case 'm': video.muted = !video.muted; break;
      case 'f':
        if (document.fullscreenElement) document.exitFullscreen();
        else video.requestFullscreen?.();
        break;
      case 'n': if (index < ticket.items.length - 1) play(index + 1); break;
      case 'p': if (index > 0) play(index - 1); break;
      case 'Escape':
        if (!document.fullscreenElement) $('#watch-back').click();
        break;
      default: return;
    }
  });
}
