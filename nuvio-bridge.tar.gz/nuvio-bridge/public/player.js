// The player that runs in the page.
//
// Everything goes through ffmpeg. Handing the file to the browser first and
// converting only when that fails sounds thriftier, but there is no reliable
// signal to react to. An MKV with AC3 audio plays perfectly well in Chrome
// with no sound at all and raises no error; a file extension tells you
// nothing about what is inside; and every browser draws the line in a
// different place. Guessing produced a different wrong answer per browser.
//
// Converting every time is one path that behaves the same everywhere, and for
// the usual release — H.264 video with AC3 audio — it is a rewrap that barely
// touches the CPU. It also quietly solves two other problems: the server
// fetches the stream, so a plain-HTTP link on an HTTPS page is no longer
// blocked, and a host that refuses cross-origin requests no longer matters.
//
// The output is HLS. Safari plays it natively; every other browser gets
// hls.js, which is fetched only when it is actually needed.
//
// Without ffmpeg in the build there is a direct-playback fallback, which is
// the old behaviour: MP4 plays, MKV mostly doesn't.

import { device, playLink } from './platform.js';

const $ = (s, root = document) => root.querySelector(s);

async function post(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

let ticket = null;
let index = 0;
let token = null;
let onExit = () => { location.href = '/'; };

// The live conversion, when there is one: which session, where in the film it
// began, and what is in the file. The element's own clock starts from wherever
// ffmpeg was told to begin, so the real position is offset + currentTime.
let convert = null;
let hlsEngine = null;
let heartbeatTimer = null;

export function isWatchRoute() {
  return location.pathname === '/watch';
}

export async function mount(options = {}) {
  const params = new URLSearchParams(location.search);
  token = params.get('t');
  if (options.onExit) onExit = options.onExit;
  if (!token) return fail('No playlist token in that link.');

  show();
  setStatus('Resolving streams…');

  try {
    ticket = await fetch(`/api/ticket/${encodeURIComponent(token)}`, { credentials: 'same-origin' })
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `Could not load that playlist (${res.status})`);
        return data;
      });
  } catch (err) {
    return fail(err.message);
  }

  if (!ticket.items?.length) return fail('That playlist came back empty.');

  document.title = `${ticket.title} — Nuvio`;
  $('#watch-title').textContent = ticket.title;

  if (params.get('copy') === '1') copyLink();

  renderQueue();
  await loadSubtitleMenu();
  await play(0);
  return undefined;
}

function show() {
  document.body.classList.add('watching');
  $('#screen-watch').hidden = false;
}

export function unmount() {
  endConversion();
  const video = $('#watch-video');
  video.pause();
  video.removeAttribute('src');
  video.load();
  document.body.classList.remove('watching');
  $('#screen-watch').hidden = true;
  document.title = 'Nuvio';
}

// --------------------------------------------------------------- playback

function current() {
  return ticket.items[index];
}

async function play(next) {
  index = Math.max(0, Math.min(next, ticket.items.length - 1));
  const item = current();
  const video = $('#watch-video');

  $('#watch-now').textContent = item.title;
  $('#watch-position').textContent = ticket.items.length > 1
    ? `${index + 1} of ${ticket.items.length}`
    : '';
  $('#watch-fallback').hidden = true;
  setStatus('');

  // Start from a clean element, so a previous file's error state and buffered
  // data don't follow this one.
  endConversion();
  $('#watch-audio-wrap').hidden = true;
  video.pause();
  video.removeAttribute('src');
  clearTracks(video);
  video.load();

  markQueue();
  updateNav();

  if (ticket.transcodeAvailable && item.transcodeKey) {
    await startConversion({ seek: savedPosition() });
    return;
  }
  playDirect(item);
}

// Only reached in a build without ffmpeg.
function playDirect(item) {
  const video = $('#watch-video');
  video.src = item.url;
  video.load();

  if (item.subtitle) addTrack(video, item.subtitle, 'Addon subtitles', true);
  video.addEventListener('loadedmetadata', renderAudioMenu, { once: true });

  const resumeAt = savedPosition();
  if (resumeAt) {
    video.addEventListener('loadedmetadata', () => { video.currentTime = resumeAt; }, { once: true });
  }

  video.play().catch(() => setStatus('Press play to start.'));
}

function updateNav() {
  $('#watch-prev').disabled = index === 0;
  $('#watch-next').disabled = index >= ticket.items.length - 1;
  $('#watch-queue-wrap').hidden = ticket.items.length < 2;
}

function setStatus(text) {
  const el = $('#watch-status');
  el.textContent = text;
  el.hidden = !text;
}

function fail(message) {
  show();
  setStatus('');
  $('#watch-title').textContent = 'Nothing to play';
  $('#watch-fallback').hidden = false;
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  $('#watch-fallback-actions').innerHTML = '';
  return undefined;
}

// ------------------------------------------------------------ conversion

async function startConversion({ seek = 0, audio = null } = {}) {
  const item = current();
  if (!item.transcodeKey) return;

  setStatus('Starting the conversion…');
  $('#watch-fallback').hidden = true;

  const wantedAudio = audio ?? convert?.audio ?? 0;
  const previous = convert?.sid || null;

  let session;
  try {
    session = await post('/api/transcode/start', {
      u: item.transcodeKey.u,
      s: item.transcodeKey.s,
      seek: Math.max(0, Math.floor(seek)),
      audio: wantedAudio,
      // Replacing rather than adding, so seeking or switching track doesn't
      // leave a second ffmpeg running on the same film.
      replace: previous,
    });
  } catch (err) {
    showFallback(err.message);
    return;
  }

  convert = {
    sid: session.sid,
    offset: session.offset || 0,
    duration: session.duration || null,
    tracks: session.audioTracks || [],
    audio: wantedAudio,
  };

  await attachHls(session.url);
  paintControls();
  renderAudioMenu();
  beginHeartbeat();

  setStatus(session.videoCopy === false
    ? `Re-encoding ${session.videoCodec} as it plays. A slow server may not keep up.`
    : `Rewrapping ${session.videoCodec} and converting ${session.audioCodec} audio.`);
}

// Safari plays HLS from a plain src. Everything else needs hls.js, which is
// 90 KB gzipped — worth fetching on demand rather than on every page view.
async function attachHls(url) {
  const video = $('#watch-video');
  detachHls();
  spinner(true, 'Converting…');

  if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = url;
    video.load();
    video.play().catch(() => spinner(false));
    return;
  }

  const Hls = await loadHlsLibrary();
  if (!Hls?.isSupported()) {
    spinner(false);
    showFallback('This browser cannot play converted video. Use VLC instead.');
    return;
  }

  hlsEngine = new Hls({
    lowLatencyMode: false,

    // The playlist grows while ffmpeg works and carries no closing tag until
    // the film is finished, so hls.js reasonably treats it as a live stream —
    // and a live stream is something it tries to stay at the leading edge of.
    // That edge is the encoder's output, which is precisely where playback
    // must not sit: every hiccup becomes a stall.
    startPosition: 0,
    liveSyncDurationCount: 6,
    liveMaxLatencyDurationCount: 30,

    maxBufferLength: 60,
    maxMaxBufferLength: 120,
    backBufferLength: 90,

    // A missing segment usually means "not written yet" rather than "gone".
    manifestLoadingMaxRetry: 8,
    levelLoadingMaxRetry: 8,
    fragLoadingMaxRetry: 8,
    fragLoadingRetryDelay: 500,
  });

  // Playing before the manifest has been parsed is a race: sometimes the
  // element has something to play and sometimes it sits at 0:00 with no
  // error, which looks exactly like a broken player.
  hlsEngine.on(Hls.Events.MANIFEST_PARSED, () => {
    video.play().catch(() => {
      spinner(false);
      setStatus('Press play to start.');
    });
  });

  hlsEngine.on(Hls.Events.ERROR, (event, data) => {
    if (!data.fatal) return;

    if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
      hlsEngine.startLoad();
      return;
    }
    if (data.type === Hls.ErrorTypes.MEDIA_ERROR) {
      hlsEngine.recoverMediaError();
      return;
    }
    // Anything else is not recoverable, and saying which is the difference
    // between a fixable report and "it doesn't work".
    spinner(false);
    showFallback(`Playback failed: ${data.details || data.type}. Try again, or use VLC.`);
  });

  hlsEngine.loadSource(url);
  hlsEngine.attachMedia(video);
}

function detachHls() {
  if (!hlsEngine) return;
  try { hlsEngine.destroy(); } catch { /* already gone */ }
  hlsEngine = null;
}

let hlsPromise = null;

function loadHlsLibrary() {
  if (window.Hls) return Promise.resolve(window.Hls);
  if (hlsPromise) return hlsPromise;

  hlsPromise = new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = '/vendor/hls.min.js';
    script.onload = () => resolve(window.Hls);
    script.onerror = () => resolve(null);
    document.head.append(script);
  });
  return hlsPromise;
}

// Without a beat the server assumes the tab is gone and reaps the session,
// which is what stops a closed tab leaving ffmpeg running on a film nobody
// is watching.
function beginHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => {
    if (!convert?.sid) return;
    post(`/api/transcode/heartbeat/${convert.sid}`).catch(() => {});
  }, 10000);
}

function endConversion() {
  clearInterval(heartbeatTimer);
  detachHls();
  if (convert?.sid) {
    // Best effort; the heartbeat timeout reaps it anyway.
    post(`/api/transcode/stop/${convert.sid}`).catch(() => {});
  }
  convert = null;
}

// ------------------------------------------------------------- controls
//
// One set of controls for both paths. The element's own bar can't be used,
// because a converted stream's clock starts wherever ffmpeg began rather than
// at the top of the film — so the native timeline and ours would disagree
// about the same video. Everything below works in film time and translates.

// Where we are in the film, as opposed to where the element thinks it is.
function position() {
  const video = $('#watch-video');
  return (convert?.offset || 0) + (video.currentTime || 0);
}

function duration() {
  const video = $('#watch-video');
  if (convert?.duration) return convert.duration;
  return Number.isFinite(video.duration) ? video.duration : 0;
}

function seekTo(seconds) {
  const video = $('#watch-video');
  const target = Math.max(0, Math.min(Math.floor(seconds), duration() || Infinity));

  if (!convert) {
    video.currentTime = target;
    return;
  }

  // Inside what has been converted, an ordinary seek. Past it there is
  // nothing to seek to, so the session restarts there.
  const relative = target - convert.offset;
  const { seekable } = video;
  const end = seekable?.length ? seekable.end(seekable.length - 1) : 0;

  if (relative >= 0 && relative <= end) {
    video.currentTime = relative;
    paintControls();
    return;
  }
  startConversion({ seek: target, audio: convert.audio });
}

function paintControls() {
  const video = $('#watch-video');
  const total = duration();
  const at = position();

  const seek = $('#watch-seek');
  if (document.activeElement !== seek) {
    seek.max = String(Math.max(1, Math.floor(total)));
    seek.value = String(Math.floor(at));
  }
  // Colour the part already played, so the bar reads at a glance.
  const pct = total ? Math.min(100, (at / total) * 100) : 0;
  seek.style.setProperty('--played', `${pct}%`);

  $('#watch-time').textContent = clock(at);
  $('#watch-duration').textContent = total ? clock(total) : '--:--';
  $('#watch-play').setAttribute('aria-label', video.paused ? 'Play' : 'Pause');
  $('#watch-controls').classList.toggle('is-paused', video.paused);
  $('#watch-mute').classList.toggle('is-muted', video.muted || video.volume === 0);
}

function spinner(show, label = 'Loading…') {
  $('#watch-spinner').hidden = !show;
  $('#watch-spinner-label').textContent = label;
}

function togglePlay() {
  const video = $('#watch-video');
  if (video.paused) video.play().catch(() => {});
  else video.pause();
}

function clock(seconds) {
  const total = Math.max(0, Math.floor(seconds));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

// ----------------------------------------------------------------- queue

function renderQueue() {
  const list = $('#watch-queue');
  list.innerHTML = '';
  ticket.items.forEach((item, i) => {
    const row = document.createElement('button');
    row.className = 'queue-item';
    row.innerHTML = '<span class="queue-num"></span><span class="queue-title"></span>';
    row.querySelector('.queue-num').textContent = String(i + 1);
    row.querySelector('.queue-title').textContent = item.title;
    row.addEventListener('click', () => play(i));
    list.append(row);
  });
  markQueue();
}

function markQueue() {
  [...$('#watch-queue').children].forEach((row, i) => {
    row.setAttribute('aria-current', String(i === index));
  });
}

// ----------------------------------------------------------- audio tracks

// While converting, ffmpeg is told which stream to map, so any track in the
// file can be chosen. Playing directly, only Safari implements
// HTMLMediaElement.audioTracks — where it doesn't exist there is nothing to
// offer, and the menu stays hidden rather than showing something that does
// nothing.
function renderAudioMenu() {
  const wrap = $('#watch-audio-wrap');
  const select = $('#watch-audio');
  const video = $('#watch-video');
  select.innerHTML = '';

  if (convert?.tracks?.length > 1) {
    for (const track of convert.tracks) {
      const option = document.createElement('option');
      option.value = String(track.index);
      option.textContent = track.label;
      select.append(option);
    }
    select.value = String(convert.audio);
    select.onchange = () => {
      // A new track means a new ffmpeg process, so carry on from where this
      // one had got to rather than starting the film again.
      startConversion({ seek: position(), audio: Number(select.value) });
    };
    wrap.hidden = false;
    return;
  }

  const native = video.audioTracks;
  if (native && native.length > 1) {
    for (let i = 0; i < native.length; i += 1) {
      const option = document.createElement('option');
      option.value = String(i);
      option.textContent = native[i].label || native[i].language?.toUpperCase() || `Track ${i + 1}`;
      if (native[i].enabled) select.value = String(i);
      select.append(option);
    }
    select.onchange = () => {
      for (let i = 0; i < native.length; i += 1) native[i].enabled = String(i) === select.value;
    };
    wrap.hidden = false;
    return;
  }

  wrap.hidden = true;
}

// -------------------------------------------------------------- subtitles

function clearTracks(video) {
  video.querySelectorAll('track').forEach((t) => t.remove());
}

function addTrack(video, src, label, active) {
  const track = document.createElement('track');
  track.kind = 'subtitles';
  track.label = label;
  track.src = src;
  track.default = Boolean(active);
  video.append(track);
  return track;
}

// Every subtitle the addons have for this title. Failing quietly is right —
// subtitles are a nicety and the film is already playing.
async function loadSubtitleMenu() {
  const select = $('#watch-subs');
  const wrap = $('#watch-subs-wrap');
  wrap.hidden = true;

  if (!ticket.type || !ticket.id) return;

  let available = [];
  try {
    available = await fetch(
      `/api/subtitles/${encodeURIComponent(ticket.type)}/${encodeURIComponent(ticket.id)}`,
      { credentials: 'same-origin' },
    ).then((res) => (res.ok ? res.json() : []));
  } catch {
    return;
  }
  if (!available.length) return;

  select.innerHTML = '<option value="">Off</option>';
  for (const sub of available) {
    const option = document.createElement('option');
    option.value = sub.url;
    option.textContent = `${sub.label}${sub.addon ? ` · ${sub.addon}` : ''}`;
    select.append(option);
  }

  select.onchange = () => {
    const video = $('#watch-video');
    clearTracks(video);
    for (const t of video.textTracks) t.mode = 'disabled';
    if (!select.value) return;

    addTrack(video, select.value, select.selectedOptions[0].textContent, true);
    // A freshly appended track starts disabled in some browsers even with
    // `default` set, so say so explicitly once it exists.
    requestAnimationFrame(() => {
      const last = video.textTracks[video.textTracks.length - 1];
      if (last) last.mode = 'showing';
    });
  };
  wrap.hidden = false;
}

// --------------------------------------------------------- when it fails

function showFallback(message) {
  const panel = $('#watch-fallback');
  const actions = $('#watch-fallback-actions');
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  actions.innerHTML = '';
  panel.hidden = false;
  setStatus('');

  action(actions, 'Try again', () => {
    if (ticket.transcodeAvailable && current().transcodeKey) {
      startConversion({ seek: convert?.offset || 0 });
    } else {
      play(index);
    }
  }, 'primary');

  action(actions, 'Open in VLC', () => {
    location.href = `/playlist/${token}.m3u?dl=1`;
  });

  if (device.os === 'android') {
    action(actions, 'Choose an app', () => {
      location.href = playLink('/play', { url: current().url, title: current().title })
        .replace(/target=[^&]*/, 'target=player-chooser');
    });
  }

  action(actions, 'Copy stream link', copyLink);
}

function action(parent, label, handler, kind = '') {
  const button = document.createElement('button');
  button.className = kind === 'primary' ? 'btn-primary' : 'btn-ghost';
  button.textContent = label;
  button.addEventListener('click', handler);
  parent.append(button);
  return button;
}

async function copyLink() {
  const url = current()?.url;
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
    setStatus('Stream link copied. In VLC: File → Open Network Stream.');
  } catch {
    // Clipboard access needs a secure context, which a plain-http LAN address
    // is not. Showing the URL is the next best thing.
    setStatus(url);
  }
}

// ------------------------------------------------------------- positions

function savedPosition() {
  const raw = localStorage.getItem(`nuvio.pos.${token}.${index}`);
  const seconds = Number(raw);
  return Number.isFinite(seconds) && seconds > 30 ? seconds : 0;
}

function rememberPosition() {
  const video = $('#watch-video');

  if (convert) {
    const at = position();
    if (at > 30) localStorage.setItem(`nuvio.pos.${token}.${index}`, String(Math.floor(at)));
    return;
  }

  if (!video.duration || video.currentTime < 30) return;
  if (video.currentTime > video.duration - 60) {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    return;
  }
  localStorage.setItem(`nuvio.pos.${token}.${index}`, String(Math.floor(video.currentTime)));
}

// ------------------------------------------------------------------ wiring

export function init() {
  const video = $('#watch-video');

  // Controls -----------------------------------------------------------
  $('#watch-play').addEventListener('click', togglePlay);
  $('#watch-tap').addEventListener('click', togglePlay);

  const seek = $('#watch-seek');
  seek.addEventListener('input', () => {
    $('#watch-time').textContent = clock(Number(seek.value));
    seek.style.setProperty('--played', `${(Number(seek.value) / Number(seek.max)) * 100}%`);
  });
  seek.addEventListener('change', () => seekTo(Number(seek.value)));

  $('#watch-mute').addEventListener('click', () => {
    video.muted = !video.muted;
    paintControls();
  });

  const volume = $('#watch-volume');
  volume.addEventListener('input', () => {
    video.volume = Number(volume.value);
    video.muted = Number(volume.value) === 0;
    paintControls();
  });

  $('#watch-full').addEventListener('click', () => {
    const stage = video.closest('.watch-stage');
    if (document.fullscreenElement) document.exitFullscreen();
    else stage.requestFullscreen?.();
  });

  if (document.pictureInPictureEnabled) {
    const pip = $('#watch-pip');
    pip.hidden = false;
    pip.addEventListener('click', () => {
      if (document.pictureInPictureElement) document.exitPictureInPicture();
      else video.requestPictureInPicture?.().catch(() => {});
    });
  }

  // The element drives the bar, so it stays right however playback changes.
  for (const event of ['play', 'pause', 'volumechange', 'durationchange', 'loadedmetadata', 'seeked']) {
    video.addEventListener(event, paintControls);
  }
  video.addEventListener('waiting', () => spinner(true, convert ? 'Converting…' : 'Buffering…'));
  video.addEventListener('playing', () => { spinner(false); setStatus(''); paintControls(); });
  video.addEventListener('canplay', () => spinner(false));

  video.addEventListener('error', () => {
    // With conversion on, hls.js reports its own errors and this fires only
    // for the direct path.
    if (convert) return;
    showFallback("This browser can't play this file, and ffmpeg isn't in this build.");
  });

  video.addEventListener('ended', () => {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    if (index < ticket.items.length - 1) play(index + 1);
  });

  let lastSave = 0;
  video.addEventListener('timeupdate', () => {
    paintControls();
    spinner(false);
    if (Date.now() - lastSave < 5000) return;
    lastSave = Date.now();
    rememberPosition();
  });

  $('#watch-prev').addEventListener('click', () => play(index - 1));
  $('#watch-next').addEventListener('click', () => play(index + 1));
  $('#watch-back').addEventListener('click', () => {
    rememberPosition();
    unmount();
    onExit();
  });

  // A closed tab or a reload should take its ffmpeg with it rather than
  // waiting for the heartbeat to time out.
  window.addEventListener('pagehide', () => {
    if (convert?.sid) navigator.sendBeacon?.(`/api/transcode/stop/${convert.sid}`);
  });

  // The shortcuts anyone who has used a video player expects. Skipped while a
  // form control has focus, so typing in a menu doesn't seek the film.
  document.addEventListener('keydown', (event) => {
    if ($('#screen-watch').hidden) return;
    if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;

    const step = event.shiftKey ? 30 : 10;
    switch (event.key) {
      case ' ': case 'k':
        event.preventDefault();
        if (video.paused) video.play().catch(() => {}); else video.pause();
        break;
      case 'ArrowRight': case 'l':
        seekTo(position() + step);
        break;
      case 'ArrowLeft': case 'j':
        seekTo(position() - step);
        break;
      case 'ArrowUp': video.volume = Math.min(1, video.volume + 0.1); break;
      case 'ArrowDown': video.volume = Math.max(0, video.volume - 0.1); break;
      case 'm': video.muted = !video.muted; break;
      case 'f':
        if (document.fullscreenElement) document.exitFullscreen();
        else video.requestFullscreen?.();
        break;
      case 'n': if (index < ticket.items.length - 1) play(index + 1); break;
      case 'p': if (index > 0) play(index - 1); break;
      case 'Escape':
        if (!document.fullscreenElement) $('#watch-back').click();
        break;
      default: return;
    }
  });
}
