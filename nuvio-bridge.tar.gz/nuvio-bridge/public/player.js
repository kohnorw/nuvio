// The player that runs in the page.
//
// On a desktop there is nothing to hand a stream to: no browser follows a
// custom scheme into VLC, and asking someone to download a file for every
// episode is a poor trade. So the page plays it itself.
//
// A <video> element is doing the work, with its own controls — that is what
// gets fullscreen, Picture-in-Picture, AirPlay on Safari and Cast on Chrome
// for free, and it is what a screen reader and a keyboard already understand.
// Everything around it is queue, subtitles, and what to do when the file is
// something the browser can't decode.
//
// It cannot play everything. MKV — which most releases are — is refused by
// every browser except in the narrow case of H.264 in a WebM-compatible
// container. That is not a bug to work around; it is why VLC stays the
// default on phones, and why a failure here offers the file to VLC instead of
// pretending.

import { device, playLink } from './platform.js';

const $ = (s, root = document) => root.querySelector(s);

async function post(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

let ticket = null;
let index = 0;
let token = null;

// Set while playing converted video. ffmpeg is fed down a pipe, so the
// response has no length and no byte ranges — the browser therefore shows no
// duration and refuses to seek. `offset` is where the current ffmpeg process
// was told to start, and every seek restarts it somewhere else, so the real
// position is always offset + whatever the element thinks its time is.
let convert = null;
let onExit = () => { location.href = '/'; };

export function isWatchRoute() {
  return location.pathname === '/watch';
}

export async function mount(options = {}) {
  const params = new URLSearchParams(location.search);
  token = params.get('t');
  if (options.onExit) onExit = options.onExit;
  if (!token) return fail('No playlist token in that link.');

  show();
  setStatus('Resolving streams…');

  try {
    ticket = await fetch(`/api/ticket/${encodeURIComponent(token)}`, { credentials: 'same-origin' })
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `Could not load that playlist (${res.status})`);
        return data;
      });
  } catch (err) {
    return fail(err.message);
  }

  if (!ticket.items?.length) return fail('That playlist came back empty.');

  document.title = `${ticket.title} — Nuvio`;
  $('#watch-title').textContent = ticket.title;

  if (params.get('copy') === '1') copyLink();

  renderQueue();
  await loadSubtitleMenu();
  play(0);
  return undefined;
}

function show() {
  document.body.classList.add('watching');
  $('#screen-watch').hidden = false;
}

export function unmount() {
  endConversion();
  const video = $('#watch-video');
  video.pause();
  video.removeAttribute('src');
  video.load();
  document.body.classList.remove('watching');
  $('#screen-watch').hidden = true;
  document.title = 'Nuvio';
}

// ------------------------------------------------------------- playback

function current() {
  return ticket.items[index];
}

// ---------------------------------------------------------- audio tracks

// Two different mechanisms, because a browser gives almost nothing here.
//
//   Converted   ffmpeg is told which stream to map, so any track in the file
//               can be chosen — and the choice restarts it, like a seek.
//   Direct      only Safari implements HTMLMediaElement.audioTracks. Where it
//               exists the menu uses it; where it doesn't there is nothing to
//               offer, and the menu stays hidden rather than lying.
function renderAudioMenu() {
  const wrap = $('#watch-audio-wrap');
  const select = $('#watch-audio');
  const video = $('#watch-video');
  select.innerHTML = '';

  if (convert?.tracks?.length > 1) {
    for (const track of convert.tracks) {
      const option = document.createElement('option');
      option.value = String(track.index);
      option.textContent = track.label;
      select.append(option);
    }
    select.value = String(convert.audio);
    select.onchange = () => {
      // A new track means a new ffmpeg process, so carry on from where this
      // one had got to rather than starting the film again.
      startConversion(convert.details, {
        seek: convertedPosition(),
        audio: Number(select.value),
      });
    };
    wrap.hidden = false;
    return;
  }

  const native = video.audioTracks;
  if (native && native.length > 1) {
    for (let i = 0; i < native.length; i += 1) {
      const option = document.createElement('option');
      option.value = String(i);
      option.textContent = native[i].label || native[i].language?.toUpperCase() || `Track ${i + 1}`;
      if (native[i].enabled) select.value = String(i);
      select.append(option);
    }
    select.onchange = () => {
      for (let i = 0; i < native.length; i += 1) native[i].enabled = String(i) === select.value;
    };
    wrap.hidden = false;
    return;
  }

  wrap.hidden = true;
}

function play(next) {
  index = Math.max(0, Math.min(next, ticket.items.length - 1));
  const item = current();
  const video = $('#watch-video');

  $('#watch-now').textContent = item.title;
  $('#watch-position').textContent = ticket.items.length > 1
    ? `${index + 1} of ${ticket.items.length}`
    : '';
  $('#watch-fallback').hidden = true;
  setStatus('');

  // Starting again from the top of the element, so a previous file's error
  // state and buffered data don't follow this one.
  endConversion();
  $('#watch-audio-wrap').hidden = true;

  video.pause();
  video.removeAttribute('src');
  clearTracks(video);
  video.src = item.url;
  video.load();

  if (item.subtitle) addTrack(video, item.subtitle, 'Addon subtitles', true);

  // Safari populates audioTracks once it has read the file.
  video.addEventListener('loadedmetadata', renderAudioMenu, { once: true });

  const resumeAt = savedPosition();
  if (resumeAt) {
    video.addEventListener('loadedmetadata', () => { video.currentTime = resumeAt; }, { once: true });
  }

  video.play().catch(() => {
    // Autoplay with sound is blocked until the person has interacted with the
    // page. Arriving here from a tap on Play usually counts, but not always —
    // and a paused first frame with working controls is a fine outcome.
    setStatus('Press play to start.');
  });

  markQueue();
  updateNav();
}

function updateNav() {
  $('#watch-prev').disabled = index === 0;
  $('#watch-next').disabled = index >= ticket.items.length - 1;
  $('#watch-queue-wrap').hidden = ticket.items.length < 2;
}

function setStatus(text) {
  const el = $('#watch-status');
  el.textContent = text;
  el.hidden = !text;
}

function fail(message) {
  show();
  setStatus('');
  $('#watch-title').textContent = 'Nothing to play';
  $('#watch-fallback').hidden = false;
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-actions').innerHTML = '';
  return undefined;
}

// ---------------------------------------------------------------- queue

function renderQueue() {
  const list = $('#watch-queue');
  list.innerHTML = '';
  ticket.items.forEach((item, i) => {
    const row = document.createElement('button');
    row.className = 'queue-item';
    row.innerHTML = '<span class="queue-num"></span><span class="queue-title"></span>';
    row.querySelector('.queue-num').textContent = String(i + 1);
    row.querySelector('.queue-title').textContent = item.title;
    row.addEventListener('click', () => play(i));
    list.append(row);
  });
  markQueue();
}

function markQueue() {
  [...$('#watch-queue').children].forEach((row, i) => {
    row.setAttribute('aria-current', String(i === index));
  });
}

// ------------------------------------------------------------ subtitles

function clearTracks(video) {
  video.querySelectorAll('track').forEach((t) => t.remove());
}

function addTrack(video, src, label, active) {
  const track = document.createElement('track');
  track.kind = 'subtitles';
  track.label = label;
  track.src = src;
  track.default = Boolean(active);
  video.append(track);
  return track;
}

// Every subtitle the addons have for this title, not only the one a language
// preference already picked. Failing quietly is right here — subtitles are a
// nicety and the film is already playing.
async function loadSubtitleMenu() {
  const select = $('#watch-subs');
  const wrap = $('#watch-subs-wrap');
  wrap.hidden = true;

  if (!ticket.type || !ticket.id) return;

  let available = [];
  try {
    available = await fetch(
      `/api/subtitles/${encodeURIComponent(ticket.type)}/${encodeURIComponent(ticket.id)}`,
      { credentials: 'same-origin' },
    ).then((res) => (res.ok ? res.json() : []));
  } catch {
    return;
  }
  if (!available.length) return;

  select.innerHTML = '<option value="">Off</option>';
  for (const sub of available) {
    const option = document.createElement('option');
    option.value = sub.url;
    option.textContent = `${sub.label}${sub.addon ? ` · ${sub.addon}` : ''}`;
    select.append(option);
  }

  select.onchange = () => {
    const video = $('#watch-video');
    clearTracks(video);
    for (const t of video.textTracks) t.mode = 'disabled';
    if (select.value) {
      addTrack(video, select.value, select.selectedOptions[0].textContent, true);
      // A freshly appended track starts disabled in some browsers even with
      // `default` set, so say so explicitly once it exists.
      requestAnimationFrame(() => {
        const last = video.textTracks[video.textTracks.length - 1];
        if (last) last.mode = 'showing';
      });
    }
  };
  wrap.hidden = false;
}

// ------------------------------------------------------- when it can't play

// MEDIA_ERR_SRC_NOT_SUPPORTED is the codec answer; MEDIA_ERR_NETWORK covers a
// blocked mixed-content load and a host that refused us. They need different
// suggestions, so they're told apart rather than lumped into "it didn't work".
function onError() {
  const video = $('#watch-video');
  const code = video.error?.code;
  const item = current();
  const mixed = location.protocol === 'https:' && item.url.startsWith('http://');

  const message = mixed
    ? 'This page is on HTTPS and the stream is plain HTTP, so the browser blocked it.'
    : code === 4
      ? "This browser can't decode this file — MKV and some audio codecs are refused by every browser."
      : 'The stream host stopped answering.';

  showFallback(message, { offerProxy: mixed || code === 2 });
}

function showFallback(message, { offerProxy = false } = {}) {
  const panel = $('#watch-fallback');
  const actions = $('#watch-fallback-actions');
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  actions.innerHTML = '';
  panel.hidden = false;

  // Converting is offered first when it's available, because it keeps the
  // person where they are rather than sending them to another app.
  if (ticket.transcodeAvailable && current().transcodeKey) {
    const button = action(actions, 'Convert and play here', async () => {
      button.disabled = true;
      button.textContent = 'Checking the file…';
      const details = await describeConversion();
      button.disabled = false;
      button.textContent = 'Convert and play here';

      const note = $('#watch-fallback-note');
      note.textContent = conversionSummary(details);
      note.hidden = false;
      // A second press starts it, so the cost is read before it is paid.
      button.onclick = () => startConversion(details);
    }, 'primary');
  }

  action(actions, 'Open in VLC', () => {
    location.href = `/playlist/${token}.m3u?dl=1`;
  }, ticket.transcodeAvailable ? '' : 'primary');

  if (device.os === 'android') {
    action(actions, 'Choose an app', () => {
      location.href = playLink('/play', { url: current().url, title: current().title })
        .replace(/target=[^&]*/, 'target=player-chooser');
    });
  }

  if (offerProxy && ticket.proxyAvailable && current().proxyUrl) {
    action(actions, 'Try through the server', () => {
      const video = $('#watch-video');
      video.src = current().proxyUrl;
      video.load();
      video.play().catch(() => {});
      panel.hidden = true;
    });
  } else if (offerProxy && !ticket.proxyAvailable) {
    const note = document.createElement('p');
    note.className = 'watch-note';
    note.textContent = 'Set MEDIA_PROXY=true on the server to route blocked streams through it.';
    actions.append(note);
  }

  action(actions, 'Copy stream link', copyLink);
}

function action(parent, label, handler, kind = '') {
  const button = document.createElement('button');
  button.className = kind === 'primary' ? 'btn-primary' : 'btn-ghost';
  button.textContent = label;
  button.addEventListener('click', handler);
  parent.append(button);
  return button;
}

async function copyLink() {
  const url = current()?.url;
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
    setStatus('Stream link copied. In VLC: File → Open Network Stream.');
  } catch {
    // Clipboard access needs a secure context, which a plain-http LAN address
    // is not. Showing the URL is the next best thing.
    setStatus(url);
  }
}

// ---------------------------------------------------------- conversion

// Converted playback is HLS, not a plain file, so three things differ from
// normal playback and all three are handled here:
//
//   Attaching   Safari plays HLS natively; everything else needs hls.js,
//               which is fetched only if this is actually used.
//   Time        the session may have started partway into the film, so the
//               element's clock is offset from the real position.
//   Seeking     inside what has been converted, the browser seeks normally.
//               Past it, there is nothing to seek to, so the session is
//               restarted at that point instead.

let hlsEngine = null;
let heartbeatTimer = null;

async function describeConversion() {
  const item = current();
  if (!item.transcodeKey) return null;

  const { u, s } = item.transcodeKey;
  try {
    return await fetch(`/api/transcode/inspect?u=${encodeURIComponent(u)}&s=${encodeURIComponent(s)}`,
      { credentials: 'same-origin' })
      .then((res) => (res.ok ? res.json() : null));
  } catch {
    return null;
  }
}

function conversionSummary(details) {
  if (!details) return 'Convert it as it plays.';
  if (details.videoCopy) {
    return `Video is ${details.videoCodec} and can be rewrapped as-is; only the ${details.audioCodec} audio needs converting. This is cheap.`;
  }
  return `Video is ${details.videoCodec}, which has to be re-encoded to H.264. That is CPU-heavy and a slow server may not keep up.`;
}

async function startConversion(details, { seek = 0, audio = null } = {}) {
  const item = current();
  if (!item.transcodeKey) return;

  setStatus('Starting the conversion…');
  $('#watch-fallback').hidden = true;

  const previous = convert?.sid || null;

  let session;
  try {
    session = await post('/api/transcode/start', {
      u: item.transcodeKey.u,
      s: item.transcodeKey.s,
      seek: Math.max(0, Math.floor(seek)),
      audio: audio ?? convert?.audio ?? defaultAudioTrack(details),
      // Replacing rather than adding, so seeking doesn't leave a second
      // ffmpeg running on the same film.
      replace: previous,
    });
  } catch (err) {
    showFallback(err.message, {});
    return;
  }

  convert = {
    sid: session.sid,
    offset: session.offset || 0,
    duration: session.duration || details?.duration || null,
    tracks: session.audioTracks || [],
    audio: audio ?? convert?.audio ?? defaultAudioTrack(details),
    details,
  };

  await attachHls(session.url);
  renderConvertBar();
  renderAudioMenu();
  beginHeartbeat();

  setStatus(session.videoCopy === false
    ? 'Re-encoding as it plays. A slow server may not keep up.'
    : 'Converting as it plays.');
}

function defaultAudioTrack(details) {
  const index = (details?.audioTracks || []).findIndex((t) => t.default);
  return index < 0 ? 0 : index;
}

// Safari plays HLS from a plain src. Everything else needs hls.js, which is
// 90 KB gzipped — worth loading on demand rather than on every page view for
// a feature most playbacks never touch.
async function attachHls(url) {
  const video = $('#watch-video');
  detachHls();

  if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = url;
    video.load();
    video.play().catch(() => setStatus('Press play to start.'));
    return;
  }

  const Hls = await loadHlsLibrary();
  if (!Hls?.isSupported()) {
    showFallback('This browser cannot play converted video. Use VLC instead.', {});
    return;
  }

  hlsEngine = new Hls({
    // The playlist grows as ffmpeg works, so it has to be re-read rather than
    // cached, and a missing segment usually means "not written yet".
    lowLatencyMode: false,
    manifestLoadingMaxRetry: 6,
    levelLoadingMaxRetry: 6,
    fragLoadingMaxRetry: 6,
  });

  hlsEngine.on(Hls.Events.ERROR, (event, data) => {
    if (!data.fatal) return;
    if (data.type === Hls.ErrorTypes.NETWORK_ERROR) hlsEngine.startLoad();
    else if (data.type === Hls.ErrorTypes.MEDIA_ERROR) hlsEngine.recoverMediaError();
    else showFallback('The conversion stopped. Try again, or use VLC.', {});
  });

  hlsEngine.loadSource(url);
  hlsEngine.attachMedia(video);
  video.play().catch(() => setStatus('Press play to start.'));
}

function detachHls() {
  if (!hlsEngine) return;
  try { hlsEngine.destroy(); } catch { /* already gone */ }
  hlsEngine = null;
}

let hlsPromise = null;

function loadHlsLibrary() {
  if (window.Hls) return Promise.resolve(window.Hls);
  if (hlsPromise) return hlsPromise;

  hlsPromise = new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = '/vendor/hls.min.js';
    script.onload = () => resolve(window.Hls);
    script.onerror = () => resolve(null);
    document.head.append(script);
  });
  return hlsPromise;
}

// Without a beat the server assumes the tab is gone and reaps the session —
// which is what stops a closed tab leaving ffmpeg running on a film nobody
// is watching.
function beginHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => {
    if (!convert?.sid) return;
    post(`/api/transcode/heartbeat/${convert.sid}`).catch(() => {});
  }, 10000);
}

function endConversion() {
  clearInterval(heartbeatTimer);
  detachHls();
  if (convert?.sid) {
    // Best effort: the heartbeat timeout will reap it anyway.
    post(`/api/transcode/stop/${convert.sid}`).catch(() => {});
  }
  convert = null;
  $('#watch-convert').hidden = true;
}

// Where we actually are in the film, as opposed to where the element thinks
// it is — the session may have begun partway in.
function convertedPosition() {
  const video = $('#watch-video');
  return (convert?.offset || 0) + (video.currentTime || 0);
}

// Inside what has been converted, an ordinary seek. Past it, the session is
// restarted there, because there is nothing yet to seek to.
async function seekConverted(seconds) {
  const video = $('#watch-video');
  const target = Math.max(0, Math.floor(seconds));
  const relative = target - convert.offset;

  const seekable = video.seekable;
  const end = seekable?.length ? seekable.end(seekable.length - 1) : 0;

  if (relative >= 0 && relative <= end) {
    video.currentTime = relative;
    updateConvertTime();
    return;
  }
  await startConversion(convert.details, { seek: target, audio: convert.audio });
}

// The element only knows about the part of the film that has been converted,
// so the timeline is drawn from ffprobe's duration instead.
function renderConvertBar() {
  const bar = $('#watch-convert');
  const slider = $('#watch-seek');
  bar.hidden = false;

  if (!convert.duration) {
    slider.hidden = true;
    $('#watch-seek-time').textContent = 'Seeking unavailable — unknown length';
    return;
  }

  slider.hidden = false;
  slider.max = String(convert.duration);
  slider.value = String(Math.floor(convertedPosition()));
  slider.onchange = () => seekConverted(Number(slider.value));
  updateConvertTime();
}

function updateConvertTime() {
  if (!convert) return;
  const position = convertedPosition();
  const slider = $('#watch-seek');
  if (!slider.hidden && document.activeElement !== slider) {
    slider.value = String(Math.floor(position));
  }
  $('#watch-seek-time').textContent = convert.duration
    ? `${clock(position)} / ${clock(convert.duration)}`
    : clock(position);
}

function clock(seconds) {
  const total = Math.max(0, Math.floor(seconds));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

// ------------------------------------------------------------- positions

function savedPosition() {
  const raw = localStorage.getItem(`nuvio.pos.${token}.${index}`);
  const seconds = Number(raw);
  return Number.isFinite(seconds) && seconds > 30 ? seconds : 0;
}

function rememberPosition() {
  const video = $('#watch-video');

  // While converting, the element's clock starts from wherever ffmpeg was
  // told to begin, so the real position is that offset plus this.
  if (convert) {
    const position = convertedPosition();
    if (position > 30) localStorage.setItem(`nuvio.pos.${token}.${index}`, String(Math.floor(position)));
    return;
  }

  if (!video.duration || video.currentTime < 30) return;
  // Near the end there is nothing worth resuming to.
  if (video.currentTime > video.duration - 60) {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    return;
  }
  localStorage.setItem(`nuvio.pos.${token}.${index}`, String(Math.floor(video.currentTime)));
}

// ------------------------------------------------------------------ wiring

export function init() {
  const video = $('#watch-video');

  video.addEventListener('error', onError);
  video.addEventListener('ended', () => {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    if (index < ticket.items.length - 1) play(index + 1);
  });

  let lastSave = 0;
  video.addEventListener('timeupdate', () => {
    if (convert) updateConvertTime();
    if (Date.now() - lastSave < 5000) return;
    lastSave = Date.now();
    rememberPosition();
  });

  $('#watch-prev').addEventListener('click', () => play(index - 1));
  $('#watch-next').addEventListener('click', () => play(index + 1));
  $('#watch-back').addEventListener('click', () => {
    rememberPosition();
    unmount();
    onExit();
  });

  // The shortcuts anyone who has used a video player expects. They are skipped
  // while a form control has focus, so typing in the subtitle menu doesn't
  // seek the film.
  // A closed tab or a reload should take its ffmpeg with it rather than
  // waiting for the heartbeat to time out.
  window.addEventListener('pagehide', () => {
    if (convert?.sid) navigator.sendBeacon?.(`/api/transcode/stop/${convert.sid}`);
  });

  document.addEventListener('keydown', (event) => {
    if ($('#screen-watch').hidden) return;
    if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;

    const step = event.shiftKey ? 30 : 10;
    switch (event.key) {
      case ' ': case 'k':
        event.preventDefault();
        if (video.paused) video.play().catch(() => {}); else video.pause();
        break;
      case 'ArrowRight': case 'l':
        if (convert) seekConverted(convertedPosition() + step);
        else video.currentTime += step;
        break;
      case 'ArrowLeft': case 'j':
        if (convert) seekConverted(convertedPosition() - step);
        else video.currentTime -= step;
        break;
      case 'ArrowUp': video.volume = Math.min(1, video.volume + 0.1); break;
      case 'ArrowDown': video.volume = Math.max(0, video.volume - 0.1); break;
      case 'm': video.muted = !video.muted; break;
      case 'f':
        if (document.fullscreenElement) document.exitFullscreen();
        else video.requestFullscreen?.();
        break;
      case 'n': if (index < ticket.items.length - 1) play(index + 1); break;
      case 'p': if (index > 0) play(index - 1); break;
      case 'Escape':
        if (!document.fullscreenElement) $('#watch-back').click();
        break;
      default: return;
    }
  });
}
