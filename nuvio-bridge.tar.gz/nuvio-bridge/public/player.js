// The player that runs in the page, on Video.js.
//
// Video.js owns the element outright: the controls, the timeline, and the HLS
// engine (VHS) that reads the playlist ffmpeg is writing. The hand-rolled bar
// this replaces had to translate between two clocks — the film's and the one
// the element reports — and got it wrong, which is how a working stream came
// to sit at 0:00. Giving one library the whole job removes that seam.
//
// What still belongs to us is what Video.js can't know about: the queue, the
// audio tracks ffmpeg maps, the subtitles the addons supply, and the
// conversion session's heartbeat.
//
// How a file reaches the player is decided server-side and comes back as a
// mode:
//
//   direct   an MP4 of H.264 and AAC, restreamed whole. Native seeking
//            anywhere in it, no ffmpeg, no segments.
//   hls      everything else — remuxed, or re-encoded when the codecs demand
//            it — served as a growing HLS playlist.
//
// One deliberate simplification: a conversion always starts at the beginning
// of the film. Restarting ffmpeg at an offset to serve a far-ahead seek meant
// the player's clock no longer matched the film's, and that mismatch caused
// more trouble than the seeking was worth.

import { device, playLink } from './platform.js';

const $ = (s, root = document) => root.querySelector(s);

async function post(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

let ticket = null;
let index = 0;
let token = null;
let onExit = () => { location.href = '/'; };

let player = null;
let convert = null;
let heartbeatTimer = null;

// What has happened, for when playback fails without raising anything.
const trace = [];

function note(what) {
  trace.push(`${String(Math.round(performance.now() / 100) / 10).padStart(6)}s  ${what}`);
  if (trace.length > 40) trace.shift();
}

export function isWatchRoute() {
  return location.pathname === '/watch';
}

// ------------------------------------------------------------------ mount

export async function mount(options = {}) {
  const params = new URLSearchParams(location.search);
  token = params.get('t');
  if (options.onExit) onExit = options.onExit;
  if (!token) return fail('No playlist token in that link.');

  show();
  setStatus('Resolving streams…');

  try {
    ticket = await fetch(`/api/ticket/${encodeURIComponent(token)}`, { credentials: 'same-origin' })
      .then(async (res) => {
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.error || `Could not load that playlist (${res.status})`);
        return data;
      });
  } catch (err) {
    return fail(err.message);
  }

  if (!ticket.items?.length) return fail('That playlist came back empty.');

  document.title = `${ticket.title} — Nuvio`;
  $('#watch-title').textContent = ticket.title;
  if (params.get('copy') === '1') copyLink();

  const ready = await createPlayer();
  if (!ready) return fail('The player library could not be loaded.');

  renderQueue();
  await loadSubtitleMenu();
  await play(0);
  return undefined;
}

function show() {
  document.body.classList.add('watching');
  $('#screen-watch').hidden = false;
}

export function unmount() {
  endConversion();
  if (player) {
    try { player.dispose(); } catch { /* already gone */ }
    player = null;
  }
  document.body.classList.remove('watching');
  $('#screen-watch').hidden = true;
  document.title = 'Nuvio';
}

// ------------------------------------------------------------ the library

let libraryPromise = null;

function loadVideoJs() {
  if (window.videojs) return Promise.resolve(window.videojs);
  if (libraryPromise) return libraryPromise;

  libraryPromise = new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = '/vendor/video.min.js';
    script.onload = () => resolve(window.videojs);
    script.onerror = () => resolve(null);
    document.head.append(script);
  });
  return libraryPromise;
}

async function createPlayer() {
  const videojs = await loadVideoJs();
  if (!videojs) return false;

  player = videojs($('#watch-video'), {
    controls: true,
    preload: 'auto',
    fluid: true,
    playsinline: true,
    playbackRates: [0.75, 1, 1.25, 1.5, 2],
    html5: {
      vhs: {
        // Use VHS rather than the browser's own HLS wherever both exist, so
        // every desktop browser behaves the same way. Mobile Safari keeps its
        // native implementation, which is better tuned for the hardware.
        overrideNative: !device.mobile,
      },
      nativeAudioTracks: false,
      nativeVideoTracks: false,
    },
  });

  player.on('error', () => {
    const err = player.error();
    note(`player error ${err?.code}: ${err?.message || ''}`);
    showFallback(`Playback failed: ${err?.message || 'unknown error'}`);
  });
  player.on('waiting', () => note('waiting for data'));
  player.on('playing', () => { note('playing'); setStatus(''); });
  player.on('loadedmetadata', () => note(`metadata: ${Math.round(player.duration() || 0)}s`));

  let lastSave = 0;
  player.on('timeupdate', () => {
    if (Date.now() - lastSave < 5000) return;
    lastSave = Date.now();
    rememberPosition();
  });

  player.on('ended', () => {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    if (index < ticket.items.length - 1) play(index + 1);
  });

  return true;
}

// --------------------------------------------------------------- playback

function current() {
  return ticket.items[index];
}

async function play(next) {
  index = Math.max(0, Math.min(next, ticket.items.length - 1));
  const item = current();

  $('#watch-now').textContent = item.title;
  $('#watch-position').textContent = ticket.items.length > 1
    ? `${index + 1} of ${ticket.items.length}`
    : '';
  $('#watch-fallback').hidden = true;
  setStatus('Preparing the stream…');
  trace.length = 0;

  endConversion();
  closeExternalPlayer();
  $('#watch-audio-wrap').hidden = true;
  markQueue();
  updateNav();

  if (!item.transcodeKey) {
    // No ffmpeg in this build: hand the file over as it is.
    note('no ffmpeg — playing the source directly');
    setSource(item.url, 'video/mp4');
    return;
  }

  let session;
  try {
    session = await post('/api/transcode/start', {
      u: item.transcodeKey.u,
      s: item.transcodeKey.s,
      audio: 0,
    });
  } catch (err) {
    showFallback(err.message);
    return;
  }

  note(`server chose: ${session.mode}`);

  if (session.mode === 'direct') {
    convert = null;
    setStatus('');
    setSource(session.url, 'video/mp4');
    attachSubtitle();
    renderAudioMenu();
    return;
  }

  convert = {
    sid: session.sid,
    duration: session.duration || null,
    tracks: session.audioTracks || [],
    audio: 0,
  };
  beginHeartbeat();

  setStatus(session.videoCopy === false
    ? `Re-encoding ${session.videoCodec}. A slow server may not keep up.`
    : `Remuxing ${session.videoCodec}, ${session.audioCodec} audio.`);

  setSource(session.url, 'application/x-mpegURL');
  attachSubtitle();
  renderAudioMenu();
  watchForSilence();
}

function setSource(src, type) {
  note(`source ${type} ${src.slice(0, 60)}`);
  player.src({ src, type });

  const resumeAt = savedPosition();
  player.one('loadedmetadata', () => {
    if (resumeAt && resumeAt < (player.duration() || Infinity)) player.currentTime(resumeAt);
    const started = player.play();
    if (started?.catch) started.catch(() => setStatus('Press play to start.'));
  });
}

function updateNav() {
  $('#watch-prev').disabled = index === 0;
  $('#watch-next').disabled = index >= ticket.items.length - 1;
  $('#watch-queue-wrap').hidden = ticket.items.length < 2;
}

function setStatus(text) {
  const el = $('#watch-status');
  el.textContent = text;
  el.hidden = !text;
}

function fail(message) {
  show();
  setStatus('');
  $('#watch-title').textContent = 'Nothing to play';
  $('#watch-fallback').hidden = false;
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  $('#watch-fallback-actions').innerHTML = '';
  return undefined;
}

// ------------------------------------------------------------ conversion

function beginHeartbeat() {
  clearInterval(heartbeatTimer);
  heartbeatTimer = setInterval(() => {
    if (!convert?.sid) return;
    post(`/api/transcode/heartbeat/${convert.sid}`).catch(() => {});
  }, 10000);
}

function endConversion() {
  clearInterval(heartbeatTimer);
  if (convert?.sid) post(`/api/transcode/stop/${convert.sid}`).catch(() => {});
  convert = null;
}

// An HLS stall raises nothing of its own, so if nothing has played after a
// reasonable wait, say what is known rather than showing a timer that never
// moves.
function watchForSilence() {
  const started = Date.now();

  const timer = setInterval(async () => {
    if (!convert || (player?.currentTime() || 0) > 0) { clearInterval(timer); return; }
    if (Date.now() - started < 12000) return;
    clearInterval(timer);

    let server = null;
    try {
      server = await fetch(`/api/transcode/debug/${convert.sid}`, { credentials: 'same-origin' })
        .then((r) => (r.ok ? r.json() : null));
    } catch { /* best effort */ }

    const lines = [
      `readyState ${player?.readyState()}, duration ${Math.round(player?.duration() || 0)}s`,
      server
        ? `server: ${server.segments} segment(s), ffmpeg ${server.running ? 'running' : 'stopped'}${server.restarts ? `, ${server.restarts} restart(s)` : ''}`
        : 'server: no report',
      server?.plan
        ? `file: ${server.plan.container} ${server.plan.videoCodec}/${server.plan.audioCodec} (copy ${server.plan.videoCopy ? 'yes' : 'no'})`
        : null,
      server?.lastError ? `ffmpeg: ${server.lastError}` : null,
      '',
      ...trace.slice(-14),
    ].filter(Boolean);

    showFallback('Nothing has played after twelve seconds. What happened:');
    const panel = $('#watch-fallback-note');
    panel.hidden = false;
    panel.style.whiteSpace = 'pre-wrap';
    panel.style.fontFamily = 'ui-monospace, monospace';
    panel.style.fontSize = '11px';
    panel.textContent = lines.join('\n');
  }, 1000);
}

// ----------------------------------------------------------- audio tracks

// While converting, ffmpeg is told which stream to map, so any track in the
// file can be chosen — at the cost of restarting the conversion. Restreaming,
// the file carries its own tracks and Video.js switches between them.
function renderAudioMenu() {
  const wrap = $('#watch-audio-wrap');
  const select = $('#watch-audio');
  select.innerHTML = '';

  if (convert?.tracks?.length > 1) {
    for (const track of convert.tracks) {
      const option = document.createElement('option');
      option.value = String(track.index);
      option.textContent = track.label;
      select.append(option);
    }
    select.value = String(convert.audio);
    select.onchange = async () => {
      const wanted = Number(select.value);
      setStatus('Switching audio track…');
      try {
        const session = await post('/api/transcode/start', {
          u: current().transcodeKey.u,
          s: current().transcodeKey.s,
          audio: wanted,
          replace: convert.sid,
        });
        convert = { ...convert, sid: session.sid, audio: wanted };
        setSource(session.url, 'application/x-mpegURL');
        attachSubtitle();
      } catch (err) {
        showFallback(err.message);
      }
    };
    wrap.hidden = false;
    return;
  }

  const native = player?.audioTracks?.();
  if (native && native.length > 1) {
    for (let i = 0; i < native.length; i += 1) {
      const option = document.createElement('option');
      option.value = String(i);
      option.textContent = native[i].label || native[i].language || `Track ${i + 1}`;
      if (native[i].enabled) select.value = String(i);
      select.append(option);
    }
    select.onchange = () => {
      for (let i = 0; i < native.length; i += 1) native[i].enabled = String(i) === select.value;
    };
    wrap.hidden = false;
    return;
  }

  wrap.hidden = true;
}

// -------------------------------------------------------------- subtitles

function clearSubtitles() {
  if (!player) return;
  const tracks = player.remoteTextTracks();
  for (let i = tracks.length - 1; i >= 0; i -= 1) player.removeRemoteTextTrack(tracks[i]);
}

function attachSubtitle(src, label) {
  const url = src || current().subtitle;
  if (!url || !player) return;
  player.addRemoteTextTrack({
    kind: 'subtitles',
    src: url,
    label: label || 'Addon subtitles',
    default: true,
  }, false);
}

async function loadSubtitleMenu() {
  const select = $('#watch-subs');
  const wrap = $('#watch-subs-wrap');
  wrap.hidden = true;

  if (!ticket.type || !ticket.id) return;

  let available = [];
  try {
    available = await fetch(
      `/api/subtitles/${encodeURIComponent(ticket.type)}/${encodeURIComponent(ticket.id)}`,
      { credentials: 'same-origin' },
    ).then((res) => (res.ok ? res.json() : []));
  } catch {
    return;
  }
  if (!available.length) return;

  select.innerHTML = '<option value="">Off</option>';
  for (const sub of available) {
    const option = document.createElement('option');
    option.value = sub.url;
    option.textContent = `${sub.label}${sub.addon ? ` · ${sub.addon}` : ''}`;
    select.append(option);
  }

  select.onchange = () => {
    clearSubtitles();
    if (!select.value) return;
    attachSubtitle(select.value, select.selectedOptions[0].textContent);
  };
  wrap.hidden = false;
}

// ----------------------------------------------------------------- queue

function renderQueue() {
  const list = $('#watch-queue');
  list.innerHTML = '';
  ticket.items.forEach((item, i) => {
    const row = document.createElement('button');
    row.className = 'queue-item';
    row.innerHTML = '<span class="queue-num"></span><span class="queue-title"></span>';
    row.querySelector('.queue-num').textContent = String(i + 1);
    row.querySelector('.queue-title').textContent = item.title;
    row.addEventListener('click', () => play(i));
    list.append(row);
  });
  markQueue();
}

function markQueue() {
  [...$('#watch-queue').children].forEach((row, i) => {
    row.setAttribute('aria-current', String(i === index));
  });
}

// -------------------------------------------------------- external player

const EXTERNAL_PLAYER = 'https://onlineplayer.app/en/player';

function externalPlayerUsable() {
  return location.protocol === 'https:';
}

async function useExternalPlayer() {
  const item = current();
  if (!item.transcodeKey) return;

  setStatus('Handing the stream to OnlinePlayer…');
  let session;
  try {
    session = await post('/api/transcode/start', {
      u: item.transcodeKey.u, s: item.transcodeKey.s, forceDirect: true,
    });
  } catch (err) {
    showFallback(err.message);
    return;
  }

  if (session.mode !== 'direct') {
    showFallback('This file has to be converted first, and a converted stream can only be played here.');
    return;
  }

  player?.pause();
  endConversion();
  setStatus('Playing in OnlinePlayer. The stream link has been shared with that site.');

  const absolute = new URL(session.url, location.origin).href;
  const frame = $('#watch-external');
  frame.src = `${EXTERNAL_PLAYER}?${new URLSearchParams({ autoload: absolute, theme: 'dark' })}`;
  frame.hidden = false;
}

function closeExternalPlayer() {
  const frame = $('#watch-external');
  if (frame.hidden) return;
  frame.hidden = true;
  frame.removeAttribute('src');
}

// --------------------------------------------------------- when it fails

function showFallback(message) {
  const panel = $('#watch-fallback');
  const actions = $('#watch-fallback-actions');
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  actions.innerHTML = '';
  panel.hidden = false;
  setStatus('');

  action(actions, 'Try again', () => play(index), 'primary');
  action(actions, 'Open in VLC', () => { location.href = `/playlist/${token}.m3u?dl=1`; });

  if (device.os === 'android') {
    action(actions, 'Choose an app', () => {
      location.href = playLink('/play', { url: current().url, title: current().title })
        .replace(/target=[^&]*/, 'target=player-chooser');
    });
  }
  if (externalPlayerUsable()) action(actions, 'Try OnlinePlayer', useExternalPlayer);
  action(actions, 'Copy stream link', copyLink);
}

function action(parent, label, handler, kind = '') {
  const button = document.createElement('button');
  button.className = kind === 'primary' ? 'btn-primary' : 'btn-ghost';
  button.textContent = label;
  button.addEventListener('click', handler);
  parent.append(button);
  return button;
}

async function copyLink() {
  const url = current()?.url;
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
    setStatus('Stream link copied. In VLC: File → Open Network Stream.');
  } catch {
    setStatus(url);
  }
}

// ------------------------------------------------------------- positions

function savedPosition() {
  const raw = localStorage.getItem(`nuvio.pos.${token}.${index}`);
  const seconds = Number(raw);
  return Number.isFinite(seconds) && seconds > 30 ? seconds : 0;
}

function rememberPosition() {
  if (!player) return;
  const at = player.currentTime() || 0;
  const total = player.duration() || 0;

  if (at < 30) return;
  if (total && at > total - 60) {
    localStorage.removeItem(`nuvio.pos.${token}.${index}`);
    return;
  }
  localStorage.setItem(`nuvio.pos.${token}.${index}`, String(Math.floor(at)));
}

// ----------------------------------------------------------------- wiring

export function init() {
  $('#watch-prev').addEventListener('click', () => play(index - 1));
  $('#watch-next').addEventListener('click', () => play(index + 1));
  $('#watch-back').addEventListener('click', () => {
    rememberPosition();
    unmount();
    onExit();
  });

  if (externalPlayerUsable()) {
    const toggle = $('#watch-external-toggle');
    toggle.hidden = false;
    toggle.addEventListener('click', () => {
      if ($('#watch-external').hidden) useExternalPlayer();
      else { closeExternalPlayer(); play(index); }
    });
  }

  // A closed tab should take its ffmpeg with it rather than waiting for the
  // heartbeat to time out.
  window.addEventListener('pagehide', () => {
    if (convert?.sid) navigator.sendBeacon?.(`/api/transcode/stop/${convert.sid}`);
  });

  // Video.js handles the usual transport keys once focused; these are the
  // ones it doesn't know about.
  document.addEventListener('keydown', (event) => {
    if ($('#screen-watch').hidden) return;
    if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;

    if (event.key === 'n' && index < ticket.items.length - 1) play(index + 1);
    else if (event.key === 'p' && index > 0) play(index - 1);
    else if (event.key === 'Escape' && !document.fullscreenElement) $('#watch-back').click();
  });
}
