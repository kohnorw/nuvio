// The player that runs in the page: a plain <video> with the browser's own
// controls.
//
// The server decides how a file arrives and answers with a mode:
//
//   direct   an MP4 of H.264 and AAC, restreamed whole. Native seeking.
//   hls      everything else, through Lumen (src/transcode.js): remuxed or
//            re-encoded on the server into a full-length VOD playlist, so
//            the whole film is seekable from the start. Safari plays it
//            natively; elsewhere hls.js feeds the <video>.
//
// VLC is the fallback. When Lumen can't take a file — no ffmpeg, the server
// busy, a source it can't open — desktops hand the stream to VLC through the
// launcher, and phones offer VLC on the fallback screen.
//
// Every load is tagged with a generation number. Anything asynchronous — a
// start request, a metadata event, a stall timer — checks it before acting,
// so a reply that arrives after the person has moved on is thrown away (and
// its ffmpeg stopped) instead of taking over the screen.

import { device, playLink, hasLauncher, launcherInstalled, openInVlc, vlcLink } from './platform.js';
import * as controls from './controls.js';

const $ = (s, root = document) => root.querySelector(s);

const HEARTBEAT_MS = 10000;
const SILENCE_MS = 12000;
const SAVE_EVERY_MS = 5000;
const MIN_RESUME_S = 30;
const END_MARGIN_S = 60;
const EXTERNAL_PLAYER = 'https://onlineplayer.app/en/player';

// ------------------------------------------------------------------ state

const state = {
  token: null,
  ticket: null,
  index: 0,
  gen: 0,             // bumped on every load; stale work checks it
  video: null,       // the <video> element
  hls: null,         // hls.js instance, when one is in use
  session: null,      // { mode, sid?, tracks, audio }
  heartbeat: null,
  silence: null,
  lastSave: 0,
  subtitle: null,     // { url, label } chosen from the menu, or null for the item's own
  subtitlesOff: false,
  addonSubs: [],      // subtitles from addons, for this title
  embeddedSubs: [],   // subtitles inside the file, from the last start reply
  initialised: false,
  onExit: () => { location.replace('/'); },
};

const trace = [];
function note(what) {
  trace.push(`${(performance.now() / 1000).toFixed(1).padStart(6)}s  ${what}`);
  if (trace.length > 40) trace.shift();
}

// ---------------------------------------------------------------- helpers

async function request(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

const post = (path, body = {}) => request(path, { method: 'POST', body });

const storage = {
  key: (i) => `nuvio.pos.${state.token}.${i}`,
  get(i) {
    try {
      const n = Number(localStorage.getItem(this.key(i)));
      return Number.isFinite(n) && n > MIN_RESUME_S ? n : 0;
    } catch { return 0; }
  },
  set(i, seconds) {
    try { localStorage.setItem(this.key(i), String(Math.floor(seconds))); } catch { /* private mode */ }
  },
  clear(i) {
    try { localStorage.removeItem(this.key(i)); } catch { /* private mode */ }
  },
};

const current = () => state.ticket?.items[state.index];
const isStale = (gen) => gen !== state.gen;

function setStatus(text) {
  const el = $('#watch-status');
  el.textContent = text || '';
  el.hidden = !text;
}

// ------------------------------------------------------------ public API

export function isWatchRoute() {
  return location.pathname === '/watch';
}

export async function mount(options = {}) {
  if (options.onExit) state.onExit = options.onExit;
  const params = new URLSearchParams(location.search);
  state.token = params.get('t');

  show();
  if (!state.token) return fail('No playlist token in that link.');
  setStatus('Resolving streams…');

  try {
    state.ticket = await request(`/api/ticket/${encodeURIComponent(state.token)}`);
  } catch (err) {
    return fail(err.message);
  }
  if (!state.ticket.items?.length) return fail('That playlist came back empty.');

  document.title = `${state.ticket.title} — Nuvio`;

  await createPlayer();

  renderQueue();
  loadSubtitleMenu(); // not awaited: playback shouldn't wait on addons
  if (params.get('copy') === '1') copyLink();
  await play(0);
  return undefined;
}

export function unmount() {
  state.gen += 1;
  rememberPosition();
  stopSession();
  closeExternalPlayer();
  resetVideo();
  document.body.classList.remove('watching');
  $('#screen-watch').hidden = true;
  document.title = 'Nuvio';
}

// Back to wherever the player was opened from. Cleaning up must never stop
// the exit, so it is guarded: before, anything that threw in unmount() left
// the button doing nothing. When the player was opened from this app, going
// back in history returns to that page as it was (the details page, not a
// fresh home screen); opened any other way, it goes home.
function leave() {
  try { unmount(); } catch (err) { console.error(err); }
  let fromHere = false;
  try { fromHere = Boolean(document.referrer) && new URL(document.referrer).origin === location.origin; } catch { /* no referrer */ }
  if (fromHere && history.length > 1) {
    history.back();
    // If nothing happened (history empty in a new window or PWA), go home.
    setTimeout(() => { if (isWatchRoute()) state.onExit(); }, 600);
    return;
  }
  state.onExit();
}

export function init() {
  if (state.initialised) return;
  state.initialised = true;

  $('#watch-back').addEventListener('click', (event) => { event.preventDefault(); leave(); });

  if (location.protocol === 'https:') {
    const toggle = $('#watch-external-toggle');
    toggle.hidden = false;
    toggle.addEventListener('click', () => {
      if ($('#watch-external').hidden) useExternalPlayer();
      else play(state.index);
    });
  }

  // A closed tab takes its ffmpeg with it rather than waiting for a timeout.
  window.addEventListener('pagehide', () => {
    rememberPosition();
    const sid = state.session?.sid;
    if (sid) navigator.sendBeacon?.(`/api/transcode/stop/${sid}`);
  });

  document.addEventListener('keydown', onKey);
}

// ---------------------------------------------------------------- the video

let hlsPromise = null;

// Only fetched the first time a converted stream needs it, and only in
// browsers that can't play HLS themselves.
function loadHlsJs() {
  if (window.Hls) return Promise.resolve(window.Hls);
  hlsPromise ??= new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = '/vendor/hls.light.min.js';
    script.onload = () => resolve(window.Hls || null);
    script.onerror = () => { hlsPromise = null; resolve(null); };
    document.head.append(script);
  });
  return hlsPromise;
}

function nativeHls(video) {
  return Boolean(video.canPlayType('application/vnd.apple.mpegurl'));
}

async function createPlayer() {
  if (state.video) return true;
  const video = $('#watch-video');
  controls.attach(video, {
    prev: () => { if (state.index > 0) play(state.index - 1); },
    next: () => { if (state.ticket && state.index < state.ticket.items.length - 1) play(state.index + 1); },
  });
  video.playsInline = true;
  video.preload = 'auto';
  state.video = video;

  video.addEventListener('error', () => {
    // An empty src after a reset raises an error too; ignore that one.
    if (!video.getAttribute('src') && !state.hls) return;
    const err = video.error;
    note(`video error ${err?.code}: ${err?.message || ''}`);
    onPlaybackError(err);
  });
  video.addEventListener('waiting', () => note('waiting for data'));
  video.addEventListener('playing', () => { note('playing'); setStatus(''); clearSilence(); });
  video.addEventListener('timeupdate', () => {
    if (Date.now() - state.lastSave < SAVE_EVERY_MS) return;
    state.lastSave = Date.now();
    rememberPosition();
  });
  video.addEventListener('ended', () => {
    storage.clear(state.index);
    if (state.index < state.ticket.items.length - 1) play(state.index + 1);
  });

  return true;
}

function resetVideo() {
  const { video } = state;
  if (state.hls) {
    try { state.hls.destroy(); } catch { /* already gone */ }
    state.hls = null;
  }
  if (!video) return;
  video.pause();
  video.removeAttribute('src');
  video.querySelectorAll('track').forEach((t) => t.remove());
  video.load();
}

// --------------------------------------------------------------- playback

// Load item `next`. `opts.resumeAt` overrides the saved position (an audio
// switch carries on from here); `opts.forceTranscode` skips direct mode after
// the browser has refused the file as it stands.
async function play(next, opts = {}) {
  const { ticket, video } = state;
  if (!ticket || !video) return;

  rememberPosition();
  const gen = ++state.gen;
  state.index = Math.max(0, Math.min(next, ticket.items.length - 1));
  const item = current();
  trace.length = 0;

  stopSession();
  closeExternalPlayer();
  hideFallback();
  $('#watch-audio-wrap').hidden = true;
  $('#watch-position').textContent = ticket.items.length > 1
    ? `${state.index + 1} of ${ticket.items.length}` : '';
  markQueue();
  updateNav();
  loadSources(gen);
  resetVideo();
  setStatus('Preparing the stream…');

  const resumeAt = opts.resumeAt ?? storage.get(state.index);
  // An image subtitle being burned in. Carried across audio switches and
  // retries of the same item; a new item starts without one.
  const burn = Number.isInteger(opts.burn) ? opts.burn : null;
  state.embeddedSubs = [];
  renderSubtitleMenu();

  if (!item.transcodeKey) {
    note('no ffmpeg — playing the source directly');
    state.session = { mode: 'source', tracks: [], audio: 0 };
    load(gen, { src: item.url, type: 'video/mp4', resumeAt });
    return;
  }

  let reply;
  try {
    reply = await post('/api/transcode/start', {
      u: item.transcodeKey.u,
      s: item.transcodeKey.s,
      audio: opts.audio ?? 0,
      // Start ffmpeg where playback will resume, so the first segment made
      // is the one that's needed.
      seek: resumeAt || 0,
      burn: burn ?? undefined,
      forceTranscode: opts.forceTranscode === true || undefined,
    });
  } catch (err) {
    if (isStale(gen)) return;
    // Lumen couldn't take it. VLC is the fallback: straight to it on a
    // desktop with the launcher, offered first everywhere else.
    note(`conversion refused: ${err.message}`);
    showFallback(`The server couldn’t convert this: ${err.message}`);
    return;
  }

  // The person moved on while we waited: don't leave that ffmpeg running.
  if (isStale(gen)) {
    if (reply.sid) post(`/api/transcode/stop/${reply.sid}`).catch(() => {});
    return;
  }

  note(`server chose: ${reply.mode}`);

  if (reply.mode === 'external') {
    state.session = { mode: 'external', tracks: [], audio: 0 };
    handToVlc(describeFile(reply));
    return;
  }
  state.session = {
    mode: reply.mode,
    sid: reply.sid || null,
    tracks: reply.audioTracks || [],
    audio: reply.audio ?? opts.audio ?? 0,
    burn: reply.burn ?? null,
    forcedTranscode: opts.forceTranscode === true,
  };
  state.embeddedSubs = reply.subtitleTracks || [];
  renderSubtitleMenu();

  if (reply.mode === 'direct') {
    load(gen, { src: reply.url, type: 'video/mp4', resumeAt });
    return;
  }

  startHeartbeat(gen);
  setStatus(describeConversion(reply));
  load(gen, { src: reply.url, type: 'application/x-mpegURL', resumeAt });
  watchForSilence(gen);
}

function describeConversion(reply) {
  if (reply.videoCopy) return `Remuxing ${reply.videoCodec}, ${reply.audioCodec} audio.`;
  const where = reply.encoder && reply.encoder !== 'software' ? ` on the GPU (${reply.encoder})` : ' on the CPU';
  const extras = [
    reply.hdr && (reply.toneMapped ? 'HDR tone mapped' : 'HDR, colours may look flat'),
    reply.burn !== null && reply.burn !== undefined && 'subtitles burned in',
  ].filter(Boolean);
  return `Converting ${reply.videoCodec}${where}${extras.length ? ` · ${extras.join(' · ')}` : ''}.`;
}

async function load(gen, { src, type, resumeAt }) {
  const { video } = state;
  note(`source ${type} ${src.slice(0, 60)}`);

  video.addEventListener('loadedmetadata', () => {
    if (isStale(gen)) return;
    note(`metadata: ${Math.round(video.duration || 0)}s`);
    if (resumeAt) seekWithin(resumeAt);
    renderAudioMenu(gen);
    video.play()?.catch?.(() => { if (!isStale(gen)) setStatus('Press play to start.'); });
  }, { once: true });

  const isHls = type === 'application/x-mpegURL';
  if (!isHls || nativeHls(video)) {
    video.src = src;
    syncSubtitles();
    return;
  }

  const Hls = await loadHlsJs();
  if (isStale(gen)) return;
  if (!Hls?.isSupported()) {
    showFallback('This browser can’t play a converted stream.');
    return;
  }

  const hls = new Hls({ maxBufferLength: 30, backBufferLength: 60 });
  state.hls = hls;
  hls.on(Hls.Events.ERROR, (_event, data) => {
    if (isStale(gen) || !data.fatal) return;
    note(`hls fatal: ${data.type} ${data.details}`);
    if (data.type === Hls.ErrorTypes.MEDIA_ERROR) { hls.recoverMediaError(); return; }
    showFallback(data.type === Hls.ErrorTypes.NETWORK_ERROR
      ? 'The stream stopped arriving.'
      : `Playback failed: ${data.details}`);
  });
  hls.loadSource(src);
  hls.attachMedia(video);
  syncSubtitles();
}

// A growing HLS playlist can only seek into what ffmpeg has written, so clamp
// to the seekable range rather than jumping into a stall.
function seekWithin(seconds) {
  const { video } = state;
  const { seekable } = video;
  let limit = Number.isFinite(video.duration) ? video.duration : Infinity;
  if (seekable?.length) limit = Math.min(limit, seekable.end(seekable.length - 1) - 2);
  const target = Math.max(0, Math.min(seconds, limit));
  if (target > 0) video.currentTime = target;
}

function onPlaybackError(err) {
  const { session } = state;
  // MEDIA_ERR_DECODE / SRC_NOT_SUPPORTED on a restream: the codecs looked
  // playable but this browser disagrees. Convert it instead, once.
  const undecodable = err?.code === 3 || err?.code === 4;
  // A file the browser refuses goes through Lumen first. Only when that
  // fails too does VLC come into it (see showFallback).
  if (['direct', 'source'].includes(session?.mode) && !session.forcedTranscode && undecodable
      && current()?.transcodeKey) {
    note('direct playback refused — converting instead');
    play(state.index, { forceTranscode: true, resumeAt: state.video.currentTime || undefined });
    return;
  }
  showFallback(describeError(err));
}

function describeError(err) {
  const mixed = location.protocol === 'https:' && /^http:/.test(current()?.url || '');
  if (state.session?.mode === 'source' && mixed) {
    return 'This stream is plain HTTP and this page is HTTPS, so the browser blocked it.';
  }
  if (err?.code === 4 || err?.code === 3) return 'This browser can’t decode that file.';
  if (err?.code === 2) return 'The stream stopped arriving.';
  return `Playback failed: ${err?.message || 'unknown error'}`;
}

function updateNav() {
  const count = state.ticket.items.length;
  // A single film has no episodes to step through, so those controls go.
  $('#watch-prev').hidden = count < 2;
  $('#watch-next').hidden = count < 2;
  $('#watch-prev').disabled = state.index === 0;
  $('#watch-next').disabled = state.index >= count - 1;
  $('#watch-queue-btn').hidden = count < 2;
}

function show() {
  document.body.classList.add('watching');
  $('#screen-watch').hidden = false;
}

function fail(message) {
  show();
  setStatus('');
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  $('#watch-fallback-actions').replaceChildren();
  $('#watch-fallback').hidden = false;
}

// ------------------------------------------------------------ conversion

function startHeartbeat(gen) {
  clearInterval(state.heartbeat);
  state.heartbeat = setInterval(async () => {
    const sid = state.session?.sid;
    if (isStale(gen) || !sid) { clearInterval(state.heartbeat); return; }
    try {
      await post(`/api/transcode/heartbeat/${sid}`);
    } catch {
      if (isStale(gen)) return;
      clearInterval(state.heartbeat);
      note('heartbeat refused — session gone');
      showFallback('The conversion ended on the server.');
    }
  }, HEARTBEAT_MS);
}

function stopSession() {
  clearInterval(state.heartbeat);
  clearSilence();
  const sid = state.session?.sid;
  if (sid) post(`/api/transcode/stop/${sid}`).catch(() => {});
  state.session = null;
}

function clearSilence() {
  clearTimeout(state.silence);
  state.silence = null;
}

// An HLS stall raises nothing, so if nothing has played after a while, say
// what is known rather than showing a clock that never moves.
function watchForSilence(gen) {
  clearSilence();
  state.silence = setTimeout(async () => {
    const { video, session } = state;
    if (isStale(gen) || !session?.sid || !video || (!video.paused && video.currentTime > 0)) return;

    let server = null;
    try { server = await request(`/api/transcode/debug/${session.sid}`); } catch { /* best effort */ }
    if (isStale(gen)) return;

    const lines = [
      `readyState ${video.readyState}, duration ${Math.round(Number.isFinite(video.duration) ? video.duration : 0)}s${state.hls ? ' (hls.js)' : ''}`,
      server
        ? `server: ${server.segments} segment(s), ffmpeg ${server.running ? 'running' : 'stopped'}${server.restarts ? `, ${server.restarts} restart(s)` : ''}`
        : 'server: no report',
      server?.plan && `file: ${server.plan.container} ${server.plan.videoCodec}/${server.plan.audioCodec} (copy ${server.plan.videoCopy ? 'yes' : 'no'})`,
      server?.lastError && `ffmpeg: ${server.lastError}`,
      '',
      ...trace.slice(-14),
    ].filter((l) => l !== null && l !== undefined && l !== false);

    showFallback(`Nothing has played after ${SILENCE_MS / 1000} seconds. What happened:`);
    const panel = $('#watch-fallback-note');
    panel.classList.add('watch-trace');
    Object.assign(panel.style, { whiteSpace: 'pre-wrap', fontFamily: 'ui-monospace, monospace', fontSize: '11px' });
    panel.textContent = lines.join('\n');
    panel.hidden = false;
  }, SILENCE_MS);
}

// ---------------------------------------------------------------- sources

// Every stream the addons returned for what's on screen, for the options
// menu's Source section. Choosing one swaps it in and carries on from the
// same position. Kept per title, so episodes and repeat visits are instant.
const sourceCache = new Map();

async function loadSources(gen) {
  const wrap = $('#watch-source-wrap');
  const select = $('#watch-source');
  const item = current();
  const type = state.ticket?.type;
  const id = item?.id || state.ticket?.id;
  wrap.hidden = true;
  if (!item || !type || !id) return;

  let list = sourceCache.get(`${type}/${id}`);
  if (!list) {
    try {
      const data = await request(`/api/streams/${encodeURIComponent(type)}/${encodeURIComponent(id)}?keys=1`);
      list = Array.isArray(data?.streams) ? data.streams : [];
      sourceCache.set(`${type}/${id}`, list);
    } catch { return; }
  }
  if (isStale(gen) || !list.length) return;

  select.replaceChildren();
  let chosen = null;
  list.forEach((stream, i) => {
    const el = option(String(i), stream.headline || stream.label || `Source ${i + 1}`);
    const usable = stream.playable && stream.url;
    el.dataset.detail = [stream.addon, ...(stream.badges || []), usable ? null : 'needs debrid']
      .filter(Boolean).join(' · ');
    el.disabled = !usable;
    if (usable && stream.url === item.url && chosen === null) chosen = String(i);
    select.append(el);
  });
  // The one playing came from a playlist and isn't in this list verbatim.
  if (chosen === null) {
    const el = option('current', 'Current stream');
    select.prepend(el);
    chosen = 'current';
  }
  select.value = chosen;
  wrap.hidden = false;

  select.onchange = () => {
    const stream = list[Number(select.value)];
    if (!stream?.url) return;
    const resumeAt = state.video?.currentTime || 0;
    state.ticket.items[state.index] = {
      ...current(),
      url: stream.url,
      transcodeKey: stream.transcodeKey || null,
    };
    setStatus('Switching source…');
    play(state.index, { resumeAt });
  };
}

// ----------------------------------------------------------- audio tracks

function renderAudioMenu(gen) {
  const wrap = $('#watch-audio-wrap');
  const select = $('#watch-audio');
  const { session, video } = state;
  select.replaceChildren();
  select.onchange = null;
  wrap.hidden = true;
  if (isStale(gen)) return;

  // Converting: ffmpeg maps whichever stream we ask for.
  if (session?.mode === 'hls' && session.tracks.length > 1) {
    for (const track of session.tracks) select.append(option(String(track.index), track.label));
    select.value = String(session.audio);
    select.onchange = () => {
      setStatus('Switching audio track…');
      play(state.index, { audio: Number(select.value), resumeAt: video.currentTime || 0, burn: session.burn ?? undefined });
    };
    wrap.hidden = false;
    return;
  }

  // Restreaming: only offer what the browser genuinely exposes (Safari).
  const tracks = video.audioTracks;
  if (tracks && tracks.length > 1) {
    for (let i = 0; i < tracks.length; i += 1) {
      select.append(option(String(i), tracks[i].label || tracks[i].language || `Track ${i + 1}`));
      if (tracks[i].enabled) select.value = String(i);
    }
    select.onchange = () => {
      for (let i = 0; i < tracks.length; i += 1) tracks[i].enabled = String(i) === select.value;
    };
    wrap.hidden = false;
  }
}

function option(value, label) {
  const el = document.createElement('option');
  el.value = value;
  el.textContent = label;
  return el;
}

// -------------------------------------------------------------- subtitles

// One subtitle track at a time: the menu's choice if there is one, else the
// item's own, else nothing. Called after every source change so tracks never
// pile up across episodes or audio switches.
function syncSubtitles() {
  const { video } = state;
  if (!video) return;
  video.querySelectorAll('track').forEach((t) => t.remove());
  if (state.subtitlesOff) return;

  const chosen = state.subtitle || (current()?.subtitle && { url: current().subtitle, label: 'Addon subtitles' });
  if (!chosen) return;

  const track = document.createElement('track');
  track.kind = 'subtitles';
  track.label = chosen.label;
  track.src = chosen.url;
  track.default = true;
  video.append(track);
  // Some browsers leave a default track hidden when it is added late.
  track.addEventListener('load', () => {
    track.track.mode = 'showing';
    if (/Loading subtitles/.test($('#watch-status')?.textContent || '')) setStatus('');
  }, { once: true });
  track.addEventListener('error', () => setStatus('Those subtitles couldn’t be loaded.'), { once: true });
  track.track.mode = 'showing';
}

async function loadSubtitleMenu() {
  state.addonSubs = [];
  renderSubtitleMenu();
  const { type, id } = state.ticket;
  if (!type || !id) return;
  try {
    const list = await request(`/api/subtitles/${encodeURIComponent(type)}/${encodeURIComponent(id)}`);
    if (Array.isArray(list)) state.addonSubs = list;
  } catch { return; }
  renderSubtitleMenu();
}

// One menu for both kinds: subtitles inside the file (from the start reply)
// and subtitles from addons. Text ones become a <track>; image ones (PGS,
// VobSub) can only be burned into the picture, which restarts the stream.
function renderSubtitleMenu() {
  const wrap = $('#watch-subs-wrap');
  const select = $('#watch-subs');
  const embedded = state.embeddedSubs || [];
  const addons = state.addonSubs || [];
  const burning = state.session?.burn ?? null;

  select.replaceChildren(option('', 'Off'));
  if (current()?.subtitle) select.append(option('__item', 'Default'));
  embedded.forEach((sub) => select.append(option(`e${sub.stream}`, sub.label)));
  addons.forEach((sub, i) => select.append(option(`a${i}`, `${sub.label}${sub.addon ? ` · ${sub.addon}` : ''}`)));
  wrap.hidden = select.options.length < 2;

  if (burning !== null) select.value = `e${burning}`;
  else if (state.subtitlesOff) select.value = '';
  else if (state.subtitle?.key && [...select.options].some((o) => o.value === state.subtitle.key)) select.value = state.subtitle.key;
  else select.value = current()?.subtitle ? '__item' : '';

  select.onchange = () => {
    const value = select.value;
    const label = select.selectedOptions[0]?.textContent || '';
    const sub = value.startsWith('e') ? embedded.find((t) => `e${t.stream}` === value) : null;
    const wasBurning = state.session?.burn ?? null;

    state.subtitlesOff = value === '';
    state.subtitle = null;
    if (sub && !sub.image) state.subtitle = { key: value, url: sub.url, label };
    if (value.startsWith('a')) state.subtitle = { key: value, url: addons[Number(value.slice(1))].url, label };

    const resume = { audio: state.session?.audio ?? 0, resumeAt: state.video?.currentTime || 0 };
    if (sub?.image) {
      setStatus('Burning in subtitles…');
      play(state.index, { ...resume, burn: sub.stream, forceTranscode: true });
      return;
    }
    if (wasBurning !== null) {
      setStatus('Removing burned-in subtitles…');
      play(state.index, resume);
      return;
    }
    if (sub) setStatus('Loading subtitles from the file… the first time can take a little while.');
    syncSubtitles();
  };
}

// ----------------------------------------------------------------- queue

function renderQueue() {
  const list = $('#watch-queue');
  list.replaceChildren(...state.ticket.items.map((item, i) => {
    const row = document.createElement('button');
    row.className = 'queue-item';
    const num = document.createElement('span');
    num.className = 'queue-num';
    num.textContent = String(i + 1);
    const title = document.createElement('span');
    title.className = 'queue-title';
    title.textContent = item.title;
    row.append(num, title);
    row.addEventListener('click', () => play(i));
    return row;
  }));
  markQueue();
}

function markQueue() {
  [...$('#watch-queue').children].forEach((row, i) => {
    row.setAttribute('aria-current', String(i === state.index));
  });
}

// -------------------------------------------------------- external player

async function useExternalPlayer() {
  const item = current();
  if (!item?.transcodeKey) {
    showFallback('This server has no restreaming for that file, so it can’t be handed to another player.');
    return;
  }
  const gen = ++state.gen;
  setStatus('Handing the stream to OnlinePlayer…');

  let reply;
  try {
    reply = await post('/api/transcode/start', { u: item.transcodeKey.u, s: item.transcodeKey.s, forceDirect: true });
  } catch (err) {
    if (!isStale(gen)) showFallback(err.message);
    return;
  }
  if (isStale(gen)) return;
  if (reply.mode !== 'direct') {
    if (reply.sid) post(`/api/transcode/stop/${reply.sid}`).catch(() => {});
    showFallback('This file has to be converted first, and a converted stream can only be played here.');
    return;
  }

  rememberPosition();
  resetVideo();
  stopSession();
  hideFallback();
  setStatus('Playing in OnlinePlayer. The stream link has been shared with that site.');

  const frame = $('#watch-external');
  const absolute = new URL(reply.url, location.origin).href;
  frame.src = `${EXTERNAL_PLAYER}?${new URLSearchParams({ autoload: absolute, theme: 'dark' })}`;
  frame.hidden = false;
}

function closeExternalPlayer() {
  const frame = $('#watch-external');
  if (frame.hidden) return;
  frame.hidden = true;
  frame.removeAttribute('src');
}

// --------------------------------------------------------- when it fails

function hideFallback() {
  $('#watch-fallback').hidden = true;
  $('#watch-fallback-note').hidden = true;
}

function showFallback(message) {
  clearSilence();
  setStatus('');
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  const actions = $('#watch-fallback-actions');
  actions.replaceChildren();

  const item = current();
  // When the browser can't decode the file, VLC is the likeliest thing to work.
  const vlcFirst = hasLauncher();
  if (vlcFirst) action(actions, 'Open in VLC', () => openVlc(), true);
  action(actions, 'Try again', () => play(state.index), !vlcFirst);
  if (item?.transcodeKey && state.session?.mode !== 'hls') {
    action(actions, 'Convert it', () => play(state.index, { forceTranscode: true }));
  }
  if (!vlcFirst && item && ['ios', 'android'].includes(device.os)) {
    action(actions, 'Open in VLC', () => {
      const link = new URL(playLink('/play', { url: item.url, title: item.title }), location.origin);
      link.searchParams.set('target', 'vlc');
      location.href = link.pathname + link.search;
    }, true);
  }
  if (device.os !== 'ios') {
    action(actions, vlcFirst ? 'VLC (.m3u file)' : 'Download for VLC (.m3u)', () => { location.href = `/playlist/${state.token}.m3u?dl=1`; });
  }
  if (device.os === 'android' && item) {
    action(actions, 'Choose an app', () => {
      const link = new URL(playLink('/play', { url: item.url, title: item.title }), location.origin);
      link.searchParams.set('target', 'player-chooser');
      location.href = link.pathname + link.search;
    });
  }
  if (location.protocol === 'https:' && item?.transcodeKey) action(actions, 'Try OnlinePlayer', useExternalPlayer);
  action(actions, 'Copy stream link', copyLink);

  $('#watch-fallback').hidden = false;
}

function describeFile(reply) {
  const codecs = [reply.videoCodec, reply.audioCodec].filter(Boolean).join(' / ');
  return codecs
    ? `This file (${codecs}) won’t play in the browser.`
    : 'This file won’t play in the browser.';
}

// The desktop path for anything the browser can't play: say so, and open a
// vlc:// link carrying the stream. Converting here stays a choice.
function handToVlc(reason) {
  setStatus('');
  resetVideo();
  stopSession();
  $('#watch-fallback-message').textContent = `${reason} Opening it in VLC…`;
  $('#watch-fallback-note').hidden = true;
  renderVlcActions();
  $('#watch-fallback').hidden = false;
  openVlc();
}

function renderVlcActions() {
  const item = current();
  const actions = $('#watch-fallback-actions');
  actions.replaceChildren();
  if (!item) return;

  // A real link, so it can be middle-clicked, dragged or copied as well.
  const open = document.createElement('a');
  open.className = 'btn-primary';
  open.textContent = 'Open in VLC';
  open.href = vlcLink(item.url);
  open.addEventListener('click', (event) => { event.preventDefault(); openVlc(); });
  actions.append(open);

  if (state.ticket.items.length > 1) {
    action(actions, 'Open the whole queue in VLC', () => openVlc(playlistUrl()));
  }
  action(actions, 'Copy VLC link', () => copyText(vlcLink(item.url), 'VLC link copied.'));
  if (item.transcodeKey) {
    action(actions, 'Convert and play here', () => play(state.index, { forceTranscode: true }));
  }
  action(actions, 'Download .m3u', () => { location.href = `${playlistUrl()}?dl=1`; });
}

function playlistUrl() {
  return `/playlist/${state.token}.m3u`;
}

// Open a stream in desktop VLC with a vlc:// link: this item's stream by
// default, or any URL given (the queue's playlist). If VLC doesn't take over,
// say how to set up the launcher that handles vlc:// links.
function openVlc(url = current()?.url) {
  if (!url) return;
  rememberPosition();
  state.video?.pause();
  stopSession();
  openInVlc(url, () => {
    const message = $('#watch-fallback-message');
    message.textContent = message.textContent.replace(' Opening it in VLC…', '');
    const note = $('#watch-fallback-note');
    note.classList.remove('watch-trace');
    note.removeAttribute('style');
    note.replaceChildren(
      launcherInstalled()
        ? 'VLC didn’t open. If your browser asked, allow vlc links and try again. Otherwise '
        : 'Desktop VLC can’t open vlc:// links until the one-time launcher is set up on this computer. ',
      Object.assign(document.createElement('a'), {
        href: '/vlc-setup', target: '_blank', rel: 'noopener',
        textContent: launcherInstalled() ? 'set up the launcher again' : 'Set up VLC',
      }),
      '.',
    );
    note.hidden = false;
    // Opened from the keyboard during playback: there are no actions showing yet.
    if ($('#watch-fallback').hidden) {
      message.textContent = 'VLC didn’t open.';
      renderVlcActions();
    }
    $('#watch-fallback').hidden = false;
  });
}

async function copyText(text, done) {
  try {
    await navigator.clipboard.writeText(text);
    setStatus(done);
  } catch {
    setStatus(text);
  }
}

function action(parent, label, handler, primary = false) {
  const button = document.createElement('button');
  button.className = primary ? 'btn-primary' : 'btn-ghost';
  button.textContent = label;
  button.addEventListener('click', handler);
  parent.append(button);
}

async function copyLink() {
  const url = current()?.url;
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
    setStatus('Stream link copied. In VLC: File → Open Network Stream.');
  } catch {
    setStatus(url);
  }
}

// ------------------------------------------------------------- positions

function rememberPosition() {
  const { video, ticket } = state;
  if (!video || !ticket) return;
  const at = video.currentTime || 0;
  const total = Number.isFinite(video.duration) ? video.duration : 0;
  if (at < MIN_RESUME_S) return;
  if (total && Number.isFinite(total) && at > total - END_MARGIN_S) storage.clear(state.index);
  else storage.set(state.index, at);
}

// -------------------------------------------------------------- keyboard

function onKey(event) {
  const { video, ticket } = state;
  if ($('#screen-watch').hidden || !ticket || !video) return;
  if (event.ctrlKey || event.metaKey || event.altKey) return;
  if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;
  if (event.key === ' ' && document.activeElement?.tagName === 'BUTTON') return;
  // The native controls already answer these keys while the video has focus.
  if (document.activeElement === video && [' ', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;

  const step = event.shiftKey ? 30 : 10;
  const seekBy = (d) => seekWithin(Math.max(0, (video.currentTime || 0) + d));
  const last = ticket.items.length - 1;
  const fullscreen = document.fullscreenElement || document.webkitFullscreenElement;

  switch (event.key) {
    case ' ':
    case 'k':
      if (video.paused) video.play()?.catch?.(() => {}); else video.pause();
      break;
    case 'j': case 'ArrowLeft': seekBy(-step); break;
    case 'l': case 'ArrowRight': seekBy(step); break;
    case 'f':
      controls.toggleFullscreen();
      break;
    case 'm': video.muted = !video.muted; break;
    case 'v': if (hasLauncher()) openVlc(); break;
    case 'n': if (state.index < last) play(state.index + 1); break;
    case 'p': if (state.index > 0) play(state.index - 1); break;
    case 'Escape':
      if (fullscreen) return;
      $('#watch-back').click();
      break;
    default: return;
  }
  event.preventDefault();
}
