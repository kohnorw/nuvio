// The player that runs in the page, on Video.js.
//
// Video.js owns the <video> element: controls, timeline and the HLS engine
// (VHS) that reads the playlist ffmpeg is writing. What belongs to us is what
// Video.js can't know: the queue, the audio tracks ffmpeg maps, the addon
// subtitles, the conversion heartbeat, and what to offer when it all fails.
//
// The server decides how a file arrives and answers with a mode:
//
//   direct   an MP4 of H.264 and AAC, restreamed whole. Native seeking.
//   hls      everything else, remuxed or re-encoded into a growing playlist
//            that always starts at the beginning of the film.
//
// Every load is tagged with a generation number. Anything asynchronous — a
// start request, a metadata event, a stall timer — checks it before acting,
// so a reply that arrives after the person has moved on is thrown away (and
// its ffmpeg stopped) instead of taking over the screen.

import { device, playLink } from './platform.js';

const $ = (s, root = document) => root.querySelector(s);

const HEARTBEAT_MS = 10000;
const SILENCE_MS = 12000;
const SAVE_EVERY_MS = 5000;
const MIN_RESUME_S = 30;
const END_MARGIN_S = 60;
const EXTERNAL_PLAYER = 'https://onlineplayer.app/en/player';

// ------------------------------------------------------------------ state

const state = {
  token: null,
  ticket: null,
  index: 0,
  gen: 0,             // bumped on every load; stale work checks it
  player: null,
  session: null,      // { mode, sid?, tracks, audio }
  heartbeat: null,
  silence: null,
  lastSave: 0,
  subtitle: null,     // { url, label } chosen from the menu, or null for the item's own
  subtitlesOff: false,
  initialised: false,
  onExit: () => { location.href = '/'; },
};

const trace = [];
function note(what) {
  trace.push(`${(performance.now() / 1000).toFixed(1).padStart(6)}s  ${what}`);
  if (trace.length > 40) trace.shift();
}

// ---------------------------------------------------------------- helpers

async function request(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    credentials: 'same-origin',
    headers: body ? { 'content-type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

const post = (path, body = {}) => request(path, { method: 'POST', body });

const storage = {
  key: (i) => `nuvio.pos.${state.token}.${i}`,
  get(i) {
    try {
      const n = Number(localStorage.getItem(this.key(i)));
      return Number.isFinite(n) && n > MIN_RESUME_S ? n : 0;
    } catch { return 0; }
  },
  set(i, seconds) {
    try { localStorage.setItem(this.key(i), String(Math.floor(seconds))); } catch { /* private mode */ }
  },
  clear(i) {
    try { localStorage.removeItem(this.key(i)); } catch { /* private mode */ }
  },
};

const current = () => state.ticket?.items[state.index];
const isStale = (gen) => gen !== state.gen;

function setStatus(text) {
  const el = $('#watch-status');
  el.textContent = text || '';
  el.hidden = !text;
}

// ------------------------------------------------------------ public API

export function isWatchRoute() {
  return location.pathname === '/watch';
}

export async function mount(options = {}) {
  if (options.onExit) state.onExit = options.onExit;
  const params = new URLSearchParams(location.search);
  state.token = params.get('t');

  show();
  if (!state.token) return fail('No playlist token in that link.');
  setStatus('Resolving streams…');

  try {
    state.ticket = await request(`/api/ticket/${encodeURIComponent(state.token)}`);
  } catch (err) {
    return fail(err.message);
  }
  if (!state.ticket.items?.length) return fail('That playlist came back empty.');

  document.title = `${state.ticket.title} — Nuvio`;
  $('#watch-title').textContent = state.ticket.title;

  if (!(await createPlayer())) return fail('The player library could not be loaded.');

  renderQueue();
  loadSubtitleMenu(); // not awaited: playback shouldn't wait on addons
  if (params.get('copy') === '1') copyLink();
  await play(0);
  return undefined;
}

export function unmount() {
  state.gen += 1;
  rememberPosition();
  stopSession();
  closeExternalPlayer();
  if (state.player) {
    try { state.player.dispose(); } catch { /* already gone */ }
    state.player = null;
  }
  document.body.classList.remove('watching');
  $('#screen-watch').hidden = true;
  document.title = 'Nuvio';
}

export function init() {
  if (state.initialised) return;
  state.initialised = true;

  $('#watch-prev').addEventListener('click', () => play(state.index - 1));
  $('#watch-next').addEventListener('click', () => play(state.index + 1));
  $('#watch-back').addEventListener('click', () => { unmount(); state.onExit(); });

  if (location.protocol === 'https:') {
    const toggle = $('#watch-external-toggle');
    toggle.hidden = false;
    toggle.addEventListener('click', () => {
      if ($('#watch-external').hidden) useExternalPlayer();
      else play(state.index);
    });
  }

  // A closed tab takes its ffmpeg with it rather than waiting for a timeout.
  window.addEventListener('pagehide', () => {
    rememberPosition();
    const sid = state.session?.sid;
    if (sid) navigator.sendBeacon?.(`/api/transcode/stop/${sid}`);
  });

  document.addEventListener('keydown', onKey);
}

// ------------------------------------------------------------ the library

let libraryPromise = null;

function loadVideoJs() {
  if (window.videojs) return Promise.resolve(window.videojs);
  libraryPromise ??= new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = '/vendor/video.min.js';
    script.onload = () => resolve(window.videojs || null);
    script.onerror = () => { libraryPromise = null; resolve(null); };
    document.head.append(script);
  });
  return libraryPromise;
}

async function createPlayer() {
  if (state.player) return true;
  const videojs = await loadVideoJs();
  if (!videojs) return false;

  const el = $('#watch-video');
  el.setAttribute('playsinline', '');

  const player = videojs(el, {
    controls: true,
    preload: 'auto',
    fluid: true,
    playbackRates: [0.75, 1, 1.25, 1.5, 2],
    userActions: { hotkeys: false }, // ours, below, work without focus
    html5: {
      vhs: { overrideNative: !device.mobile },
      nativeAudioTracks: false,
      nativeVideoTracks: false,
      nativeTextTracks: false,
    },
  });
  state.player = player;

  player.on('error', () => {
    const err = player.error();
    note(`player error ${err?.code}: ${err?.message || ''}`);
    onPlaybackError(err);
  });
  player.on('waiting', () => note('waiting for data'));
  player.on('playing', () => { note('playing'); setStatus(''); clearSilence(); });
  player.on('timeupdate', () => {
    if (Date.now() - state.lastSave < SAVE_EVERY_MS) return;
    state.lastSave = Date.now();
    rememberPosition();
  });
  player.on('ended', () => {
    storage.clear(state.index);
    if (state.index < state.ticket.items.length - 1) play(state.index + 1);
  });

  return true;
}

// --------------------------------------------------------------- playback

// Load item `next`. `opts.resumeAt` overrides the saved position (an audio
// switch carries on from here); `opts.forceTranscode` skips direct mode after
// the browser has refused the file as it stands.
async function play(next, opts = {}) {
  const { ticket, player } = state;
  if (!ticket || !player) return;

  rememberPosition();
  const gen = ++state.gen;
  state.index = Math.max(0, Math.min(next, ticket.items.length - 1));
  const item = current();
  trace.length = 0;

  stopSession();
  closeExternalPlayer();
  hideFallback();
  $('#watch-audio-wrap').hidden = true;
  $('#watch-now').textContent = item.title;
  $('#watch-position').textContent = ticket.items.length > 1
    ? `${state.index + 1} of ${ticket.items.length}` : '';
  markQueue();
  updateNav();
  player.pause();
  setStatus('Preparing the stream…');

  const resumeAt = opts.resumeAt ?? storage.get(state.index);

  if (!item.transcodeKey) {
    note('no ffmpeg — playing the source directly');
    state.session = { mode: 'source', tracks: [], audio: 0 };
    load(gen, { src: item.url, type: 'video/mp4', resumeAt });
    return;
  }

  let reply;
  try {
    reply = await post('/api/transcode/start', {
      u: item.transcodeKey.u,
      s: item.transcodeKey.s,
      audio: opts.audio ?? 0,
      forceTranscode: opts.forceTranscode === true || undefined,
    });
  } catch (err) {
    if (!isStale(gen)) showFallback(err.message);
    return;
  }

  // The person moved on while we waited: don't leave that ffmpeg running.
  if (isStale(gen)) {
    if (reply.sid) post(`/api/transcode/stop/${reply.sid}`).catch(() => {});
    return;
  }

  note(`server chose: ${reply.mode}`);
  state.session = {
    mode: reply.mode,
    sid: reply.sid || null,
    tracks: reply.audioTracks || [],
    audio: opts.audio ?? 0,
    forcedTranscode: opts.forceTranscode === true,
  };

  if (reply.mode === 'direct') {
    load(gen, { src: reply.url, type: 'video/mp4', resumeAt });
    return;
  }

  startHeartbeat(gen);
  setStatus(reply.videoCopy === false
    ? `Re-encoding ${reply.videoCodec}. A slow server may not keep up.`
    : `Remuxing ${reply.videoCodec}, ${reply.audioCodec} audio.`);
  load(gen, { src: reply.url, type: 'application/x-mpegURL', resumeAt });
  watchForSilence(gen);
}

function load(gen, { src, type, resumeAt }) {
  const { player } = state;
  note(`source ${type} ${src.slice(0, 60)}`);
  player.src({ src, type });
  syncSubtitles();

  player.one('loadedmetadata', () => {
    if (isStale(gen)) return;
    note(`metadata: ${Math.round(player.duration() || 0)}s`);
    if (resumeAt) seekWithin(resumeAt);
    renderAudioMenu(gen);
    const started = player.play();
    started?.catch?.(() => { if (!isStale(gen)) setStatus('Press play to start.'); });
  });
}

// A growing HLS playlist can only seek into what ffmpeg has written, so clamp
// to the seekable range rather than jumping into a stall.
function seekWithin(seconds) {
  const { player } = state;
  const seekable = player.seekable();
  let limit = player.duration() || Infinity;
  if (seekable?.length) limit = Math.min(limit, seekable.end(seekable.length - 1) - 2);
  const target = Math.max(0, Math.min(seconds, limit));
  if (target > 0) player.currentTime(target);
}

function onPlaybackError(err) {
  const { session } = state;
  // MEDIA_ERR_DECODE / SRC_NOT_SUPPORTED on a restream: the codecs looked
  // playable but this browser disagrees. Convert it instead, once.
  if (session?.mode === 'direct' && !session.forcedTranscode && (err?.code === 3 || err?.code === 4)) {
    note('direct playback refused — converting instead');
    play(state.index, { forceTranscode: true, resumeAt: state.player.currentTime() || undefined });
    return;
  }
  showFallback(describeError(err));
}

function describeError(err) {
  const mixed = location.protocol === 'https:' && /^http:/.test(current()?.url || '');
  if (state.session?.mode === 'source' && mixed) {
    return 'This stream is plain HTTP and this page is HTTPS, so the browser blocked it.';
  }
  if (err?.code === 4 || err?.code === 3) return 'This browser can’t decode that file.';
  if (err?.code === 2) return 'The stream stopped arriving.';
  return `Playback failed: ${err?.message || 'unknown error'}`;
}

function updateNav() {
  const count = state.ticket.items.length;
  $('#watch-prev').disabled = state.index === 0;
  $('#watch-next').disabled = state.index >= count - 1;
  $('#watch-queue-wrap').hidden = count < 2;
}

function show() {
  document.body.classList.add('watching');
  $('#screen-watch').hidden = false;
}

function fail(message) {
  show();
  setStatus('');
  $('#watch-title').textContent = 'Nothing to play';
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  $('#watch-fallback-actions').replaceChildren();
  $('#watch-fallback').hidden = false;
}

// ------------------------------------------------------------ conversion

function startHeartbeat(gen) {
  clearInterval(state.heartbeat);
  state.heartbeat = setInterval(async () => {
    const sid = state.session?.sid;
    if (isStale(gen) || !sid) { clearInterval(state.heartbeat); return; }
    try {
      await post(`/api/transcode/heartbeat/${sid}`);
    } catch {
      if (isStale(gen)) return;
      clearInterval(state.heartbeat);
      note('heartbeat refused — session gone');
      showFallback('The conversion ended on the server.');
    }
  }, HEARTBEAT_MS);
}

function stopSession() {
  clearInterval(state.heartbeat);
  clearSilence();
  const sid = state.session?.sid;
  if (sid) post(`/api/transcode/stop/${sid}`).catch(() => {});
  state.session = null;
}

function clearSilence() {
  clearTimeout(state.silence);
  state.silence = null;
}

// An HLS stall raises nothing, so if nothing has played after a while, say
// what is known rather than showing a clock that never moves.
function watchForSilence(gen) {
  clearSilence();
  state.silence = setTimeout(async () => {
    const { player, session } = state;
    if (isStale(gen) || !session?.sid || !player || !player.paused() && player.currentTime() > 0) return;

    let server = null;
    try { server = await request(`/api/transcode/debug/${session.sid}`); } catch { /* best effort */ }
    if (isStale(gen)) return;

    const lines = [
      `readyState ${player.readyState()}, duration ${Math.round(player.duration() || 0)}s`,
      server
        ? `server: ${server.segments} segment(s), ffmpeg ${server.running ? 'running' : 'stopped'}${server.restarts ? `, ${server.restarts} restart(s)` : ''}`
        : 'server: no report',
      server?.plan && `file: ${server.plan.container} ${server.plan.videoCodec}/${server.plan.audioCodec} (copy ${server.plan.videoCopy ? 'yes' : 'no'})`,
      server?.lastError && `ffmpeg: ${server.lastError}`,
      '',
      ...trace.slice(-14),
    ].filter((l) => l !== null && l !== undefined && l !== false);

    showFallback(`Nothing has played after ${SILENCE_MS / 1000} seconds. What happened:`);
    const panel = $('#watch-fallback-note');
    panel.classList.add('watch-trace');
    Object.assign(panel.style, { whiteSpace: 'pre-wrap', fontFamily: 'ui-monospace, monospace', fontSize: '11px' });
    panel.textContent = lines.join('\n');
    panel.hidden = false;
  }, SILENCE_MS);
}

// ----------------------------------------------------------- audio tracks

function renderAudioMenu(gen) {
  const wrap = $('#watch-audio-wrap');
  const select = $('#watch-audio');
  const { session, player } = state;
  select.replaceChildren();
  select.onchange = null;
  wrap.hidden = true;
  if (isStale(gen)) return;

  // Converting: ffmpeg maps whichever stream we ask for.
  if (session?.mode === 'hls' && session.tracks.length > 1) {
    for (const track of session.tracks) select.append(option(String(track.index), track.label));
    select.value = String(session.audio);
    select.onchange = () => {
      setStatus('Switching audio track…');
      play(state.index, { audio: Number(select.value), resumeAt: player.currentTime() || 0 });
    };
    wrap.hidden = false;
    return;
  }

  // Restreaming: only offer what the browser genuinely exposes.
  const tracks = player.audioTracks?.();
  if (tracks && tracks.length > 1) {
    for (let i = 0; i < tracks.length; i += 1) {
      select.append(option(String(i), tracks[i].label || tracks[i].language || `Track ${i + 1}`));
      if (tracks[i].enabled) select.value = String(i);
    }
    select.onchange = () => {
      for (let i = 0; i < tracks.length; i += 1) tracks[i].enabled = String(i) === select.value;
    };
    wrap.hidden = false;
  }
}

function option(value, label) {
  const el = document.createElement('option');
  el.value = value;
  el.textContent = label;
  return el;
}

// -------------------------------------------------------------- subtitles

// One subtitle track at a time: the menu's choice if there is one, else the
// item's own, else nothing. Called after every source change so tracks never
// pile up across episodes or audio switches.
function syncSubtitles() {
  const { player } = state;
  if (!player) return;
  const tracks = player.remoteTextTracks();
  for (let i = tracks.length - 1; i >= 0; i -= 1) player.removeRemoteTextTrack(tracks[i]);
  if (state.subtitlesOff) return;

  const chosen = state.subtitle || (current()?.subtitle && { url: current().subtitle, label: 'Addon subtitles' });
  if (!chosen) return;
  player.addRemoteTextTrack({ kind: 'subtitles', src: chosen.url, label: chosen.label, default: true }, false);
}

async function loadSubtitleMenu() {
  const wrap = $('#watch-subs-wrap');
  const select = $('#watch-subs');
  wrap.hidden = true;
  const { type, id } = state.ticket;
  if (!type || !id) return;

  let available = [];
  try {
    available = await request(`/api/subtitles/${encodeURIComponent(type)}/${encodeURIComponent(id)}`);
  } catch { return; }
  if (!Array.isArray(available) || !available.length) return;

  select.replaceChildren(option('', 'Off'), option('__item', 'Default'));
  available.forEach((sub, i) => {
    select.append(option(String(i), `${sub.label}${sub.addon ? ` · ${sub.addon}` : ''}`));
  });
  select.value = '__item';

  select.onchange = () => {
    state.subtitlesOff = select.value === '';
    state.subtitle = /^\d+$/.test(select.value)
      ? { url: available[Number(select.value)].url, label: select.selectedOptions[0].textContent }
      : null;
    syncSubtitles();
  };
  wrap.hidden = false;
}

// ----------------------------------------------------------------- queue

function renderQueue() {
  const list = $('#watch-queue');
  list.replaceChildren(...state.ticket.items.map((item, i) => {
    const row = document.createElement('button');
    row.className = 'queue-item';
    const num = document.createElement('span');
    num.className = 'queue-num';
    num.textContent = String(i + 1);
    const title = document.createElement('span');
    title.className = 'queue-title';
    title.textContent = item.title;
    row.append(num, title);
    row.addEventListener('click', () => play(i));
    return row;
  }));
  markQueue();
}

function markQueue() {
  [...$('#watch-queue').children].forEach((row, i) => {
    row.setAttribute('aria-current', String(i === state.index));
  });
}

// -------------------------------------------------------- external player

async function useExternalPlayer() {
  const item = current();
  if (!item?.transcodeKey) {
    showFallback('This server has no restreaming for that file, so it can’t be handed to another player.');
    return;
  }
  const gen = ++state.gen;
  setStatus('Handing the stream to OnlinePlayer…');

  let reply;
  try {
    reply = await post('/api/transcode/start', { u: item.transcodeKey.u, s: item.transcodeKey.s, forceDirect: true });
  } catch (err) {
    if (!isStale(gen)) showFallback(err.message);
    return;
  }
  if (isStale(gen)) return;
  if (reply.mode !== 'direct') {
    if (reply.sid) post(`/api/transcode/stop/${reply.sid}`).catch(() => {});
    showFallback('This file has to be converted first, and a converted stream can only be played here.');
    return;
  }

  rememberPosition();
  state.player?.pause();
  stopSession();
  hideFallback();
  setStatus('Playing in OnlinePlayer. The stream link has been shared with that site.');

  const frame = $('#watch-external');
  const absolute = new URL(reply.url, location.origin).href;
  frame.src = `${EXTERNAL_PLAYER}?${new URLSearchParams({ autoload: absolute, theme: 'dark' })}`;
  frame.hidden = false;
}

function closeExternalPlayer() {
  const frame = $('#watch-external');
  if (frame.hidden) return;
  frame.hidden = true;
  frame.removeAttribute('src');
}

// --------------------------------------------------------- when it fails

function hideFallback() {
  $('#watch-fallback').hidden = true;
  $('#watch-fallback-note').hidden = true;
}

function showFallback(message) {
  clearSilence();
  setStatus('');
  $('#watch-fallback-message').textContent = message;
  $('#watch-fallback-note').hidden = true;
  const actions = $('#watch-fallback-actions');
  actions.replaceChildren();

  const item = current();
  action(actions, 'Try again', () => play(state.index), true);
  if (item?.transcodeKey && state.session?.mode !== 'hls') {
    action(actions, 'Convert it', () => play(state.index, { forceTranscode: true }));
  }
  action(actions, 'Open in VLC', () => { location.href = `/playlist/${state.token}.m3u?dl=1`; });
  if (device.os === 'android' && item) {
    action(actions, 'Choose an app', () => {
      const link = new URL(playLink('/play', { url: item.url, title: item.title }), location.origin);
      link.searchParams.set('target', 'player-chooser');
      location.href = link.pathname + link.search;
    });
  }
  if (location.protocol === 'https:' && item?.transcodeKey) action(actions, 'Try OnlinePlayer', useExternalPlayer);
  action(actions, 'Copy stream link', copyLink);

  $('#watch-fallback').hidden = false;
}

function action(parent, label, handler, primary = false) {
  const button = document.createElement('button');
  button.className = primary ? 'btn-primary' : 'btn-ghost';
  button.textContent = label;
  button.addEventListener('click', handler);
  parent.append(button);
}

async function copyLink() {
  const url = current()?.url;
  if (!url) return;
  try {
    await navigator.clipboard.writeText(url);
    setStatus('Stream link copied. In VLC: File → Open Network Stream.');
  } catch {
    setStatus(url);
  }
}

// ------------------------------------------------------------- positions

function rememberPosition() {
  const { player, ticket } = state;
  if (!player || !ticket || player.isDisposed?.()) return;
  const at = player.currentTime() || 0;
  const total = state.session?.duration || player.duration() || 0;
  if (at < MIN_RESUME_S) return;
  if (total && Number.isFinite(total) && at > total - END_MARGIN_S) storage.clear(state.index);
  else storage.set(state.index, at);
}

// -------------------------------------------------------------- keyboard

function onKey(event) {
  if ($('#screen-watch').hidden || !state.ticket || !state.player) return;
  if (event.ctrlKey || event.metaKey || event.altKey) return;
  if (/^(INPUT|SELECT|TEXTAREA|BUTTON)$/.test(document.activeElement?.tagName || '') && event.key === ' ') return;
  if (/^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement?.tagName || '')) return;

  const { player } = state;
  const step = event.shiftKey ? 30 : 10;
  const seekBy = (d) => seekWithin(Math.max(0, (player.currentTime() || 0) + d));
  const last = state.ticket.items.length - 1;

  switch (event.key) {
    case ' ':
    case 'k':
      if (player.paused()) player.play()?.catch?.(() => {}); else player.pause();
      break;
    case 'j': case 'ArrowLeft': seekBy(-step); break;
    case 'l': case 'ArrowRight': seekBy(step); break;
    case 'f':
      if (player.isFullscreen()) player.exitFullscreen(); else player.requestFullscreen();
      break;
    case 'm': player.muted(!player.muted()); break;
    case 'n': if (state.index < last) play(state.index + 1); break;
    case 'p': if (state.index > 0) play(state.index - 1); break;
    case 'Escape':
      if (player.isFullscreen() || document.fullscreenElement) return;
      $('#watch-back').click();
      break;
    default: return;
  }
  event.preventDefault();
}
