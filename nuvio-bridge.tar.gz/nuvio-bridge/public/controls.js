// The player's own controls, drawn over the picture on every device.
//
// Everything a viewer touches lives here: play/pause, the seek bar, skip,
// volume, fullscreen, picture-in-picture, and the audio, subtitle and episode
// menus. player.js still owns *what* plays; this only drives the <video> and
// the two hidden <select>s player.js keeps as the source of truth for tracks
// (choosing from a menu sets the select and fires its onchange, exactly as the
// old dropdowns did).

const $ = (s, root = document) => root.querySelector(s);
const HIDE_AFTER_MS = 3000;
const SKIP_S = 10;

let video;
let stage;
let hideTimer = null;
let seeking = false;
let hooks = { prev: () => {}, next: () => {} };

function fmt(seconds) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const s = Math.floor(seconds % 60);
  const m = Math.floor((seconds / 60) % 60);
  const h = Math.floor(seconds / 3600);
  const mm = h ? String(m).padStart(2, '0') : String(m);
  return `${h ? `${h}:` : ''}${mm}:${String(s).padStart(2, '0')}`;
}

// --------------------------------------------------------- visibility

function menuOpen() {
  return !$('#watch-menu').hidden || !$('#watch-queue-wrap').hidden;
}

export function showUi() {
  stage.classList.add('show-ui');
  clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    if (!video.paused && !seeking && !menuOpen()) {
      stage.classList.remove('show-ui');
    }
  }, HIDE_AFTER_MS);
}

function hideUi() {
  if (video.paused || menuOpen()) return;
  clearTimeout(hideTimer);
  stage.classList.remove('show-ui');
}

// ------------------------------------------------------------ playback

function togglePlay() {
  if (video.paused) video.play()?.catch?.(() => {});
  else video.pause();
}

function syncPlayState() {
  const paused = video.paused;
  stage.classList.toggle('is-paused', paused);
  $('#watch-play').setAttribute('aria-label', paused ? 'Play' : 'Pause');
  if (paused) showUi();
}

function syncTime() {
  const duration = Number.isFinite(video.duration) ? video.duration : 0;
  $('#watch-duration').textContent = fmt(duration);
  if (seeking) return;
  const at = video.currentTime || 0;
  $('#watch-time').textContent = fmt(at);
  const seek = $('#watch-seek');
  seek.value = duration ? String(Math.round((at / duration) * 1000)) : '0';
  paintSeek();
}

// Played portion and buffered portion, painted as one gradient.
function paintSeek() {
  const seek = $('#watch-seek');
  const duration = Number.isFinite(video.duration) ? video.duration : 0;
  const played = (Number(seek.value) / 10);
  let buffered = played;
  if (duration && video.buffered?.length) {
    for (let i = 0; i < video.buffered.length; i += 1) {
      if (video.buffered.start(i) <= video.currentTime + 0.5) {
        buffered = Math.max(buffered, (video.buffered.end(i) / duration) * 100);
      }
    }
  }
  seek.style.setProperty('--played', `${played}%`);
  seek.style.setProperty('--buffered', `${Math.min(100, buffered)}%`);
}

function skip(seconds) {
  const duration = Number.isFinite(video.duration) ? video.duration : Infinity;
  video.currentTime = Math.max(0, Math.min(duration - 1, (video.currentTime || 0) + seconds));
  showUi();
}

function syncVolume() {
  $('#watch-mute').classList.toggle('is-muted', video.muted || video.volume === 0);
  $('#watch-volume').value = String(video.muted ? 0 : video.volume);
}

// ----------------------------------------------------------- fullscreen

function fullscreenElement() {
  return document.fullscreenElement || document.webkitFullscreenElement;
}

export function toggleFullscreen() {
  if (fullscreenElement()) {
    (document.exitFullscreen || document.webkitExitFullscreen)?.call(document);
    return;
  }
  // The stage, not the video, so the controls and menus come along.
  const request = stage.requestFullscreen || stage.webkitRequestFullscreen;
  if (request) {
    Promise.resolve(request.call(stage)).then(() => {
      // Phones: turn sideways for a landscape film, where the browser allows.
      screen.orientation?.lock?.('landscape').catch(() => {});
    }).catch(() => video.webkitEnterFullscreen?.());
  } else {
    // iPhone Safari only allows the video itself to go fullscreen.
    video.webkitEnterFullscreen?.();
  }
}

// ----------------------------------------------------------------- menus

function closeMenus() {
  $('#watch-menu').hidden = true;
  $('#watch-queue-wrap').hidden = true;
  for (const id of ['#watch-source-btn', '#watch-audio-btn', '#watch-subs-btn', '#watch-queue-btn']) {
    $(id).setAttribute('aria-expanded', 'false');
  }
}

// The options menu: one panel with a section per hidden select player.js
// keeps — Source, Audio, Subtitles — each a list of choices. Picking one sets
// that select and fires its onchange, which is where player.js acts on it.
const SECTIONS = [
  ['#watch-source-wrap', '#watch-source', 'Source', 'Looking for other sources…'],
  ['#watch-audio-wrap', '#watch-audio', 'Audio', 'This file has one audio track.'],
  ['#watch-subs-wrap', '#watch-subs', 'Subtitles', 'No subtitles found for this one.'],
];

// Each button opens its own section. The buttons are always there, so the
// controls never move around; a section with nothing to pick says so.
function openOptionsMenu(button, only) {
  const menu = $('#watch-menu');
  const wasOpen = !menu.hidden && menu.dataset.for === only;
  closeMenus();
  if (wasOpen) return;

  const parts = [];
  for (const [wrap, selectId, title, empty] of SECTIONS) {
    if (only && title !== only) continue;
    const select = $(selectId);
    if ($(wrap).hidden || !select.options.length) {
      const heading = document.createElement('h2');
      heading.className = 'watch-menu-title';
      heading.textContent = title;
      const note = document.createElement('p');
      note.className = 'watch-menu-empty';
      note.textContent = title === 'Audio' && $('#watch-audio').options.length === 0 && !$('#watch-video').currentSrc
        ? 'Tracks appear once the video starts.' : empty;
      parts.push(heading, note);
      continue;
    }

    const heading = document.createElement('h2');
    heading.className = 'watch-menu-title';
    heading.textContent = title;
    const list = document.createElement('div');
    list.className = 'watch-menu-list';

    for (const option of select.options) {
      const item = document.createElement('button');
      item.className = 'watch-menu-item';
      item.setAttribute('role', 'menuitemradio');
      item.setAttribute('aria-checked', String(option.value === select.value));
      item.disabled = option.disabled;
      const label = document.createElement('span');
      label.className = 'watch-menu-label';
      label.textContent = option.textContent;
      item.append(label);
      if (option.dataset.detail) {
        const detail = document.createElement('span');
        detail.className = 'watch-menu-detail';
        detail.textContent = option.dataset.detail;
        item.append(detail);
      }
      item.addEventListener('click', () => {
        closeMenus();
        if (select.value === option.value) return;
        select.value = option.value;
        select.onchange?.();
      });
      list.append(item);
    }
    parts.push(heading, list);
  }

  if (!parts.length) {
    const empty = document.createElement('p');
    empty.className = 'watch-menu-empty';
    empty.textContent = 'Nothing to choose for this one.';
    parts.push(empty);
  }

  menu.replaceChildren(...parts);
  menu.dataset.for = only || '';
  menu.hidden = false;
  button.setAttribute('aria-expanded', 'true');
  menu.querySelector('[aria-checked="true"]')?.focus({ preventScroll: true });
  showUi();
}

function toggleQueue() {
  const panel = $('#watch-queue-wrap');
  const opening = panel.hidden;
  closeMenus();
  if (!opening) return;
  panel.hidden = false;
  $('#watch-queue-btn').setAttribute('aria-expanded', 'true');
  panel.querySelector('[aria-current="true"]')?.scrollIntoView({ block: 'center' });
  showUi();
}

// The options button lights up while subtitles are on.
function watchAvailability() {
  const sync = () => {
    $('#watch-subs-btn').classList.toggle('is-on', Boolean($('#watch-subs').value) && !$('#watch-subs-wrap').hidden);
  };
  const observer = new MutationObserver(sync);
  observer.observe($('#watch-subs'), { childList: true });
  observer.observe($('#watch-subs-wrap'), { attributes: true, attributeFilter: ['hidden'] });
  $('#watch-subs').addEventListener('change', sync);
  sync();
  return sync;
}

// ------------------------------------------------------------------ setup

/**
 * @param {HTMLVideoElement} el
 * @param {{ prev: () => void, next: () => void }} navigation
 */
export function attach(el, navigation) {
  video = el;
  stage = $('#watch-stage');
  hooks = { ...hooks, ...navigation };
  video.controls = false;

  // Playback
  $('#watch-play').addEventListener('click', togglePlay);
  $('#watch-rew').addEventListener('click', () => skip(-SKIP_S));
  $('#watch-fwd').addEventListener('click', () => skip(SKIP_S));
  $('#watch-prev').addEventListener('click', () => hooks.prev());
  $('#watch-next').addEventListener('click', () => hooks.next());

  // The picture: a click plays or pauses; on touch the first tap brings the
  // controls up and a tap while they're up plays or pauses. Double-click is
  // fullscreen, as in every desktop player.
  const tap = $('#watch-tap');
  tap.addEventListener('click', (event) => {
    if (menuOpen()) { closeMenus(); return; }
    if (event.pointerType === 'touch' || matchMedia('(hover: none)').matches) {
      if (!stage.classList.contains('show-ui')) { showUi(); return; }
    }
    togglePlay();
    showUi();
  });
  tap.addEventListener('dblclick', toggleFullscreen);

  // Seeking: preview the time while dragging, seek on release.
  const seek = $('#watch-seek');
  seek.addEventListener('input', () => {
    seeking = true;
    const duration = Number.isFinite(video.duration) ? video.duration : 0;
    $('#watch-time').textContent = fmt((Number(seek.value) / 1000) * duration);
    paintSeek();
    showUi();
  });
  seek.addEventListener('change', () => {
    const duration = Number.isFinite(video.duration) ? video.duration : 0;
    if (duration) video.currentTime = (Number(seek.value) / 1000) * duration;
    seeking = false;
    showUi();
  });

  // Volume
  $('#watch-mute').addEventListener('click', () => {
    if (video.muted || video.volume === 0) {
      video.muted = false;
      if (video.volume === 0) video.volume = 0.5;
    } else {
      video.muted = true;
    }
  });
  $('#watch-volume').addEventListener('input', (event) => {
    video.volume = Number(event.target.value);
    video.muted = video.volume === 0;
  });

  // Menus
  $('#watch-source-btn').addEventListener('click', (e) => openOptionsMenu(e.currentTarget, 'Source'));
  $('#watch-audio-btn').addEventListener('click', (e) => openOptionsMenu(e.currentTarget, 'Audio'));
  $('#watch-subs-btn').addEventListener('click', (e) => openOptionsMenu(e.currentTarget, 'Subtitles'));
  $('#watch-queue-btn').addEventListener('click', toggleQueue);
  $('#watch-queue').addEventListener('click', () => closeMenus());
  watchAvailability();

  // Fullscreen and picture-in-picture
  $('#watch-fullscreen').addEventListener('click', toggleFullscreen);
  const onFullscreen = () => stage.classList.toggle('is-fullscreen', Boolean(fullscreenElement()));
  document.addEventListener('fullscreenchange', onFullscreen);
  document.addEventListener('webkitfullscreenchange', onFullscreen);
  if (document.pictureInPictureEnabled || video.webkitSupportsPresentationMode) {
    const pip = $('#watch-pip');
    pip.hidden = false;
    pip.addEventListener('click', () => {
      if (document.pictureInPictureElement) document.exitPictureInPicture().catch(() => {});
      else if (video.requestPictureInPicture) video.requestPictureInPicture().catch(() => {});
      else video.webkitSetPresentationMode?.('picture-in-picture');
    });
  }

  // State from the video itself
  video.addEventListener('play', syncPlayState);
  video.addEventListener('pause', syncPlayState);
  video.addEventListener('timeupdate', syncTime);
  video.addEventListener('durationchange', syncTime);
  video.addEventListener('progress', paintSeek);
  video.addEventListener('volumechange', syncVolume);
  video.addEventListener('emptied', () => { syncTime(); syncPlayState(); });
  const spinner = $('#watch-spinner');
  video.addEventListener('waiting', () => { spinner.hidden = false; });
  video.addEventListener('loadstart', () => { spinner.hidden = false; });
  for (const done of ['playing', 'canplay', 'pause', 'error', 'emptied']) {
    video.addEventListener(done, () => { spinner.hidden = true; });
  }

  // Controls come up with any movement and fade after a few idle seconds.
  stage.addEventListener('mousemove', showUi);
  stage.addEventListener('mouseleave', hideUi);
  stage.addEventListener('focusin', showUi);
  document.addEventListener('keydown', (event) => {
    if ($('#screen-watch').hidden) return;
    if (event.key === 'Escape' && menuOpen()) {
      event.stopImmediatePropagation();
      closeMenus();
      return;
    }
    showUi();
  }, true);

  syncPlayState();
  syncVolume();
  syncTime();
}

export { closeMenus };
