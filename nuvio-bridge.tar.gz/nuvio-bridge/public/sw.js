// The service worker exists so the app can be installed — Android and desktop
// Chrome will not offer "Install" without one. What it does deliberately is
// very little.
//
// Only the shell is cached: the HTML, the scripts, the stylesheet, the icons.
// Nothing under /api is ever stored, because it is somebody's library and
// their sign-in state. Nothing under /play, /playlist, /media or /sub.vtt is
// ever stored either, because those resolve to debrid links that are
// single-use as often as not — a cached one is a link that has already been
// spent.

const CACHE = 'nuvio-shell-v50';

const SHELL = [
  '/',
  '/index.html',
  '/style.css?v=50',
  '/app.js?v=50',
  '/platform.js',
  '/player.js',
  '/manifest.webmanifest',
  '/icons/icon.svg',
  '/icons/icon-192.png',
  // The player library. Worth caching: it is the largest thing the app
  // loads, and it is needed every time anything is played.
  '/vendor/video.min.js',
  '/vendor/video-js.min.css',
];

const NEVER_CACHE = /^\/(api|play|playlist|media|hls|sub\.vtt|healthz|watch)/;

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE)
      // One missing file shouldn't fail the whole install, so they're added
      // individually rather than with addAll.
      .then((cache) => Promise.all(SHELL.map((url) => cache.add(url).catch(() => {}))))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((names) => Promise.all(names.filter((n) => n !== CACHE).map((n) => caches.delete(n))))
      .then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== location.origin) return;
  if (NEVER_CACHE.test(url.pathname)) return;

  // Navigations go to the network first so a new build is picked up on the
  // next load; the cached shell is only there for when the network isn't.
  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request).catch(() => caches.match('/index.html')),
    );
    return;
  }

  event.respondWith(
    caches.match(request).then((hit) => hit || fetch(request).then((response) => {
      if (response.ok) {
        const copy = response.clone();
        caches.open(CACHE).then((cache) => cache.put(request, copy));
      }
      return response;
    })),
  );
});
