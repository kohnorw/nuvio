// The OpenSubtitles file hash, worked out from two small range requests.
//
// Subtitle addons can only guess which cut of a film a subtitle belongs to from
// its name. A hash removes the guess: it is computed from the file's size and
// its first and last 64 KB, so it identifies one exact file, and a subtitle
// matched on it was timed against that file. That is the single biggest cause
// of "the subtitles are out of sync" — a perfectly good subtitle for a
// different release, a few seconds (or a whole intro) adrift.
//
// The hash is size + the sum of every little-endian 64-bit word in those two
// chunks, modulo 2^64. Nothing here downloads the film: two 64 KB ranges.
//
// SUBTITLE_HASH=false turns it off, for debrid providers whose links are
// single-use and can't spare even two small requests.

const CHUNK = 65536;
const TIMEOUT_MS = Number(process.env.SUBTITLE_HASH_TIMEOUT_MS || 8000);
const ENABLED = process.env.SUBTITLE_HASH !== 'false';
const TTL_MS = 6 * 60 * 60 * 1000;

const cache = new Map();

export const enabled = ENABLED;

function sumWords(buffer, seed) {
  let hash = seed;
  const mask = (1n << 64n) - 1n;
  const words = Math.floor(buffer.length / 8);
  const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
  for (let i = 0; i < words; i += 1) {
    hash = (hash + view.getBigUint64(i * 8, true)) & mask;
  }
  return hash;
}

async function range(url, start, end) {
  const res = await fetch(url, {
    redirect: 'follow',
    headers: { range: `bytes=${start}-${end}`, 'user-agent': 'Mozilla/5.0' },
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  if (res.status !== 206 && res.status !== 200) throw new Error(`range refused (${res.status})`);
  const bytes = new Uint8Array(await res.arrayBuffer());
  const total = Number(/\/(\d+)\s*$/.exec(res.headers.get('content-range') || '')?.[1]) || null;
  return { bytes, total, partial: res.status === 206 };
}

async function compute(url) {
  const head = await range(url, 0, CHUNK - 1);
  // A host that ignores ranges answers 200 with the whole file. Nothing useful
  // can be done with that here, and reading it would defeat the point.
  if (!head.partial || !head.total || head.total < CHUNK * 2) return null;

  const tail = await range(url, head.total - CHUNK, head.total - 1);
  if (!tail.partial || tail.bytes.length !== CHUNK || head.bytes.length !== CHUNK) return null;

  let hash = BigInt(head.total);
  hash = sumWords(head.bytes, hash);
  hash = sumWords(tail.bytes, hash);
  return { hash: hash.toString(16).padStart(16, '0'), size: head.total };
}

/**
 * @returns {Promise<{hash: string, size: number} | null>} null when the host
 *   can't be ranged, or hashing is off; never throws.
 */
export async function forUrl(url) {
  if (!ENABLED || !/^https?:/i.test(String(url))) return null;

  const hit = cache.get(url);
  if (hit && hit.until > Date.now()) return hit.value;

  const value = await compute(url).catch(() => null);
  cache.set(url, { value, until: Date.now() + (value ? TTL_MS : 5 * 60 * 1000) });
  if (cache.size > 200) cache.delete(cache.keys().next().value);
  return value;
}
