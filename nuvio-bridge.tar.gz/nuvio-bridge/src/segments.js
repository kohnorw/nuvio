// Where the intro, the recap and the credits are, for the skip buttons.
//
// Nothing in a video file says where its opening titles end, so the answer
// comes from people who watched it: three community databases hold timestamps
// keyed by IMDb id, season and episode.
//
//   IntroDB      api.introdb.app      intro, recap, outro, post-credits
//   TheIntroDB   api.theintrodb.org   intro, recap, credits, preview
//   SkipDB       api.skipdb.tv        intro, recap, outro, preview
//
// All three are asked at once and merged in that order: the first one to know
// a segment wins, and the others fill what it lacks. When none of them knows
// the episode, chapters inside the file ("Opening", "Credits") stand in — see
// fromChapters, used by the transcoder's probe.
//
// Nothing here is required. A title nobody has timed simply gets no buttons.
//
//   SKIP_SEGMENTS=false      turn the lookups off
//   THEINTRODB_API_KEY       optional; only needed for higher rate limits

const ENABLED = process.env.SKIP_SEGMENTS !== 'false';
const TIMEOUT_MS = Number(process.env.SEGMENTS_TIMEOUT_MS || 6000);
const HIT_TTL_MS = 12 * 60 * 60 * 1000;
const MISS_TTL_MS = 30 * 60 * 1000;
const MIN_SECONDS = 3;

export const enabled = ENABLED;

const cache = new Map();

// Stremio ids: `tt0944947:1:2` for an episode, `tt0133093` for a film.
export function parseId(type, id) {
  const [imdb, season, episode] = String(id || '').split(':');
  if (!/^tt\d+$/.test(imdb || '')) return null;
  if (type === 'series') {
    const s = Number(season);
    const e = Number(episode);
    if (!Number.isInteger(s) || !Number.isInteger(e) || e < 1) return null;
    return { imdb, season: s, episode: e, movie: false };
  }
  return { imdb, season: null, episode: null, movie: true };
}

function range(startSec, endSec, duration) {
  const start = Number.isFinite(startSec) ? Math.max(0, startSec) : 0;
  const end = Number.isFinite(endSec) ? endSec : (duration > 0 ? duration : null);
  if (end === null || end - start < MIN_SECONDS) return null;
  return { start, end };
}

const fromMs = (item, duration) => (item && typeof item === 'object'
  ? range(item.start_ms == null ? 0 : item.start_ms / 1000,
    item.end_ms == null ? null : item.end_ms / 1000, duration)
  : null);

// IntroDB has answered in seconds and in milliseconds at different times.
const fromEither = (item, duration) => {
  if (!item || typeof item !== 'object') return null;
  const s = item.start_sec ?? (item.start_ms == null ? 0 : item.start_ms / 1000);
  const e = item.end_sec ?? (item.end_ms == null ? null : item.end_ms / 1000);
  return range(s, e, duration);
};

// TheIntroDB answers each type with a list; the first usable entry is used.
const firstOf = (list, duration) => {
  for (const item of Array.isArray(list) ? list : []) {
    const r = fromMs(item, duration);
    if (r) return r;
  }
  return null;
};

async function getJson(url, headers = {}) {
  const res = await fetch(url, {
    headers: { accept: 'application/json', 'user-agent': 'nuvio-bridge', ...headers },
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  if (!res.ok) throw new Error(`${res.status}`);
  return res.json();
}

const providers = {
  async introdb(ref, duration) {
    const url = ref.movie
      ? `https://api.introdb.app/segments?imdb_id=${ref.imdb}&is_movie=true`
      : `https://api.introdb.app/segments?imdb_id=${ref.imdb}&season=${ref.season}&episode=${ref.episode}`;
    const data = await getJson(url);
    return {
      intro: fromEither(data.intro, duration),
      recap: fromEither(data.recap, duration),
      credits: fromEither(data.outro, duration),
    };
  },

  async theintrodb(ref, duration) {
    const params = [`imdb_id=${ref.imdb}`];
    if (!ref.movie) params.push(`season=${ref.season}`, `episode=${ref.episode}`);
    if (duration > 0) params.push(`duration_ms=${Math.round(duration * 1000)}`);
    const key = process.env.THEINTRODB_API_KEY;
    const data = await getJson(`https://api.theintrodb.org/v3/media?${params.join('&')}`,
      key ? { authorization: `Bearer ${key}` } : {});
    return {
      intro: firstOf(data.intro, duration),
      recap: firstOf(data.recap, duration),
      credits: firstOf(data.credits, duration),
    };
  },

  async skipdb(ref, duration) {
    let url = `https://api.skipdb.tv/api/segments?imdb_id=${ref.imdb}`;
    if (!ref.movie) url += `&season=${ref.season}&episode=${ref.episode}`;
    if (duration > 0) url += `&duration=${Math.floor(duration)}`;
    const data = await getJson(url);
    const segs = data.segments || {};
    return {
      intro: fromMs(segs.intro, duration),
      recap: fromMs(segs.recap, duration),
      credits: fromMs(segs.outro, duration),
    };
  },
};

const ORDER = ['introdb', 'theintrodb', 'skipdb'];
const KINDS = ['intro', 'recap', 'credits'];

/**
 * @returns {Promise<{intro, recap, credits}>} each `{start, end}` in seconds,
 *   or null. Never throws: no answer is a normal answer.
 */
export async function lookup(type, id, duration = 0) {
  const empty = { intro: null, recap: null, credits: null };
  if (!ENABLED) return empty;
  const ref = parseId(type, id);
  if (!ref) return empty;

  const key = `${type}:${id}`;
  const hit = cache.get(key);
  if (hit && hit.until > Date.now()) return hit.value;

  const settled = await Promise.allSettled(ORDER.map((name) => providers[name](ref, duration)));
  const merged = { ...empty };
  for (const result of settled) {
    if (result.status !== 'fulfilled') continue;
    for (const kind of KINDS) {
      if (!merged[kind] && result.value[kind]) merged[kind] = result.value[kind];
    }
  }

  const found = KINDS.some((kind) => merged[kind]);
  // A failure of every provider is not the same as "nobody has timed this",
  // and caching it as one would hide segments for half an hour over a blip.
  const allFailed = settled.every((r) => r.status === 'rejected');
  if (!allFailed) {
    cache.set(key, { value: merged, until: Date.now() + (found ? HIT_TTL_MS : MISS_TTL_MS) });
    if (cache.size > 500) cache.delete(cache.keys().next().value);
  }
  return merged;
}

// ------------------------------------------------------------- chapters

const CHAPTER_WORDS = {
  intro: /\b(intro|introduction|opening|op|theme|title sequence|main titles?)\b/i,
  recap: /\b(recap|previously)\b/i,
  credits: /\b(credits|end credits|ending|outro|ed|closing)\b/i,
};

/**
 * Stand-ins for the databases: chapters the file itself carries. Blu-ray and
 * anime releases usually name them. `chapters` is ffprobe's list, already
 * shifted onto the player's clock.
 */
export function fromChapters(chapters, duration = 0) {
  const out = { intro: null, recap: null, credits: null };
  const list = (chapters || [])
    .filter((c) => Number.isFinite(c.start) && Number.isFinite(c.end) && c.end > c.start)
    .sort((a, b) => a.start - b.start);

  for (const chapter of list) {
    const length = chapter.end - chapter.start;
    const title = String(chapter.title || '').replace(/[_.\-–—:]+/g, ' ');
    for (const kind of KINDS) {
      if (out[kind] || !CHAPTER_WORDS[kind].test(title)) continue;
      // A "credits" chapter is only that if it is near the end; an "opening"
      // chapter only if it is near the start. Chapter names are loose.
      if (kind === 'credits' && duration > 0 && chapter.start < duration * 0.6) continue;
      if (kind === 'intro' && duration > 0 && chapter.start > duration * 0.5) continue;
      if (length < 10 || length > (kind === 'credits' ? 1200 : 400)) continue;
      out[kind] = { start: chapter.start, end: chapter.end };
    }
  }
  return out;
}

export function mergeInto(primary, fallback) {
  const out = { ...primary };
  for (const kind of KINDS) if (!out[kind] && fallback?.[kind]) out[kind] = fallback[kind];
  return out;
}
