// Making the unplayable playable, with ffmpeg.
//
// Browsers refuse MKV. Not the codecs inside it particularly — H.264 video is
// something every browser decodes happily — but the container, and the audio,
// which on a release is usually AC3, E-AC3 or DTS and which no browser has
// ever supported. So the file is nearly always playable; it is just wrapped
// and scored in ways the <video> element won't touch.
//
// That makes remuxing the common case and re-encoding the exception:
//
//   H.264 video  → copied through untouched. Costs almost no CPU.
//   HEVC / AV1   → re-encoded to H.264, which is expensive and the reason
//                  this is opt-in rather than the default.
//   AC3/DTS/etc  → re-encoded to AAC stereo. Cheap.
//
// Output is fragmented MP4 down a pipe, which a browser will start playing
// before it has the whole thing. The cost is that a pipe has no byte ranges,
// so seeking can't work the usual way — see `seek` handling in the player,
// which restarts ffmpeg at an offset instead.

import { spawn } from 'node:child_process';
import { once } from 'node:events';

export const enabled = process.env.TRANSCODE !== 'false';

// A transcode is the most expensive thing this container can be asked to do.
// On a small box two at once is already plenty, and an unbounded number is how
// a NAS falls over.
const MAX_CONCURRENT = Number(process.env.TRANSCODE_MAX || 2);
const PROBE_TIMEOUT_MS = Number(process.env.TRANSCODE_PROBE_TIMEOUT_MS || 20000);

let running = 0;
let available = null;

// Codecs a browser can be handed as-is inside an MP4. Everything else has to
// be re-encoded, and knowing which is which is the difference between using
// no CPU and using all of it.
const VIDEO_PASSTHROUGH = new Set(['h264', 'avc1']);
const AUDIO_PASSTHROUGH = new Set(['aac', 'mp3']);

// Whether ffmpeg is actually in the image. Checked once at startup rather
// than per request, and cached — including the negative answer, so a build
// without ffmpeg doesn't spawn a doomed process on every play.
export async function detect() {
  if (available !== null) return available;
  if (!enabled) { available = false; return false; }

  try {
    const child = spawn('ffmpeg', ['-version'], { stdio: 'ignore' });
    const [code] = await once(child, 'close');
    available = code === 0;
  } catch {
    available = false;
  }
  return available;
}

export function isAvailable() {
  return available === true;
}

export function busy() {
  return running >= MAX_CONCURRENT;
}

// What is actually inside the file, so the command can copy what it can and
// only re-encode what it must. Also returns the duration, which is what lets
// the player draw a real timeline for something it is being fed down a pipe.
export async function inspect(url) {
  const args = [
    '-v', 'quiet',
    '-print_format', 'json',
    '-show_format',
    '-show_streams',
    '-analyzeduration', '10M',
    '-probesize', '10M',
    url,
  ];

  const child = spawn('ffprobe', args, { stdio: ['ignore', 'pipe', 'ignore'] });
  const timer = setTimeout(() => child.kill('SIGKILL'), PROBE_TIMEOUT_MS);

  let out = '';
  child.stdout.on('data', (chunk) => { out += chunk; });

  try {
    const [code] = await once(child, 'close');
    if (code !== 0 || !out) return null;

    const data = JSON.parse(out);
    const video = (data.streams || []).find((s) => s.codec_type === 'video');
    const audioStreams = (data.streams || []).filter((s) => s.codec_type === 'audio');
    const audio = audioStreams[0];

    return {
      duration: Math.floor(Number(data.format?.duration) || 0) || null,
      videoCodec: video?.codec_name || null,
      audioCodec: audio?.codec_name || null,
      // Copying video is the difference between a transcode a Raspberry Pi
      // can do and one it can't, so the client is told which it is getting.
      videoCopy: VIDEO_PASSTHROUGH.has(String(video?.codec_name)),
      audioCopy: AUDIO_PASSTHROUGH.has(String(audio?.codec_name)),
      // Dual-audio releases are common and a browser gives no way to choose
      // between tracks, so the choice is made here instead: ffmpeg is told
      // which stream to map and the rest are dropped.
      audioTracks: audioStreams.map((stream, order) => ({
        index: order,
        codec: stream.codec_name || null,
        channels: stream.channels || null,
        lang: stream.tags?.language || null,
        title: stream.tags?.title || null,
        label: audioLabel(stream, order),
        default: stream.disposition?.default === 1,
      })),
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

// What to call a track in a menu. A release's own title is the most useful
// thing when it has one — "Commentary", "English 5.1" — falling back to the
// language and channel count.
function audioLabel(stream, order) {
  const language = stream.tags?.language ? String(stream.tags.language).toUpperCase() : null;
  const layout = stream.channels === 6 ? '5.1'
    : stream.channels === 8 ? '7.1'
      : stream.channels === 2 ? 'Stereo'
        : stream.channels === 1 ? 'Mono' : null;

  const parts = [
    language,
    stream.tags?.title,
    layout,
    stream.codec_name ? String(stream.codec_name).toUpperCase() : null,
  ].filter(Boolean);

  return parts.length ? parts.join(' · ') : `Track ${order + 1}`;
}

function buildArgs(url, { start = 0, plan, audio = 0 }) {
  const args = ['-hide_banner', '-loglevel', 'error'];

  // -ss before -i seeks by jumping rather than by decoding everything up to
  // the point, which is the difference between instant and a minute.
  if (start > 0) args.push('-ss', String(start));

  args.push(
    '-user_agent', 'Mozilla/5.0',
    '-reconnect', '1',
    '-reconnect_streamed', '1',
    '-reconnect_delay_max', '5',
    '-i', url,
    '-map', '0:v:0',
    // `?` so a file with no audio at all still produces video rather than
    // failing outright.
    '-map', `0:a:${Math.max(0, Number(audio) || 0)}?`,
    '-sn', '-dn',
  );

  if (plan?.videoCopy) {
    args.push('-c:v', 'copy');
  } else {
    args.push(
      '-c:v', 'libx264',
      '-preset', process.env.TRANSCODE_PRESET || 'veryfast',
      '-crf', process.env.TRANSCODE_CRF || '23',
      '-profile:v', 'high',
      '-level', '4.1',
      '-pix_fmt', 'yuv420p',
      // A keyframe every two seconds keeps the fragments small enough that
      // playback starts quickly rather than after a long first fragment.
      '-g', '48',
    );
  }

  // Always AAC stereo. Even when the source is AAC it is often 5.1, which
  // some browsers will decode and then play out of the wrong channels.
  args.push('-c:a', 'aac', '-ac', '2', '-b:a', '192k');

  args.push(
    '-f', 'mp4',
    // empty_moov + frag_keyframe is what makes an MP4 streamable before it
    // is finished. Without them ffmpeg needs to seek back and write the index
    // at the end, which it cannot do into a pipe.
    '-movflags', 'frag_keyframe+empty_moov+default_base_moof',
    'pipe:1',
  );

  return args;
}

// Pipes converted video into the response. Returns when the process has been
// started; the response ends when ffmpeg does or when the client goes away.
export async function stream(url, req, res, { start = 0, plan = null, audio = 0 } = {}) {
  running += 1;

  const child = spawn('ffmpeg', buildArgs(url, { start, plan, audio }), {
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  let stderr = '';
  child.stderr.on('data', (chunk) => {
    // Kept only so a failure can be logged with a reason attached.
    if (stderr.length < 4000) stderr += chunk;
  });

  res.status(200);
  res.setHeader('content-type', 'video/mp4');
  // A pipe has no length and no ranges. Saying so plainly stops the browser
  // asking for a byte range it will never get.
  res.setHeader('accept-ranges', 'none');
  res.setHeader('cache-control', 'private, no-store');

  const cleanup = () => {
    running = Math.max(0, running - 1);
    if (!child.killed) child.kill('SIGKILL');
  };

  // Every seek in the player closes this request and opens a new one, so a
  // client hanging up is the normal case, not an error.
  res.on('close', cleanup);
  child.on('close', (code) => {
    running = Math.max(0, running - 1);
    if (code && code !== 255 && !res.writableEnded) {
      console.error(`ffmpeg exited ${code}: ${stderr.trim().slice(0, 500)}`);
    }
    if (!res.writableEnded) res.end();
  });

  child.stdout.on('error', cleanup);
  child.stdout.pipe(res);
}
