// Making the unplayable playable, with ffmpeg.
//
// Browsers refuse MKV. Not the codecs inside it particularly — H.264 video is
// something every browser decodes happily — but the container, and the audio,
// which on a release is usually AC3, E-AC3 or DTS and which no browser has
// ever supported. So the file is nearly always playable; it is just wrapped
// and scored in ways the <video> element won't touch.
//
// Output is HLS: ffmpeg writes numbered .ts segments and a playlist, and the
// browser fetches them like any other files. The obvious alternative — one
// long fragmented-MP4 response down a pipe — does not survive contact with
// real browsers. A pipe has no length and no byte ranges, so Chrome and
// Firefox variously refuse to start, refuse to seek, or stall partway, and
// when the process dies there is nothing to resume from. Segments on disk fix
// all three, because each one is an ordinary file with a size.
//
// What actually gets converted:
//
//   H.264 video  → copied through untouched. Costs almost no CPU.
//   HEVC / AV1   → re-encoded to H.264, which is expensive.
//   AC3/DTS/etc  → re-encoded to AAC stereo. Cheap.
//
// A session owns one ffmpeg process, one directory of segments, a watchdog
// that restarts a stalled encode, and a timer that cleans the whole thing up
// when the person closes the tab.

import { spawn } from 'node:child_process';
import { once } from 'node:events';
import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';

export const enabled = process.env.TRANSCODE !== 'false';

const MAX_SESSIONS = Number(process.env.TRANSCODE_MAX || 2);
// Shorter segments mean the first one is ready sooner, which is most of what
// "slow to start" actually is. Two seconds each, two of them, so playback
// begins on four seconds of video instead of twelve.
const SEGMENT_SECS = Number(process.env.TRANSCODE_SEGMENT_SECS || 2);
const PREBUFFER = Number(process.env.TRANSCODE_PREBUFFER || 2);
const PROBE_TIMEOUT_MS = Number(process.env.TRANSCODE_PROBE_TIMEOUT_MS || 20000);
const START_TIMEOUT_MS = Number(process.env.TRANSCODE_START_TIMEOUT_MS || 60000);
// No heartbeat for this long and the session is assumed abandoned. The player
// beats every ten seconds, so this is three missed beats.
const HEARTBEAT_MS = Number(process.env.TRANSCODE_HEARTBEAT_MS || 35000);
const STALL_MS = Number(process.env.TRANSCODE_STALL_MS || 20000);
const MAX_RESTARTS = 5;
// How much of the film to convert flat out before dropping to playback speed.
// Enough to start instantly and absorb a short seek; not so much that a film
// closed after a minute has written a gigabyte.
const BURST_SECS = Number(process.env.TRANSCODE_BURST_SECS || 120);

// How fast to convert once the burst is over, as a multiple of playback speed.
//
// This was 1, which is exactly the wrong number: converting at precisely the
// speed the film is watched leaves no headroom at all, so the player sits on
// the encoder's heels and any hiccup — a slow read from the host, a busy
// moment on the CPU — becomes a stall. At 1.6 the buffer grows by six seconds
// for every ten watched, which absorbs those without converting the whole film
// to disk for someone who watches five minutes.
const READRATE = process.env.TRANSCODE_READRATE || '1.6';

// -readrate_initial_burst arrived in ffmpeg 6. Without it the choice is
// between converting flat out (gigabytes for a film nobody finishes) and
// converting at playback speed from the first frame (a slow start), so it is
// worth knowing which is available rather than guessing.
let hasBurst = false;

// Segments live on disk for as long as the session does, and a film is
// gigabytes. STATE_DIR is a real volume; tmpfs on a small box is not where
// this belongs.
const HLS_ROOT = process.env.TRANSCODE_DIR
  || path.join(process.env.STATE_DIR || os.tmpdir(), 'hls');

// What ffmpeg can copy into an MP4 or MPEG-TS without re-encoding.
const VIDEO_PASSTHROUGH = new Set(['h264', 'avc1']);
const AUDIO_PASSTHROUGH = new Set(['aac', 'mp3']);

// What a browser can actually decode — a different question, and the one
// that matters for deciding whether to convert at all.
//
// The distinction is the whole reason a film can play with no sound: Chrome
// and Firefox will happily demux an MKV and decode its H.264 video while
// silently ignoring an AC3 track they have no decoder for. Nothing errors,
// nothing is reported. The video just plays, mute, and the only way to know
// in advance is to look inside the file.
const BROWSER_VIDEO = new Set(['h264', 'avc1', 'vp8', 'vp9', 'av1']);
const BROWSER_AUDIO = new Set(['aac', 'mp3', 'opus', 'vorbis', 'flac']);

/** @type {Map<string, object>} sid -> session */
const sessions = new Map();
let available = null;

// ----------------------------------------------------------------- setup

export async function detect() {
  if (available !== null) return available;
  if (!enabled) { available = false; return false; }

  try {
    const child = spawn('ffmpeg', ['-version'], { stdio: 'ignore' });
    const [code] = await once(child, 'close');
    available = code === 0;
  } catch {
    available = false;
  }

  if (available) hasBurst = await supportsBurst();

  if (available) {
    // Anything left from a previous run is dead weight — the sessions it
    // belonged to are gone.
    await fsp.rm(HLS_ROOT, { recursive: true, force: true }).catch(() => {});
    await fsp.mkdir(HLS_ROOT, { recursive: true }).catch(() => {});
  }
  return available;
}

// ffmpeg 6 and later. Asked once, because the answer can't change while the
// process is running.
async function supportsBurst() {
  try {
    const child = spawn('ffmpeg', ['-h', 'full'], { stdio: ['ignore', 'pipe', 'ignore'] });
    let out = '';
    child.stdout.on('data', (chunk) => { out += chunk; });
    await once(child, 'close');
    return out.includes('readrate_initial_burst');
  } catch {
    return false;
  }
}

export function isAvailable() {
  return available === true;
}

export function busy() {
  return sessions.size >= MAX_SESSIONS;
}

export function count() {
  return sessions.size;
}

// --------------------------------------------------------------- probing

export async function inspect(url) {
  const args = [
    '-v', 'quiet',
    '-print_format', 'json',
    '-show_format',
    '-show_streams',
    '-user_agent', 'Mozilla/5.0',
    '-analyzeduration', '5M',
    '-probesize', '5M',
    url,
  ];

  const child = spawn('ffprobe', args, { stdio: ['ignore', 'pipe', 'ignore'] });
  const timer = setTimeout(() => child.kill('SIGKILL'), PROBE_TIMEOUT_MS);

  let out = '';
  child.stdout.on('data', (chunk) => { out += chunk; });

  try {
    const [code] = await once(child, 'close');
    if (code !== 0 || !out) return null;

    const data = JSON.parse(out);
    const video = (data.streams || []).find((s) => s.codec_type === 'video');
    const audioStreams = (data.streams || []).filter((s) => s.codec_type === 'audio');
    const audio = audioStreams[0];

    // The frame rate decides the keyframe interval, and the keyframe interval
    // is what makes segments line up. Safari in particular will not play a
    // segment that doesn't begin on a keyframe.
    let fps = 25;
    if (video?.r_frame_rate) {
      const [n, d] = String(video.r_frame_rate).split('/').map(Number);
      if (d > 0 && n > 0) fps = Math.round(n / d);
    }

    return {
      duration: Math.floor(Number(data.format?.duration) || 0) || null,
      videoCodec: video?.codec_name || null,
      audioCodec: audio?.codec_name || null,
      fps,
      hasVideo: Boolean(video),
      hasAudio: Boolean(audio),
      videoCopy: VIDEO_PASSTHROUGH.has(String(video?.codec_name)),
      audioCopy: AUDIO_PASSTHROUGH.has(String(audio?.codec_name)),
      // Whether the browser stands a chance without any conversion at all.
      browserVideo: !video || BROWSER_VIDEO.has(String(video.codec_name)),
      browserAudio: !audio || BROWSER_AUDIO.has(String(audio.codec_name)),
      // Dual-audio releases are common and a browser gives no way to choose
      // between tracks, so the choice is made here instead.
      audioTracks: audioStreams.map((stream, order) => ({
        index: order,
        codec: stream.codec_name || null,
        channels: stream.channels || null,
        lang: stream.tags?.language || null,
        title: stream.tags?.title || null,
        label: audioLabel(stream, order),
        default: stream.disposition?.default === 1,
      })),
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function audioLabel(stream, order) {
  const language = stream.tags?.language ? String(stream.tags.language).toUpperCase() : null;
  const layout = stream.channels === 6 ? '5.1'
    : stream.channels === 8 ? '7.1'
      : stream.channels === 2 ? 'Stereo'
        : stream.channels === 1 ? 'Mono' : null;

  const parts = [
    language,
    stream.tags?.title,
    layout,
    stream.codec_name ? String(stream.codec_name).toUpperCase() : null,
  ].filter(Boolean);

  return parts.length ? parts.join(' · ') : `Track ${order + 1}`;
}

// ---------------------------------------------------------------- ffmpeg

function buildArgs(url, {
  dir, start, audio, plan, startNumber,
}) {
  const fps = plan?.fps || 25;
  const gop = Math.max(1, Math.round(fps * SEGMENT_SECS));

  const input = [
    '-hide_banner', '-loglevel', 'error',
    // Debrid links drop connections. These are what let a two-hour film
    // survive one rather than ending the session.
    '-reconnect', '1',
    '-reconnect_streamed', '1',
    '-reconnect_on_network_error', '1',
    '-reconnect_delay_max', '5',
    '-rw_timeout', '15000000',
    '-thread_queue_size', '4096',
    // 10M here meant reading ten megabytes of the file before a single frame
    // came out, which on a remote stream is several seconds of nothing. A
    // couple of megabytes is plenty to identify a normal release.
    '-analyzeduration', '2M',
    '-probesize', '2M',
    // genpts repairs missing timestamps; discardcorrupt drops damaged packets
    // instead of letting one stop the encode.
    '-fflags', '+genpts+discardcorrupt',
    '-user_agent', 'Mozilla/5.0',
  ];

  // Seeking before -i jumps rather than decoding everything up to the point.
  if (start > 0) input.push('-ss', String(start));

  // Convert a burst flat out, then drop to playback speed. Without the
  // throttle ffmpeg writes the whole film to disk whether or not anyone
  // watches it — gigabytes for something closed after five minutes. Without
  // the burst, playback can't start until the first segments have been
  // produced in real time, which is a slow start.
  //
  // One process doing both is what matters: killing and restarting ffmpeg to
  // change its rate leaves a discontinuity in the playlist and has to guess
  // how much was actually converted before the kill landed.
  if (hasBurst) input.push('-readrate', READRATE, '-readrate_initial_burst', String(BURST_SECS));

  input.push('-i', url);

  const maps = [
    '-map', '0:v:0?',
    // `?` so a file with no audio still produces video rather than failing.
    '-map', `0:a:${Math.max(0, Number(audio) || 0)}?`,
    '-sn', '-dn',
  ];

  const videoArgs = plan?.videoCopy
    ? ['-c:v', 'copy']
    : [
      '-c:v', 'libx264',
      '-preset', process.env.TRANSCODE_PRESET || 'veryfast',
      '-crf', process.env.TRANSCODE_CRF || '23',
      '-profile:v', 'high',
      '-level', '4.1',
      '-pix_fmt', 'yuv420p',
      // No -tune zerolatency here. It suits live streams, where latency is
      // the whole point, by disabling lookahead and B-frames — which costs
      // compression efficiency and therefore encoding speed. This is a film
      // being converted ahead of playback, so the buffer covers latency and
      // the encoder may as well be efficient.
      // Forced keyframes at a fixed interval are what make every segment start
      // on one. Safari's native HLS will not play segments that don't.
      '-g', String(gop),
      '-keyint_min', String(gop),
      '-forced_idr', '1',
      '-sc_threshold', '0',
      '-bf', '0',
    ];

  const audioArgs = [
    '-c:a', 'aac',
    '-profile:a', 'aac_low',
    '-b:a', '192k',
    '-ar', '48000',
    '-ac', '2',
    // Copying video while re-encoding audio lets their clocks drift apart,
    // which comes out as audio sliding out of sync over a long film.
    '-af', 'aresample=async=1:first_pts=0',
  ];

  const hls = [
    '-f', 'hls',
    '-hls_time', String(SEGMENT_SECS),
    // An event playlist grows and never drops anything, so you can seek back
    // through everything converted so far.
    '-hls_playlist_type', 'event',
    '-hls_flags', 'append_list+independent_segments',
    '-hls_segment_type', 'mpegts',
    '-hls_segment_filename', path.join(dir, 'seg%06d.ts'),
    '-start_number', String(startNumber || 0),
    path.join(dir, 'index.m3u8'),
  ];

  return [...input, ...maps, ...videoArgs, ...audioArgs, ...hls];
}

// What ffmpeg says about imperfect sources that isn't worth a log line.
const NOISE = /non-monotonous|non monotonic|Packet corrupt|PES packet|Last message repeated|no frame!|non-existing (SPS|PPS)|Could not find ref|\[h264 @|\[hevc @|\[aac @|\[ac3 @/i;

function segmentCount(dir) {
  try {
    return fs.readdirSync(dir).filter((f) => f.endsWith('.ts')).length;
  } catch {
    return 0;
  }
}

// -------------------------------------------------------------- sessions

export async function start(url, { audio = 0, seek = 0, plan = null } = {}) {
  if (!isAvailable()) throw new Error('ffmpeg is not in this build.');
  if (busy()) throw new Error('Too many conversions are already running.');

  const details = plan || await inspect(url);
  const sid = crypto.randomBytes(12).toString('hex');
  const dir = path.join(HLS_ROOT, sid);
  await fsp.mkdir(dir, { recursive: true });

  const session = {
    sid,
    dir,
    url,
    audio,
    // Where this session began in the film, kept separate from the moving
    // offset so a restart can be measured against it rather than compounding.
    startedAt: Math.max(0, Math.floor(seek)),
    offset: Math.max(0, Math.floor(seek)),
    plan: details,
    child: null,
    dead: false,
    finished: false,
    restarts: 0,
    timers: {},
  };
  sessions.set(sid, session);

  spawnInto(session, 0);
  armWatchdog(session);
  heartbeat(sid);

  // Hand the playlist over only once there is enough in it to start without
  // stalling on the first segment.
  const deadline = Date.now() + START_TIMEOUT_MS;
  const playlist = path.join(dir, 'index.m3u8');

  while (Date.now() < deadline) {
    if (session.dead) throw new Error('The conversion stopped before it started.');

    // Normally: wait for a few segments so playback doesn't stall on the
    // first one. But a short file can finish converting before that many
    // exist, and waiting for a fourth segment that is never coming would
    // hang until the start timeout.
    const produced = segmentCount(dir);
    const ready = produced >= PREBUFFER || (session.finished && produced >= 1);

    if (ready && fs.existsSync(playlist) && fs.statSync(playlist).size > 0) {
      return {
        sid,
        url: `/hls/${sid}/index.m3u8`,
        offset: session.offset,
        duration: details?.duration || null,
        audioTracks: details?.audioTracks || [],
        videoCopy: Boolean(details?.videoCopy),
        videoCodec: details?.videoCodec || null,
        audioCodec: details?.audioCodec || null,
      };
    }
    await new Promise((resolve) => { setTimeout(resolve, 250); });
  }

  stop(sid);
  throw new Error('ffmpeg produced nothing in time. The source may be unreachable.');
}

function spawnInto(session, startNumber) {
  const args = buildArgs(session.url, {
    dir: session.dir,
    start: session.offset,
    audio: session.audio,
    plan: session.plan,
    startNumber,
  });

  const child = spawn('ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] });
  session.child = child;

  child.stderr.on('data', (chunk) => {
    const message = chunk.toString().trim();
    if (message && !NOISE.test(message)) {
      console.error(`[ffmpeg ${session.sid.slice(0, 8)}] ${message.slice(0, 300)}`);
    }
  });

  child.on('error', (err) => {
    console.error(`[ffmpeg ${session.sid.slice(0, 8)}] could not start: ${err.message}`);
  });

  child.on('close', (code) => {
    if (session.dead) return;

    // 0 means it reached the end of the film, which is not a fault. ffmpeg
    // writes the closing tag itself, so the player knows it is complete.
    if (code === 0) { session.finished = true; return; }

    session.restarts += 1;
    if (session.restarts > MAX_RESTARTS) {
      console.error(`[ffmpeg ${session.sid.slice(0, 8)}] gave up after ${MAX_RESTARTS} restarts`);
      stop(session.sid);
      return;
    }

    // Pick up where the segments left off, continuing the same playlist
    // rather than starting the film again. The offset is measured from the
    // segments that exist, because that is what was actually converted.
    const produced = segmentCount(session.dir);
    session.offset = session.startedAt + produced * SEGMENT_SECS;
    spawnInto(session, produced);
  });
}

// An encode that has stopped producing segments but hasn't exited is stuck on
// a source that stopped answering. Killing it triggers the restart above.
function armWatchdog(session) {
  let lastCount = 0;
  let lastChange = Date.now();

  session.timers.watchdog = setInterval(() => {
    if (session.dead || session.finished) return;

    const now = segmentCount(session.dir);
    if (now > lastCount) {
      lastCount = now;
      lastChange = Date.now();
      return;
    }
    if (Date.now() - lastChange > STALL_MS) {
      lastChange = Date.now();
      try { session.child?.kill('SIGKILL'); } catch { /* already gone */ }
    }
  }, 2000);
}

// The player beats while it plays. A tab closed without a stop still gets
// cleaned up, which matters because each session holds a process and
// potentially gigabytes of segments.
export function heartbeat(sid) {
  const session = sessions.get(sid);
  if (!session) return false;

  clearTimeout(session.timers.idle);
  session.timers.idle = setTimeout(() => stop(sid), HEARTBEAT_MS);
  return true;
}

export function get(sid) {
  return sessions.get(sid) || null;
}

export function stop(sid) {
  const session = sessions.get(sid);
  if (!session) return;

  session.dead = true;
  clearInterval(session.timers.watchdog);
  clearTimeout(session.timers.idle);
  try { session.child?.kill('SIGKILL'); } catch { /* already gone */ }
  sessions.delete(sid);

  fsp.rm(session.dir, { recursive: true, force: true }).catch(() => {});
}

export function stopAll() {
  for (const sid of [...sessions.keys()]) stop(sid);
}

// The playlist references segments by bare filename; the browser needs paths
// it can actually fetch.
export function readPlaylist(sid) {
  const session = sessions.get(sid);
  if (!session) return null;
  try {
    const raw = fs.readFileSync(path.join(session.dir, 'index.m3u8'), 'utf8');
    return raw.replace(/^(seg\d+\.ts)$/gm, `/hls/${sid}/$1`);
  } catch {
    return null;
  }
}

export function segmentPath(sid, file) {
  const session = sessions.get(sid);
  if (!session) return null;
  // Only ever a segment this session produced — nothing that could walk out
  // of the directory.
  if (!/^seg\d{6}\.ts$/.test(file)) return null;
  return path.join(session.dir, file);
}
