// Making the unplayable playable, with ffmpeg.
//
// Browsers refuse MKV. Not the codecs inside it particularly — H.264 video is
// something every browser decodes happily — but the container, and the audio,
// which on a release is usually AC3, E-AC3 or DTS and which no browser has
// ever supported. So the file is nearly always playable; it is just wrapped
// and scored in ways the <video> element won't touch.
//
// Output is HLS: ffmpeg writes numbered .ts segments and a playlist, and the
// browser fetches them like any other files. The obvious alternative — one
// long fragmented-MP4 response down a pipe — does not survive contact with
// real browsers. A pipe has no length and no byte ranges, so Chrome and
// Firefox variously refuse to start, refuse to seek, or stall partway, and
// when the process dies there is nothing to resume from. Segments on disk fix
// all three, because each one is an ordinary file with a size.
//
// What actually gets converted:
//
//   H.264 video  → copied through untouched. Costs almost no CPU.
//   HEVC / AV1   → re-encoded to H.264, which is expensive.
//   AC3/DTS/etc  → re-encoded to AAC stereo. Cheap.
//
// A session owns one ffmpeg process, one directory of segments, a watchdog
// that restarts a stalled encode, and a timer that cleans the whole thing up
// when the person closes the tab.

import { spawn } from 'node:child_process';
import { once } from 'node:events';
import crypto from 'node:crypto';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import * as hw from './hwaccel.js';

export const enabled = process.env.TRANSCODE !== 'false';

const MAX_SESSIONS = Number(process.env.TRANSCODE_MAX || 2);
// Shorter segments mean the first one is ready sooner, which is most of what
// "slow to start" actually is. Two seconds each, two of them, so playback
// begins on four seconds of video instead of twelve.
const SEGMENT_SECS = Number(process.env.TRANSCODE_SEGMENT_SECS || 2);
// One segment is enough to start: hls.js begins on it and the rest arrive
// while it plays, and the spinner covers the gap. Waiting for more only moves
// the same delay in front of the person instead of behind them.
const PREBUFFER = Number(process.env.TRANSCODE_PREBUFFER || 1);
const PROBE_TIMEOUT_MS = Number(process.env.TRANSCODE_PROBE_TIMEOUT_MS || 20000);
const START_TIMEOUT_MS = Number(process.env.TRANSCODE_START_TIMEOUT_MS || 60000);
// No heartbeat for this long and the session is assumed abandoned. The player
// beats every ten seconds, so this is three missed beats.
const HEARTBEAT_MS = Number(process.env.TRANSCODE_HEARTBEAT_MS || 35000);
const STALL_MS = Number(process.env.TRANSCODE_STALL_MS || 20000);
const MAX_RESTARTS = 5;

// Encode height ceiling. This is the single biggest lever on encoding speed:
// a 2160p source re-encoded at 2160p is roughly four times the pixels of the
// same thing at 1080p, and pixels are what an encoder charges for. Plex and
// Jellyfin both default to a ladder that tops out well below source for the
// same reason. 0 disables it and encodes at source height.
const MAX_HEIGHT = Number(process.env.TRANSCODE_MAX_HEIGHT || 1080);

// A preset chosen for the machine rather than a fixed guess. On two cores
// veryfast is not fast enough to keep up with playback; on twelve it is
// leaving quality on the table for no reason.
function defaultPreset() {
  if (process.env.TRANSCODE_PRESET) return process.env.TRANSCODE_PRESET;
  const cores = os.cpus()?.length || 2;
  if (cores <= 2) return 'ultrafast';
  if (cores <= 4) return 'superfast';
  if (cores <= 8) return 'veryfast';
  return 'faster';
}
// How much of the film to convert flat out before dropping to playback speed.
// Enough to start instantly and absorb a short seek; not so much that a film
// closed after a minute has written a gigabyte.
const BURST_SECS = Number(process.env.TRANSCODE_BURST_SECS || 120);

// How fast to convert once the burst is over, as a multiple of playback speed.
//
// This was 1, which is exactly the wrong number: converting at precisely the
// speed the film is watched leaves no headroom at all, so the player sits on
// the encoder's heels and any hiccup — a slow read from the host, a busy
// moment on the CPU — becomes a stall. At 1.6 the buffer grows by six seconds
// for every ten watched, which absorbs those without converting the whole film
// to disk for someone who watches five minutes.
const READRATE = process.env.TRANSCODE_READRATE || '1.6';

// Copying video costs almost nothing, so the only reason to throttle it at
// all is disk. Encoding costs a core, so it is throttled to protect the
// machine. Treating both the same was holding the cheap path back to barely
// above playback speed for no reason.
const COPY_READRATE = process.env.TRANSCODE_COPY_READRATE || '3';
const COPY_BURST_SECS = Number(process.env.TRANSCODE_COPY_BURST_SECS || 300);

// -readrate_initial_burst arrived in ffmpeg 6. Without it the choice is
// between converting flat out (gigabytes for a film nobody finishes) and
// converting at playback speed from the first frame (a slow start), so it is
// worth knowing which is available rather than guessing.
let hasBurst = false;

// Segments live on disk for as long as the session does, and a film is
// gigabytes. STATE_DIR is a real volume; tmpfs on a small box is not where
// this belongs.
const HLS_ROOT = process.env.TRANSCODE_DIR
  || path.join(process.env.STATE_DIR || os.tmpdir(), 'hls');

// What ffmpeg can copy into an MP4 or MPEG-TS without re-encoding.
const VIDEO_PASSTHROUGH = new Set(['h264', 'avc1']);
const AUDIO_PASSTHROUGH = new Set(['aac', 'mp3']);

// What a browser can actually decode — a different question, and the one
// that matters for deciding whether to convert at all.
//
// The distinction is the whole reason a film can play with no sound: Chrome
// and Firefox will happily demux an MKV and decode its H.264 video while
// silently ignoring an AC3 track they have no decoder for. Nothing errors,
// nothing is reported. The video just plays, mute, and the only way to know
// in advance is to look inside the file.
const BROWSER_VIDEO = new Set(['h264', 'avc1', 'vp8', 'vp9', 'av1']);
const BROWSER_AUDIO = new Set(['aac', 'mp3', 'opus', 'vorbis', 'flac']);

/** @type {Map<string, object>} sid -> session */
const sessions = new Map();

// What ffprobe found, kept per URL.
//
// Probing opens the remote file and reads megabytes of it before answering,
// and the answer cannot change — it is the same file. Without this, every
// seek and every audio-track switch paid that cost again before ffmpeg had
// even started, which is most of what made restarting feel slow.
const probeCache = new Map();
const PROBE_TTL_MS = 30 * 60_000;
let available = null;

// ----------------------------------------------------------------- setup

export async function detect() {
  if (available !== null) return available;
  if (!enabled) { available = false; return false; }

  try {
    const child = spawn('ffmpeg', ['-version'], { stdio: 'ignore' });
    const [code] = await once(child, 'close');
    available = code === 0;
  } catch {
    available = false;
  }

  if (available) {
    hasBurst = await supportsBurst();
    await hw.detect();
  }

  if (available) {
    // Anything left from a previous run is dead weight — the sessions it
    // belonged to are gone.
    await fsp.rm(HLS_ROOT, { recursive: true, force: true }).catch(() => {});
    await fsp.mkdir(HLS_ROOT, { recursive: true }).catch(() => {});
  }
  return available;
}

// ffmpeg 6 and later. Asked once, because the answer can't change while the
// process is running.
async function supportsBurst() {
  try {
    const child = spawn('ffmpeg', ['-h', 'full'], { stdio: ['ignore', 'pipe', 'ignore'] });
    let out = '';
    child.stdout.on('data', (chunk) => { out += chunk; });
    await once(child, 'close');
    return out.includes('readrate_initial_burst');
  } catch {
    return false;
  }
}

export function isAvailable() {
  return available === true;
}

export function acceleration() {
  return hw.describe();
}

export function busy() {
  return sessions.size >= MAX_SESSIONS;
}

export function count() {
  return sessions.size;
}

// --------------------------------------------------------------- probing

export async function inspect(url) {
  const cached = probeCache.get(url);
  if (cached && Date.now() - cached.at < PROBE_TTL_MS) return cached.details;

  const details = await probeNow(url);
  // Only a successful probe is worth keeping; a failure is usually the source
  // being briefly unreachable, and should be retried rather than remembered.
  if (details) {
    if (probeCache.size > 200) probeCache.clear();
    probeCache.set(url, { at: Date.now(), details });
  }
  return details;
}

async function probeNow(url) {
  const args = [
    '-v', 'quiet',
    '-print_format', 'json',
    '-show_format',
    '-show_streams',
    '-user_agent', 'Mozilla/5.0',
    // Keep the connection open between reads rather than opening a new one
    // for every seek within the file.
    '-multiple_requests', '1',
    // A megabyte is enough to identify the streams in a normal release, and
    // on a remote file every extra megabyte here is a download to wait for.
    '-analyzeduration', '1M',
    '-probesize', '1M',
    url,
  ];

  const child = spawn('ffprobe', args, { stdio: ['ignore', 'pipe', 'ignore'] });
  const timer = setTimeout(() => child.kill('SIGKILL'), PROBE_TIMEOUT_MS);

  let out = '';
  child.stdout.on('data', (chunk) => { out += chunk; });

  try {
    const [code] = await once(child, 'close');
    if (code !== 0 || !out) return null;

    const data = JSON.parse(out);
    const video = (data.streams || []).find((s) => s.codec_type === 'video');
    const audioStreams = (data.streams || []).filter((s) => s.codec_type === 'audio');
    const audio = audioStreams[0];

    // The frame rate decides the keyframe interval, and the keyframe interval
    // is what makes segments line up. Safari in particular will not play a
    // segment that doesn't begin on a keyframe.
    let fps = 25;
    if (video?.r_frame_rate) {
      const [n, d] = String(video.r_frame_rate).split('/').map(Number);
      if (d > 0 && n > 0) fps = Math.round(n / d);
    }

    return {
      duration: Math.floor(Number(data.format?.duration) || 0) || null,
      width: video?.width || null,
      height: video?.height || null,
      videoCodec: video?.codec_name || null,
      audioChannels: audio?.channels || null,
      audioCodec: audio?.codec_name || null,
      fps,
      hasVideo: Boolean(video),
      hasAudio: Boolean(audio),
      videoCopy: VIDEO_PASSTHROUGH.has(String(video?.codec_name)),
      audioCopy: AUDIO_PASSTHROUGH.has(String(audio?.codec_name)),
      // Whether the browser stands a chance without any conversion at all.
      browserVideo: !video || BROWSER_VIDEO.has(String(video.codec_name)),
      browserAudio: !audio || BROWSER_AUDIO.has(String(audio.codec_name)),
      container: data.format?.format_name || null,
      // Whether this can simply be restreamed rather than converted. The
      // container has to be one every browser reads, not merely one some
      // browser tolerates: Chrome will play H.264 inside an MKV and Safari
      // will not, so MKV is not on this list even when its contents are fine.
      direct: Boolean(video) && Boolean(audio)
        && BROWSER_VIDEO.has(String(video.codec_name))
        && BROWSER_AUDIO.has(String(audio.codec_name))
        && /mp4|mov|m4v|webm/.test(String(data.format?.format_name || '')),
      // Dual-audio releases are common and a browser gives no way to choose
      // between tracks, so the choice is made here instead.
      audioTracks: audioStreams.map((stream, order) => ({
        index: order,
        codec: stream.codec_name || null,
        channels: stream.channels || null,
        lang: stream.tags?.language || null,
        title: stream.tags?.title || null,
        label: audioLabel(stream, order),
        default: stream.disposition?.default === 1,
      })),
    };
  } catch {
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function audioLabel(stream, order) {
  const language = stream.tags?.language ? String(stream.tags.language).toUpperCase() : null;
  const layout = stream.channels === 6 ? '5.1'
    : stream.channels === 8 ? '7.1'
      : stream.channels === 2 ? 'Stereo'
        : stream.channels === 1 ? 'Mono' : null;

  const parts = [
    language,
    stream.tags?.title,
    layout,
    stream.codec_name ? String(stream.codec_name).toUpperCase() : null,
  ].filter(Boolean);

  return parts.length ? parts.join(' · ') : `Track ${order + 1}`;
}

// ---------------------------------------------------------------- ffmpeg

function buildArgs(url, {
  dir, start, audio, plan, startNumber,
}) {
  const fps = plan?.fps || 25;
  const gop = Math.max(1, Math.round(fps * SEGMENT_SECS));
  const decodeOnGpu = !plan?.videoCopy && hw.active().decode.length > 0;

  // Whether the picture is being made smaller, and to what.
  const sourceHeight = plan?.height || 0;
  const targetHeight = MAX_HEIGHT > 0 && sourceHeight > MAX_HEIGHT ? MAX_HEIGHT : 0;

  const input = [
    '-hide_banner', '-loglevel', 'error',
    // Debrid links drop connections. These are what let a two-hour film
    // survive one rather than ending the session.
    '-reconnect', '1',
    '-reconnect_streamed', '1',
    '-reconnect_on_network_error', '1',
    '-reconnect_delay_max', '5',
    '-rw_timeout', '15000000',
    '-thread_queue_size', '4096',
    // 10M here meant reading ten megabytes of the file before a single frame
    // came out, which on a remote stream is several seconds of nothing. A
    // couple of megabytes is plenty to identify a normal release.
    '-analyzeduration', '2M',
    '-probesize', '2M',
    // genpts repairs missing timestamps; discardcorrupt drops damaged packets
    // instead of letting one stop the encode.
    '-fflags', '+genpts+discardcorrupt',
    '-user_agent', 'Mozilla/5.0',
    '-multiple_requests', '1',
  ];

  // Seeking before -i jumps rather than decoding everything up to the point.
  if (start > 0) input.push('-ss', String(start));

  // Convert a burst flat out, then drop to playback speed. Without the
  // throttle ffmpeg writes the whole film to disk whether or not anyone
  // watches it — gigabytes for something closed after five minutes. Without
  // the burst, playback can't start until the first segments have been
  // produced in real time, which is a slow start.
  //
  // One process doing both is what matters: killing and restarting ffmpeg to
  // change its rate leaves a discontinuity in the playlist and has to guess
  // how much was actually converted before the kill landed.
  if (hasBurst) {
    const copying = Boolean(plan?.videoCopy);
    input.push(
      '-readrate', copying ? COPY_READRATE : READRATE,
      '-readrate_initial_burst', String(copying ? COPY_BURST_SECS : BURST_SECS),
    );
  }

  // Decoding on the GPU as well, so frames never cross the bus on their way
  // to the encoder. Only when something is actually being encoded — hardware
  // decode into a stream copy would be pointless work.
  if (decodeOnGpu) input.push(...hw.active().decode);

  input.push('-i', url);

  const maps = [
    '-map', '0:v:0?',
    // `?` so a file with no audio still produces video rather than failing.
    '-map', `0:a:${Math.max(0, Number(audio) || 0)}?`,
    '-sn', '-dn',
  ];

  // Copying is free on any hardware, so the accelerator is irrelevant for the
  // common case — an H.264 release is rewrapped, not encoded. All of the GPU
  // machinery below is for HEVC, AV1 and 4K: the files that pin a CPU and
  // still stutter.
  const accel = plan?.videoCopy ? null : hw.active();
  const quality = Number(process.env.TRANSCODE_CRF || 23);

  const videoArgs = plan?.videoCopy
    ? ['-c:v', 'copy']
    : [
      ...accel.encode(quality, defaultPreset()),
      // Use every core. Left to itself libx264 does this anyway, but an
      // explicit 0 also covers the hardware encoders' own threading.
      '-threads', '0',
      // A keyframe every segment is what makes the segments independent, and
      // Safari refuses ones that aren't.
      '-g', String(gop),
      '-keyint_min', String(gop),
      '-sc_threshold', '0',
    ];

  // Filters, in the order ffmpeg needs them. Scaling is the cheap way to make
  // encoding fast: the encoder is paid by the pixel, so halving the height
  // quarters the work. On a GPU the scaler runs there too, so the frames stay
  // put; VAAPI additionally needs CPU-decoded frames uploaded before its
  // encoder will look at them.
  if (!plan?.videoCopy) {
    const filters = [];
    if (accel.uploadFilter && !decodeOnGpu) filters.push(accel.uploadFilter);
    if (targetHeight) {
      filters.push(decodeOnGpu && accel.scaleFilter
        ? accel.scaleFilter(-2).replace('-2', `-2:${targetHeight}`)
        : `scale=-2:${targetHeight}`);
    }
    if (filters.length) videoArgs.unshift('-vf', filters.join(','));
  }

  // Re-encoding audio that is already AAC stereo is pure waste — it is
  // already exactly what the output wants. Multichannel AAC still gets
  // downmixed, because browsers that decode it often route 5.1 to the wrong
  // speakers.
  const audioUntouched = plan?.audioCopy
    && plan?.audioCodec === 'aac'
    && (plan?.audioChannels || 2) <= 2;

  const audioArgs = audioUntouched
    ? ['-c:a', 'copy']
    : [
      '-c:a', 'aac',
      '-profile:a', 'aac_low',
      '-b:a', '192k',
      '-ar', '48000',
      '-ac', '2',
      // Copying video while re-encoding audio lets their clocks drift apart,
      // which comes out as audio sliding out of sync over a long film.
      '-af', 'aresample=async=1:first_pts=0',
    ];

  const hls = [
    '-f', 'hls',
    '-hls_time', String(SEGMENT_SECS),
    // An event playlist grows and never drops anything, so you can seek back
    // through everything converted so far.
    '-hls_playlist_type', 'event',
    '-hls_flags', 'append_list+independent_segments',
    '-hls_segment_type', 'mpegts',
    '-hls_segment_filename', path.join(dir, 'seg%06d.ts'),
    '-start_number', String(startNumber || 0),
    path.join(dir, 'index.m3u8'),
  ];

  return [...input, ...maps, ...videoArgs, ...audioArgs, ...hls];
}

// What ffmpeg says about imperfect sources that isn't worth a log line.
const NOISE = /non-monotonous|non monotonic|Packet corrupt|PES packet|Last message repeated|no frame!|non-existing (SPS|PPS)|Could not find ref|\[h264 @|\[hevc @|\[aac @|\[ac3 @/i;

function segmentCount(dir) {
  try {
    return fs.readdirSync(dir).filter((f) => f.endsWith('.ts')).length;
  } catch {
    return 0;
  }
}

// -------------------------------------------------------------- sessions

export async function start(url, { audio = 0, seek = 0, plan = null } = {}) {
  if (!isAvailable()) throw new Error('ffmpeg is not in this build.');
  if (busy()) throw new Error('Too many conversions are already running.');

  const details = plan || await inspect(url);
  const sid = crypto.randomBytes(12).toString('hex');
  const dir = path.join(HLS_ROOT, sid);
  await fsp.mkdir(dir, { recursive: true });

  const session = {
    sid,
    dir,
    url,
    audio,
    // Where this session began in the film, kept separate from the moving
    // offset so a restart can be measured against it rather than compounding.
    startedAt: Math.max(0, Math.floor(seek)),
    offset: Math.max(0, Math.floor(seek)),
    plan: details,
    child: null,
    dead: false,
    finished: false,
    restarts: 0,
    timers: {},
  };
  sessions.set(sid, session);

  spawnInto(session, 0);
  armWatchdog(session);
  heartbeat(sid);

  // Hand the playlist over only once there is enough in it to start without
  // stalling on the first segment.
  const deadline = Date.now() + START_TIMEOUT_MS;
  const playlist = path.join(dir, 'index.m3u8');

  while (Date.now() < deadline) {
    if (session.dead) throw new Error('The conversion stopped before it started.');

    // Normally: wait for a few segments so playback doesn't stall on the
    // first one. But a short file can finish converting before that many
    // exist, and waiting for a fourth segment that is never coming would
    // hang until the start timeout.
    const produced = segmentCount(dir);
    const ready = produced >= PREBUFFER || (session.finished && produced >= 1);

    if (ready && fs.existsSync(playlist) && fs.statSync(playlist).size > 0) {
      return {
        sid,
        url: `/hls/${sid}/index.m3u8`,
        offset: session.offset,
        duration: details?.duration || null,
        audioTracks: details?.audioTracks || [],
        videoCopy: Boolean(details?.videoCopy),
        videoCodec: details?.videoCodec || null,
        audioCodec: details?.audioCodec || null,
      };
    }
    await new Promise((resolve) => { setTimeout(resolve, 250); });
  }

  stop(sid);
  throw new Error('ffmpeg produced nothing in time. The source may be unreachable.');
}

function spawnInto(session, startNumber) {
  const args = buildArgs(session.url, {
    dir: session.dir,
    start: session.offset,
    audio: session.audio,
    plan: session.plan,
    startNumber,
  });

  const child = spawn('ffmpeg', args, { stdio: ['ignore', 'ignore', 'pipe'] });
  session.child = child;

  child.stderr.on('data', (chunk) => {
    const message = chunk.toString().trim();
    if (message && !NOISE.test(message)) {
      // Kept so a failed restart can tell a GPU problem from a source problem.
      session.lastError = message;
      console.error(`[ffmpeg ${session.sid.slice(0, 8)}] ${message.slice(0, 300)}`);
    }
  });

  child.on('error', (err) => {
    console.error(`[ffmpeg ${session.sid.slice(0, 8)}] could not start: ${err.message}`);
  });

  child.on('close', (code) => {
    if (session.dead) return;

    // 0 means it reached the end of the film, which is not a fault. ffmpeg
    // writes the closing tag itself, so the player knows it is complete.
    if (code === 0) { session.finished = true; return; }

    // A GPU that dies mid-film — driver reset, device busy, a stream it can't
    // handle — should cost one restart on the CPU, not every playback from
    // here on. The encoder name in the error is the tell.
    if (session.plan && !session.plan.videoCopy && /nvenc|qsv|vaapi|amf|videotoolbox|v4l2|Device creation failed|Function not implemented/i.test(session.lastError || '')) {
      hw.demote(session.sid.slice(0, 8));
    }

    session.restarts += 1;
    if (session.restarts > MAX_RESTARTS) {
      console.error(`[ffmpeg ${session.sid.slice(0, 8)}] gave up after ${MAX_RESTARTS} restarts`);
      stop(session.sid);
      return;
    }

    // Pick up where the segments left off, continuing the same playlist
    // rather than starting the film again. The offset is measured from the
    // segments that exist, because that is what was actually converted.
    const produced = segmentCount(session.dir);
    session.offset = session.startedAt + produced * SEGMENT_SECS;
    spawnInto(session, produced);
  });
}

// An encode that has stopped producing segments but hasn't exited is stuck on
// a source that stopped answering. Killing it triggers the restart above.
function armWatchdog(session) {
  let lastCount = 0;
  let lastChange = Date.now();

  session.timers.watchdog = setInterval(() => {
    if (session.dead || session.finished) return;

    const now = segmentCount(session.dir);
    if (now > lastCount) {
      lastCount = now;
      lastChange = Date.now();
      return;
    }
    if (Date.now() - lastChange > STALL_MS) {
      lastChange = Date.now();
      try { session.child?.kill('SIGKILL'); } catch { /* already gone */ }
    }
  }, 2000);
}

// The player beats while it plays. A tab closed without a stop still gets
// cleaned up, which matters because each session holds a process and
// potentially gigabytes of segments.
export function heartbeat(sid) {
  const session = sessions.get(sid);
  if (!session) return false;

  clearTimeout(session.timers.idle);
  session.timers.idle = setTimeout(() => stop(sid), HEARTBEAT_MS);
  return true;
}

export function get(sid) {
  return sessions.get(sid) || null;
}

export function stop(sid) {
  const session = sessions.get(sid);
  if (!session) return;

  session.dead = true;
  clearInterval(session.timers.watchdog);
  clearTimeout(session.timers.idle);
  try { session.child?.kill('SIGKILL'); } catch { /* already gone */ }
  sessions.delete(sid);

  fsp.rm(session.dir, { recursive: true, force: true }).catch(() => {});
}

export function stopAll() {
  for (const sid of [...sessions.keys()]) stop(sid);
}

// The playlist references segments by bare filename; the browser needs paths
// it can actually fetch.
export function readPlaylist(sid) {
  const session = sessions.get(sid);
  if (!session) return null;
  try {
    const raw = fs.readFileSync(path.join(session.dir, 'index.m3u8'), 'utf8');
    return raw.replace(/^(seg\d+\.ts)$/gm, `/hls/${sid}/$1`);
  } catch {
    return null;
  }
}

export function segmentPath(sid, file) {
  const session = sessions.get(sid);
  if (!session) return null;
  // Only ever a segment this session produced — nothing that could walk out
  // of the directory.
  if (!/^seg\d{6}\.ts$/.test(file)) return null;
  return path.join(session.dir, file);
}
