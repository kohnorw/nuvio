// Subtitles for the browser player.
//
// VLC reads SubRip happily; <track> does not — browsers want WebVTT and
// nothing else. Since almost every subtitle addon returns .srt, a subtitle
// menu in the web player means converting on the way through.
//
// Going through the server also solves a second problem: <track> is subject
// to CORS, and subtitle hosts rarely send the header. Served from our own
// origin, it's same-origin and the question doesn't arise.

// SubRip and WebVTT are the same format with three differences: the header,
// the decimal separator in timestamps, and the fact that VTT dislikes some
// characters appearing raw in cue text.
export function srtToVtt(text) {
  const body = String(text)
    .replace(/^\uFEFF/, '')
    .replace(/\r\n?/g, '\n')
    // 00:01:02,500 --> 00:01:04,000
    .replace(/(\d{2}:\d{2}:\d{2}),(\d{1,3})/g, '$1.$2')
    // Some files use a two-digit hour-less form that VTT reads as mm:ss.mmm
    // anyway, so leave those alone.
    .trim();

  return `WEBVTT\n\n${body}\n`;
}

export function looksLikeVtt(text) {
  return /^\uFEFF?WEBVTT/.test(String(text).slice(0, 32));
}

// Anything we can turn into text. Archives and image-based formats (.sub/.idx,
// PGS) can't be shown by a browser at all, so they're filtered out of the menu
// rather than converted into something broken.
export function convertible(url) {
  return !/\.(zip|gz|rar|7z|sub|idx|sup)(\?|$)/i.test(String(url));
}

export function convert(text) {
  return looksLikeVtt(text) ? String(text).replace(/^\uFEFF/, '') : srtToVtt(text);
}

// The M3U carries the chosen subtitle as `input-slave=<url>`; the web player
// needs that same URL back out to build a <track>.
export function slaveUrlFrom(options = []) {
  for (const option of options) {
    const match = /^input-slave=(.+)$/.exec(option);
    if (match) return match[1];
  }
  return null;
}
