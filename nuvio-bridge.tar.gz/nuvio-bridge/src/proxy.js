// An optional pipe between the browser player and the stream host.
//
// Two things break browser playback that don't trouble VLC:
//
//   Mixed content   The page is on https and the addon returned an http link.
//                   Every browser blocks that outright.
//   Hotlinking      A few hosts check Referer or Origin and refuse anything
//                   that didn't come from their own page.
//
// Proxying fixes both, at the cost of every byte of video passing through the
// server. That is a real cost on a small box or a metered connection, so it is
// off unless MEDIA_PROXY=true — and even then the player only reaches for it
// when direct playback has actually failed.
//
// Range requests are forwarded verbatim in both directions, which is what
// makes seeking work.

import { Readable } from 'node:stream';

export const enabled = process.env.MEDIA_PROXY === 'true';

const PASS_TO_ORIGIN = ['range', 'if-range', 'user-agent'];
const PASS_TO_CLIENT = [
  'content-type', 'content-length', 'content-range', 'accept-ranges',
  'last-modified', 'etag',
];

export async function pipe(url, req, res) {
  const headers = {};
  for (const name of PASS_TO_ORIGIN) {
    const value = req.get(name);
    if (value) headers[name] = value;
  }

  const upstream = await fetch(url, {
    method: req.method === 'HEAD' ? 'HEAD' : 'GET',
    headers,
    redirect: 'follow',
  });

  res.status(upstream.status);
  for (const name of PASS_TO_CLIENT) {
    const value = upstream.headers.get(name);
    if (value) res.setHeader(name, value);
  }
  // Resolved links are per-session and shouldn't be held by an intermediary.
  res.setHeader('cache-control', 'private, no-store');

  if (req.method === 'HEAD' || !upstream.body) return res.end();

  const body = Readable.fromWeb(upstream.body);
  // The browser aborts the request on every seek, which lands here as an
  // error on a pipe nobody is reading any more. It is normal, not a fault.
  body.on('error', () => res.destroy());
  res.on('close', () => body.destroy());
  body.pipe(res);
  return undefined;
}
