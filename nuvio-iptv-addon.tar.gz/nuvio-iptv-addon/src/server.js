import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defaults, decodeConfig } from './config.js';
import { getData, cacheStats } from './store.js';
import { buildManifest, groupCatalogId } from './manifest.js';
import { catalogItem, fullMeta, buildStreams } from './meta.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PAGE_SIZE = 100;

const app = express();
app.disable('x-powered-by');

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Cache-Control', 'public, max-age=60');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

const router = express.Router({ mergeParams: true });

// Resolve the config for this request: URL segment first, env second.
router.use((req, res, next) => {
  const seg = req.params.cfg;
  if (!seg) {
    req.cfg = defaults;
    return next();
  }
  try {
    req.cfg = decodeConfig(seg);
    next();
  } catch {
    res.status(404).json({ err: 'That configuration link is not valid.' });
  }
});

router.get('/configure', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(path.join(__dirname, 'public', 'configure.html'));
});

router.use((req, res, next) => {
  if (!req.cfg.m3u.length) {
    return res.status(500).json({
      err: 'No playlist configured. Set M3U_URL, or install with a configured URL from /configure.',
    });
  }
  next();
});

function parseExtra(raw) {
  const out = {};
  if (!raw) return out;
  for (const pair of decodeURIComponent(raw).split('&')) {
    const i = pair.indexOf('=');
    if (i > 0) out[pair.slice(0, i)] = pair.slice(i + 1);
  }
  return out;
}

router.get('/manifest.json', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    res.json(buildManifest(req.cfg, data));
  } catch (err) { next(err); }
});

async function catalog(req, res, next) {
  try {
    const { type, id } = req.params;
    if (type !== 'tv') return res.json({ metas: [] });

    const cfg = req.cfg;
    const data = await getData(cfg);
    const extra = parseExtra(req.params.extra);
    const now = Date.now();

    let list = data.channels;

    if (id !== 'iptv_channels') {
      const group = data.groups.find((g) => groupCatalogId(g) === id);
      if (!group) return res.json({ metas: [] });
      list = list.filter((c) => c.group === group);
    }

    if (extra.genre) {
      const g = extra.genre.toLowerCase();
      list = list.filter((c) => (c.group || '').toLowerCase() === g);
    }

    if (extra.search) {
      const q = extra.search.toLowerCase();
      list = list.filter((c) => {
        if (c.name.toLowerCase().includes(q)) return true;
        const { programmes } = c;
        return programmes.some((p) => p.stop > now && p.title.toLowerCase().includes(q));
      });
    }

    const skip = Number(extra.skip) || 0;
    const page = list.slice(skip, skip + PAGE_SIZE);
    res.json({ metas: page.map((c) => catalogItem(c, cfg, now)) });
  } catch (err) { next(err); }
}

router.get('/catalog/:type/:id.json', catalog);
router.get('/catalog/:type/:id/:extra.json', catalog);

router.get('/meta/:type/:id.json', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    const ch = data.channels.find((c) => c.id === req.params.id);
    if (!ch) return res.status(404).json({ err: 'Channel not found' });
    res.setHeader('Cache-Control', 'public, max-age=30');
    res.json({ meta: await fullMeta(ch, req.cfg) });
  } catch (err) { next(err); }
});

router.get('/stream/:type/:id.json', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    const ch = data.channels.find((c) => c.id === req.params.id);
    if (!ch) return res.json({ streams: [] });
    res.setHeader('Cache-Control', 'public, max-age=30');
    res.json({ streams: buildStreams(ch, req.cfg) });
  } catch (err) { next(err); }
});

app.get('/health', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json({ status: 'ok', installs: cacheStats() });
});

app.get('/', (req, res) => res.redirect('/configure'));

// Plain routes first, then the /<config>/ variants.
app.use('/', router);
app.use('/:cfg([A-Za-z0-9_-]+)', router);

app.use((req, res) => res.status(404).json({ err: 'Not found' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[error]', err);
  res.status(500).json({ err: err.message });
});

app.listen(defaults.port, () => {
  console.log(`IPTV addon listening on :${defaults.port}`);
  console.log(`  configure   http://localhost:${defaults.port}/configure`);
  console.log(`  manifest    http://localhost:${defaults.port}/manifest.json`);
  if (defaults.m3u.length) {
    getData(defaults).catch((err) => console.error('[startup]', err.message));
  } else {
    console.log('  no M3U_URL set — configure per-install links at /configure');
  }
});
