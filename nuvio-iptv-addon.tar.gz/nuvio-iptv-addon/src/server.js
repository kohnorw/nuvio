import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { defaults, decodeConfig } from './config.js';
import { getData, cacheStats } from './store.js';
import { buildManifest, groupCatalogId } from './manifest.js';
import { catalogItem, fullMeta, buildStreams } from './meta.js';
import { artworkStats } from './artwork.js';
import {
  normalizeLogo,
  fetchRawLogo,
  placeholderTile,
  stationBackdrop,
  logoCacheStats,
} from './logos.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PAGE_SIZE = 100;

const app = express();
app.disable('x-powered-by');

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Cache-Control', 'public, max-age=60');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

const router = express.Router({ mergeParams: true });

// Resolve the config for this request: URL segment first, env second.
router.use((req, res, next) => {
  const seg = req.params.cfg;
  if (!seg) {
    req.cfg = defaults;
    return next();
  }
  try {
    req.cfg = decodeConfig(seg);
    next();
  } catch {
    res.status(404).json({ err: 'That configuration link is not valid.' });
  }
});

router.get('/configure', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.sendFile(path.join(__dirname, 'public', 'configure.html'));
});

router.use((req, res, next) => {
  if (!req.cfg.m3u.length) {
    return res.status(500).json({
      err: 'No playlist configured. Set M3U_URL, or install with a configured URL from /configure.',
    });
  }
  next();
});

// The address Nuvio reached us on, so generated image URLs point back here.
function baseUrl(req) {
  if (req.cfg.publicUrl) return req.cfg.publicUrl + (req.baseUrl || '');
  const proto = req.get('x-forwarded-proto') || req.protocol;
  const host = req.get('x-forwarded-host') || req.get('host');
  return `${proto}://${host}${req.baseUrl || ''}`;
}

// Logo fetching happens per request, so a systemic failure (blocked host,
// no DNS, provider rejecting the container) would otherwise be invisible.
const logoFailures = { count: 0, lastUrl: null, lastError: null, at: null };
let logoFailuresLogged = 0;

function noteLogoFailure(channel, err) {
  logoFailures.count++;
  logoFailures.lastUrl = channel?.logo || null;
  logoFailures.lastError = err.message;
  logoFailures.at = new Date().toISOString();
  // Loud for the first few, then quiet — one line per channel would flood.
  if (logoFailuresLogged < 5) {
    logoFailuresLogged++;
    console.warn(`[logo] ${channel?.name || '?'}: ${err.message} (${channel?.logo || 'no url'})`);
    if (logoFailuresLogged === 5) {
      console.warn('[logo] further logo failures will not be logged; see /health');
    }
  }
}

function parseExtra(raw) {
  const out = {};
  if (!raw) return out;
  for (const pair of decodeURIComponent(raw).split('&')) {
    const i = pair.indexOf('=');
    if (i > 0) out[pair.slice(0, i)] = pair.slice(i + 1);
  }
  return out;
}

router.get('/manifest.json', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    res.json(buildManifest(req.cfg, data));
  } catch (err) { next(err); }
});

async function catalog(req, res, next) {
  try {
    const { type, id } = req.params;
    if (type !== 'tv') return res.json({ metas: [] });

    const cfg = req.cfg;
    const data = await getData(cfg);
    const extra = parseExtra(req.params.extra);
    const now = Date.now();

    let list = data.channels;

    if (id !== 'iptv_channels') {
      const group = data.groups.find((g) => groupCatalogId(g) === id);
      if (!group) return res.json({ metas: [] });
      list = list.filter((c) => c.group === group);
    }

    if (extra.genre) {
      const g = extra.genre.toLowerCase();
      list = list.filter((c) => (c.group || '').toLowerCase() === g);
    }

    if (extra.search) {
      const q = extra.search.toLowerCase();
      list = list.filter((c) => {
        if (c.name.toLowerCase().includes(q)) return true;
        const { programmes } = c;
        return programmes.some((p) => p.stop > now && p.title.toLowerCase().includes(q));
      });
    }

    const skip = Number(extra.skip) || 0;
    const page = list.slice(skip, skip + PAGE_SIZE);
    const base = baseUrl(req);
    res.json({ metas: page.map((c) => catalogItem(c, cfg, now, base)) });
  } catch (err) { next(err); }
}

router.get('/catalog/:type/:id.json', catalog);
router.get('/catalog/:type/:id/:extra.json', catalog);

// Diagnose a single channel's logo end to end: what the container gets back,
// and what it managed to do with it.
router.get('/logo/:id/debug', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    const ch = data.channels.find((c) => c.id === req.params.id) || data.channels[0];
    if (!ch) return res.status(404).json({ err: 'no channels loaded' });

    const out = { channel: ch.name, logoUrl: ch.logo || null };
    if (!ch.logo) {
      out.result = 'channel has no tvg-logo in the playlist';
      return res.json(out);
    }

    try {
      const probe = await fetch(ch.logo, {
        headers: { 'User-Agent': req.cfg.userAgent, Accept: '*/*' },
        redirect: 'follow',
        signal: AbortSignal.timeout(15000),
      });
      const buf = Buffer.from(await probe.arrayBuffer());
      out.fetch = {
        status: probe.status,
        contentType: probe.headers.get('content-type'),
        bytes: buf.length,
        firstBytes: buf.subarray(0, 8).toString('hex'),
      };
    } catch (err) {
      out.fetch = { error: err.message };
    }

    try {
      const png = await normalizeLogo(ch.logo, req.cfg);
      out.result = 'normalized ok';
      out.tileBytes = png.length;
    } catch (err) {
      out.result = `normalize failed: ${err.message}`;
    }
    res.json(out);
  } catch (err) { next(err); }
});

// What the guide actually gave us for a channel, before any formatting.
// Answers "is the description missing from the XMLTV, or lost on the way out?"
router.get('/guide/:id/debug', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    const ch = data.channels.find((c) => c.id === req.params.id);
    if (!ch) return res.status(404).json({ err: 'channel not found' });

    const now = Date.now();
    const current = ch.programmes.find((p) => p.start <= now && p.stop > now) || null;
    const withDesc = ch.programmes.filter((p) => p.desc).length;

    res.json({
      channel: ch.name,
      tvgId: ch.tvgId,
      programmes: ch.programmes.length,
      programmesWithDescription: withDesc,
      current: current && {
        title: current.title,
        subTitle: current.subTitle,
        desc: current.desc || null,
        descLength: (current.desc || '').length,
        categories: current.categories,
        episode: current.episode,
        date: current.date,
        credits: current.credits,
        icon: current.icon || null,
      },
      note: withDesc === 0 && ch.programmes.length
        ? 'This channel\'s guide carries no <desc> elements; descriptions come from the artwork provider instead.'
        : undefined,
    });
  } catch (err) { next(err); }
});

router.get('/backdrop/:id.png', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    const ch = data.channels.find((c) => c.id === req.params.id);
    if (!ch) return res.status(404).end();
    const png = await stationBackdrop(ch.logo, req.cfg, ch.name);
    res.setHeader('Content-Type', 'image/png');
    res.setHeader('Cache-Control', 'public, max-age=604800');
    return res.end(png);
  } catch (err) { next(err); }
});

router.get('/logo/:id.png', async (req, res, next) => {
  let channel = null;
  try {
    const data = await getData(req.cfg);
    channel = data.channels.find((c) => c.id === req.params.id);
    if (!channel) return res.status(404).end();

    // No logo at all is the only case that gets initials.
    if (!channel.logo) {
      const png = await placeholderTile(channel.name, req.cfg);
      res.setHeader('Content-Type', 'image/png');
      // Short: a channel may gain a logo on the next playlist refresh, and a
      // week-long cache of initials is exactly how this went wrong before.
      res.setHeader('Cache-Control', 'public, max-age=3600');
      return res.end(png);
    }

    // Preferred: fitted onto a consistent tile.
    try {
      const png = await normalizeLogo(channel.logo, req.cfg);
      res.setHeader('Content-Type', 'image/png');
      res.setHeader('Cache-Control', 'public, max-age=604800');
      return res.end(png);
    } catch (err) {
      noteLogoFailure(channel, err);
    }

    // Next best: whatever the logo host returned, at whatever size or format.
    // An odd-sized logo showing beats a tidy tile with nothing on it.
    try {
      const raw = await fetchRawLogo(channel.logo, req.cfg);
      res.setHeader('Content-Type', raw.contentType);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      return res.end(raw.buf);
    } catch (err) {
      noteLogoFailure(channel, err);
    }

    // Last: let the player fetch it directly, as it did before any of this.
    return res.redirect(302, channel.logo);
  } catch (err) {
    if (channel?.logo) return res.redirect(302, channel.logo);
    return next(err);
  }
});

router.get('/meta/:type/:id.json', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    const ch = data.channels.find((c) => c.id === req.params.id);
    if (!ch) return res.status(404).json({ err: 'Channel not found' });
    res.setHeader('Cache-Control', 'public, max-age=30');
    res.json({ meta: await fullMeta(ch, req.cfg, Date.now(), baseUrl(req)) });
  } catch (err) { next(err); }
});

router.get('/stream/:type/:id.json', async (req, res, next) => {
  try {
    const data = await getData(req.cfg);
    const ch = data.channels.find((c) => c.id === req.params.id);
    if (!ch) return res.json({ streams: [] });
    res.setHeader('Cache-Control', 'public, max-age=30');
    res.json({ streams: buildStreams(ch, req.cfg) });
  } catch (err) { next(err); }
});

app.get('/health', (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.json({
    status: 'ok',
    installs: cacheStats(),
    artwork: artworkStats(),
    logos: { ...logoCacheStats(), failures: logoFailures },
  });
});

app.get('/', (req, res) => res.redirect('/configure'));

// Plain routes first, then the /<config>/ variants.
app.use('/', router);
app.use('/:cfg([A-Za-z0-9_-]+)', router);

app.use((req, res) => res.status(404).json({ err: 'Not found' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[error]', err);
  res.status(500).json({ err: err.message });
});

// Some provider logo hosts serve broken or self-signed certificates. Opt-in,
// and scoped to this process only.
if (defaults.insecureTls) {
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
  console.warn('[tls] certificate verification disabled by INSECURE_TLS');
}

app.listen(defaults.port, () => {
  console.log(`IPTV addon listening on :${defaults.port}`);
  console.log(`  configure   http://localhost:${defaults.port}/configure`);
  console.log(`  manifest    http://localhost:${defaults.port}/manifest.json`);
  if (defaults.m3u.length) {
    getData(defaults).catch((err) => console.error('[startup]', err.message));
  } else {
    console.log('  no M3U_URL set — configure per-install links at /configure');
  }
});
