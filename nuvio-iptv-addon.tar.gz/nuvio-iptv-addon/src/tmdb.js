// Optional: when a guide entry has no artwork, look the title up on TMDB so the
// channel page shows a real backdrop instead of a stretched station logo.
// Set TMDB_API_KEY to switch this on; everything works without it.

const IMG = 'https://image.tmdb.org/t/p';
const cache = new Map(); // title -> { at, value }
const TTL_MS = 24 * 60 * 60 * 1000;
const MAX_ENTRIES = 3000;

export async function lookupArtwork(title, year, cfg) {
  if (!cfg.tmdbKey || !title || title.length < 3) return null;
  const key = `${title.toLowerCase()}|${year || ''}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.value;

  let value = null;
  try {
    const url = new URL('https://api.themoviedb.org/3/search/multi');
    url.searchParams.set('api_key', cfg.tmdbKey);
    url.searchParams.set('language', cfg.tmdbLang);
    url.searchParams.set('query', title);
    url.searchParams.set('include_adult', 'false');
    const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
    if (res.ok) {
      const json = await res.json();
      const hitItem = (json.results || []).find(
        (r) => (r.media_type === 'movie' || r.media_type === 'tv') && (r.backdrop_path || r.poster_path)
      );
      if (hitItem) {
        value = {
          background: hitItem.backdrop_path ? `${IMG}/w1280${hitItem.backdrop_path}` : null,
          poster: hitItem.poster_path ? `${IMG}/w500${hitItem.poster_path}` : null,
          overview: hitItem.overview || '',
          rating: hitItem.vote_average ? Number(hitItem.vote_average).toFixed(1) : '',
          year: (hitItem.release_date || hitItem.first_air_date || '').slice(0, 4),
        };
      }
    }
  } catch {
    value = null;
  }

  if (cache.size > MAX_ENTRIES) cache.clear();
  cache.set(key, { at: Date.now(), value });
  return value;
}
