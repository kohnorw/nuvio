import crypto from 'node:crypto';
import { configKey } from './config.js';

export const VERSION = '1.12.0';

export function groupCatalogId(group) {
  return 'iptv_g_' + crypto.createHash('sha1').update(group).digest('hex').slice(0, 8);
}

export function buildManifest(cfg, data) {
  const groups = data?.groups || [];
  const idSuffix = crypto.createHash('sha1').update(configKey(cfg)).digest('hex').slice(0, 6);

  const catalogs = [];

  // Folder row first, so it leads the home screen.
  if (cfg.folders) {
    catalogs.push({
      type: 'tv',
      id: 'iptv_folders',
      name: cfg.folderCatalogName,
      extra: [
        { name: 'search', isRequired: false },
        { name: 'skip', isRequired: false },
      ],
      extraSupported: ['search', 'skip'],
    });
  }

  // The flat list stays whenever folders are off, and by default alongside
  // them because it is what search runs against.
  if (!cfg.folders || cfg.showAllChannels) {
    catalogs.push({
      type: 'tv',
      id: 'iptv_channels',
      name: cfg.catalogName,
      extra: [
        { name: 'genre', options: groups, isRequired: false },
        { name: 'search', isRequired: false },
        { name: 'skip', isRequired: false },
      ],
      extraSupported: ['genre', 'search', 'skip'],
    });
  }

  // One catalog per category. A Nuvio collection folder points at a catalog,
  // so this is what lets "Live TV" have a folder per category that opens into
  // that category's channels.
  if (cfg.splitGroups || cfg.categoryCatalogs) {
    for (const g of groups.slice(0, cfg.maxSplitGroups)) {
      catalogs.push({
        type: 'tv',
        id: groupCatalogId(g),
        name: g,
        extra: [
          { name: 'search', isRequired: false },
          { name: 'skip', isRequired: false },
        ],
        extraSupported: ['search', 'skip'],
      });
    }
  }

  return {
    id: `community.iptv.live.${idSuffix}`,
    version: VERSION,
    name: cfg.name,
    description:
      `Live TV from your own playlist — ${data?.channels.length ?? 0} channels, ` +
      `station logos, and XMLTV guide data showing what is on now and next.`,
    logo: 'https://raw.githubusercontent.com/Stremio/stremio-art/main/orig/stremio_symbol.png',
    resources: ['catalog', 'meta', 'stream'],
    types: ['tv'],
    idPrefixes: ['iptv:'],
    catalogs,
    // No configure page to point at, so no Configure button.
    behaviorHints: { configurable: false, configurationRequired: false },
  };
}


/**
 * A Nuvio collection describing this addon's categories: one folder per
 * category, each bound to that category's catalog, with square tiles so the
 * grid matches the channel logos.
 *
 * Ids are derived from the addon id and the category name rather than random,
 * so re-pushing updates the same folders instead of duplicating them.
 */
function uuidFrom(...parts) {
  const h = crypto.createHash('sha1').update(parts.join('|')).digest('hex').slice(0, 32);
  // Shape the digest as a v5-looking UUID; Nuvio only needs a stable unique id.
  return [h.slice(0, 8), h.slice(8, 12), '5' + h.slice(13, 16), '8' + h.slice(17, 20), h.slice(20, 32)].join('-');
}

export function buildCollection(cfg, data, { title = 'Live TV', base = '' } = {}) {
  const manifest = buildManifest(cfg, data);
  const addonId = manifest.id;
  // One catalog for everything; each folder is the same catalog filtered to
  // its category. That is why the addon publishes a single channels catalog
  // rather than one per category.
  const folders = (data?.folders || []).map((f) => {
    const source = {
      addonId,
      type: 'tv',
      catalogId: 'iptv_channels',
      genre: f.name,
    };
    return {
      id: uuidFrom(addonId, 'folder', f.name),
      title: f.name,
      // The tile is a rendered label, so the title would be printed twice.
      hideTitle: true,
      coverImageUrl: base ? `${base}/folder/${encodeURIComponent(f.id)}.png` : null,
      coverEmoji: null,
      focusGifUrl: null,
      focusGifEnabled: false,
      heroBackdropUrl: null,
      heroVideoUrl: null,
      titleLogoUrl: null,
      // Station logos are square; SQUARE keeps the channel grid uncropped.
      tileShape: 'SQUARE',
      catalogSources: [source],
      sources: [{ provider: 'addon', ...source }],
    };
  });

  return {
    id: uuidFrom(addonId, 'collection', title),
    title,
    pinToTop: true,
    focusGlowEnabled: true,
    viewMode: 'FOLLOW_LAYOUT',
    showAllTab: true,
    backdropImageUrl: null,
    folders,
  };
}
