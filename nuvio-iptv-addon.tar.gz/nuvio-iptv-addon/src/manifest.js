import crypto from 'node:crypto';
import { configKey } from './config.js';

export const VERSION = '1.12.0';

export function groupCatalogId(group) {
  return 'iptv_g_' + crypto.createHash('sha1').update(group).digest('hex').slice(0, 8);
}

export function buildManifest(cfg, data) {
  const groups = data?.groups || [];
  const idSuffix = crypto.createHash('sha1').update(configKey(cfg)).digest('hex').slice(0, 6);

  const catalogs = [];

  // Folder row first, so it leads the home screen.
  if (cfg.folders) {
    catalogs.push({
      type: 'tv',
      id: 'iptv_folders',
      name: cfg.folderCatalogName,
      extra: [
        { name: 'search', isRequired: false },
        { name: 'skip', isRequired: false },
      ],
      extraSupported: ['search', 'skip'],
    });
  }

  // The flat list stays whenever folders are off, and by default alongside
  // them because it is what search runs against.
  if (!cfg.folders || cfg.showAllChannels) {
    catalogs.push({
      type: 'tv',
      id: 'iptv_channels',
      name: cfg.catalogName,
      extra: [
        { name: 'genre', options: groups, isRequired: false },
        { name: 'search', isRequired: false },
        { name: 'skip', isRequired: false },
      ],
      extraSupported: ['genre', 'search', 'skip'],
    });
  }

  if (cfg.splitGroups) {
    for (const g of groups.slice(0, cfg.maxSplitGroups)) {
      catalogs.push({
        type: 'tv',
        id: groupCatalogId(g),
        name: g,
        extra: [
          { name: 'search', isRequired: false },
          { name: 'skip', isRequired: false },
        ],
        extraSupported: ['search', 'skip'],
      });
    }
  }

  return {
    id: `community.iptv.live.${idSuffix}`,
    version: VERSION,
    name: cfg.name,
    description:
      `Live TV from your own playlist — ${data?.channels.length ?? 0} channels, ` +
      `station logos, and XMLTV guide data showing what is on now and next.`,
    logo: 'https://raw.githubusercontent.com/Stremio/stremio-art/main/orig/stremio_symbol.png',
    resources: ['catalog', 'meta', 'stream'],
    types: ['tv'],
    idPrefixes: ['iptv:'],
    catalogs,
    // No configure page to point at, so no Configure button.
    behaviorHints: { configurable: false, configurationRequired: false },
  };
}
