// Configuration comes from two places:
//  1. Environment variables (the docker-native way) -> the default config
//  2. An optional base64url segment in the addon URL, so one container can serve
//     several playlists: http://host:7000/<config>/manifest.json

const splitList = (v) =>
  (v || '')
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);

const num = (v, fallback) => {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
};

export const defaults = {
  name: process.env.ADDON_NAME || 'IPTV',
  m3u: splitList(process.env.M3U_URL),
  epg: splitList(process.env.EPG_URL),
  includeGroups: splitList(process.env.INCLUDE_GROUPS),
  excludeGroups: splitList(process.env.EXCLUDE_GROUPS),
  posterShape: process.env.POSTER_SHAPE || 'square',
  splitGroups: String(process.env.SPLIT_GROUPS || 'false') === 'true',
  maxSplitGroups: num(process.env.MAX_SPLIT_GROUPS, 30),
  refreshHours: num(process.env.REFRESH_HOURS, 6),
  epgOffsetHours: num(process.env.EPG_OFFSET_HOURS, 0),
  userAgent:
    process.env.USER_AGENT ||
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
  locale: process.env.DISPLAY_LOCALE || 'en-US',
  clock24: String(process.env.TIME_FORMAT || '12') === '24',
  // cinemeta (default, no key needed) | tmdb (needs TMDB_API_KEY) | off
  artwork: (process.env.ARTWORK || 'cinemeta').toLowerCase(),
  // letterbox station logos onto one canvas so tiles are visually consistent
  normalizeLogos: String(process.env.NORMALIZE_LOGOS || 'true') === 'true',
  tileBackground: process.env.TILE_BACKGROUND || '#101317',
  // playlist (default) | repo | repo-only. The iptv-org database is well
  // curated, but many of its logos are hosted on Wikimedia, which refuses
  // server-side fetches — so it is opt-in rather than the default.
  logoSource: (process.env.LOGO_SOURCE || 'playlist').toLowerCase(),
  logoCountryFallback: (process.env.LOGO_COUNTRY_FALLBACK || 'US,CA,GB')
    .split(',').map((s) => s.trim().toUpperCase()).filter(Boolean),
  warmLogos: String(process.env.WARM_LOGOS || 'true') === 'true',
  insecureTls: String(process.env.INSECURE_TLS || 'false') === 'true',
  // keep live channels out of the player's Continue Watching row
  hideFromContinueWatching: String(process.env.HIDE_FROM_CONTINUE_WATCHING || 'true') === 'true',
  // how many upcoming programmes to list
  scheduleItems: num(process.env.SCHEDULE_ITEMS, 5),
  // blocks | ascii | none
  progressStyle: (process.env.PROGRESS_STYLE || 'ascii').toLowerCase(),
  tmdbKey: process.env.TMDB_API_KEY || '',
  tmdbLang: process.env.TMDB_LANGUAGE || 'en-US',
  port: num(process.env.PORT, 7000),
  publicUrl: (process.env.PUBLIC_URL || '').replace(/\/+$/, ''),
};

export function encodeConfig(cfg) {
  return Buffer.from(JSON.stringify(cfg), 'utf8').toString('base64url');
}

export function decodeConfig(segment) {
  const raw = JSON.parse(Buffer.from(segment, 'base64url').toString('utf8'));
  const cfg = {
    ...defaults,
    name: raw.name || defaults.name,
    m3u: Array.isArray(raw.m3u) ? raw.m3u : splitList(raw.m3u),
    epg: Array.isArray(raw.epg) ? raw.epg : splitList(raw.epg),
    includeGroups: Array.isArray(raw.includeGroups) ? raw.includeGroups : splitList(raw.includeGroups),
    excludeGroups: Array.isArray(raw.excludeGroups) ? raw.excludeGroups : splitList(raw.excludeGroups),
    posterShape: raw.posterShape || defaults.posterShape,
    splitGroups: raw.splitGroups === undefined ? defaults.splitGroups : !!raw.splitGroups,
    artwork: raw.artwork || defaults.artwork,
    progressStyle: raw.progressStyle || defaults.progressStyle,
    scheduleItems: num(raw.scheduleItems, defaults.scheduleItems),
    normalizeLogos:
      raw.normalizeLogos === undefined ? defaults.normalizeLogos : !!raw.normalizeLogos,
    tileBackground: raw.tileBackground || defaults.tileBackground,
    logoSource: raw.logoSource || defaults.logoSource,
    hideFromContinueWatching:
      raw.hideFromContinueWatching === undefined
        ? defaults.hideFromContinueWatching
        : !!raw.hideFromContinueWatching,
    epgOffsetHours: num(raw.epgOffsetHours, defaults.epgOffsetHours),
  };
  if (!cfg.m3u.length) throw new Error('config has no playlist');
  return cfg;
}

// Stable key used to cache parsed playlist + guide data per configuration.
export function configKey(cfg) {
  return JSON.stringify([cfg.m3u, cfg.epg, cfg.includeGroups, cfg.excludeGroups]);
}
