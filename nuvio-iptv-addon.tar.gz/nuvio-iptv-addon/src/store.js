import { parseM3U, filterChannels, normalizeKey } from './m3u.js';
import { loadGuide, attachGuide } from './epg.js';
import { configKey } from './config.js';
import { warmLogos } from './logos.js';
import { applyLogoDatabase } from './logodb.js';
import { loadXtream, xtreamEpgUrl, folderId } from './xtream.js';

const cache = new Map(); // configKey -> { promise, data, loadedAt, refreshing }

async function fetchText(url, userAgent) {
  const res = await fetch(url, {
    headers: { 'User-Agent': userAgent, Accept: '*/*' },
    redirect: 'follow',
  });
  if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
  return res.text();
}

async function build(cfg) {
  const started = Date.now();
  const warnings = [];

  let channels = [];
  let providerOrder = null; // category order as the Xtream panel lists them
  let xtreamInfo = null;

  if (cfg.xtream) {
    try {
      const x = await loadXtream(cfg.xtream, cfg.userAgent);
      channels = channels.concat(x.channels);
      providerOrder = x.categories;
      xtreamInfo = x.info;
    } catch (err) {
      warnings.push(`Xtream: ${err.message}`);
    }
  }

  for (const url of cfg.m3u) {
    try {
      const text = await fetchText(url, cfg.userAgent);
      channels = channels.concat(parseM3U(text));
    } catch (err) {
      warnings.push(`Playlist ${url}: ${err.message}`);
    }
  }
  channels = filterChannels(channels, cfg);

  // Drop duplicate ids that came from separate playlists.
  const byId = new Map();
  for (const c of channels) if (!byId.has(c.id)) byId.set(c.id, c);
  channels = [...byId.values()];

  let guideChannels = 0;
  // With an Xtream login and no EPG_URL, the panel's own guide is used.
  const epgUrls = cfg.epg.length ? cfg.epg : cfg.xtream ? [xtreamEpgUrl(cfg.xtream)] : [];
  if (epgUrls.length && channels.length) {
    const wanted = new Set();
    for (const c of channels) for (const k of c.epgKeys) wanted.add(normalizeKey(k));
    wanted.delete('');
    try {
      const guide = await loadGuide(epgUrls, wanted, {
        userAgent: cfg.userAgent,
        offsetHours: cfg.epgOffsetHours,
      });
      warnings.push(...guide.errors.map((e) => `Guide ${e}`));
      guideChannels = attachGuide(channels, guide);
    } catch (err) {
      warnings.push(`Guide: ${err.message}`);
    }
  } else {
    for (const c of channels) c.programmes = [];
  }

  // Swap in standardised artwork before anything is cached or served.
  let logoDb = { matched: 0 };
  try {
    logoDb = await applyLogoDatabase(channels, cfg);
  } catch (err) {
    warnings.push(`Logo database: ${err.message}`);
  }

  const present = new Set(channels.map((c) => c.group));
  let groups;
  if (providerOrder) {
    // Provider order first (it is usually curated), then anything from M3U.
    groups = providerOrder.filter((g) => present.has(g));
    for (const g of [...present].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))) {
      if (!groups.includes(g)) groups.push(g);
    }
  } else {
    groups = [...present].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }));
  }

  channels.sort((a, b) => {
    const an = Number(a.chno) || 0;
    const bn = Number(b.chno) || 0;
    if (an && bn && an !== bn) return an - bn;
    return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' });
  });

  // One folder per category, with its channels already in order.
  const folders = groups.map((name) => ({
    id: folderId(name),
    name,
    channels: channels.filter((c) => c.group === name),
  }));
  const folderById = new Map(folders.map((f) => [f.id, f]));

  return {
    channels,
    byId,
    groups,
    folders,
    folderById,
    xtreamInfo,
    guideChannels,
    logoDb,
    warnings,
    loadedAt: Date.now(),
    loadMs: Date.now() - started,
  };
}

/** Returns cached data immediately; kicks off a background refresh when stale. */
export async function getData(cfg) {
  const key = configKey(cfg);
  let entry = cache.get(key);

  if (!entry) {
    entry = { promise: null, data: null, refreshing: false };
    cache.set(key, entry);
  }

  if (!entry.data) {
    if (!entry.promise) {
      entry.promise = build(cfg)
        .then((data) => {
          entry.data = data;
          entry.promise = null;
          log(cfg, data);
          return data;
        })
        .catch((err) => {
          entry.promise = null;
          throw err;
        });
    }
    return entry.promise;
  }

  const age = Date.now() - entry.data.loadedAt;
  if (age > cfg.refreshHours * 3600000 && !entry.refreshing) {
    entry.refreshing = true;
    build(cfg)
      .then((data) => {
        entry.data = data;
        log(cfg, data);
      })
      .catch((err) => console.error('[refresh]', err.message))
      .finally(() => { entry.refreshing = false; });
  }

  return entry.data;
}

function log(cfg, data) {
  console.log(
    `[load] ${data.channels.length} channels, ${data.groups.length} groups, ` +
      `${data.guideChannels} with guide data, ${data.loadMs} ms`
  );
  for (const w of data.warnings) console.warn('[warn]', w);

  // Fire and forget; browsing works while this runs.
  if (cfg.normalizeLogos && cfg.warmLogos) {
    warmLogos(data.channels, cfg)
      .then((r) => { data.logoWarm = r; })
      .catch((err) => console.warn('[logos] warm-up failed:', err.message));
  }
}

export function cacheStats() {
  return [...cache.values()].map((e) => ({
    channels: e.data?.channels.length ?? 0,
    guideChannels: e.data?.guideChannels ?? 0,
    loadedAt: e.data ? new Date(e.data.loadedAt).toISOString() : null,
    warnings: e.data?.warnings ?? [],
  }));
}
