import { formatEpisode } from './epg.js';
import { lookupArtwork } from './tmdb.js';

const timeFmt = new Map();
function clock(ms, cfg) {
  const key = `${cfg.locale}|${cfg.clock24}`;
  let f = timeFmt.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat(cfg.locale, {
      hour: 'numeric',
      minute: '2-digit',
      hour12: !cfg.clock24,
    });
    timeFmt.set(key, f);
  }
  return f.format(new Date(ms));
}

function dayLabel(ms, cfg) {
  const d = new Date(ms);
  const today = new Date();
  const sameDay = d.toDateString() === today.toDateString();
  if (sameDay) return '';
  const tomorrow = new Date(today.getTime() + 86400000);
  if (d.toDateString() === tomorrow.toDateString()) return 'Tomorrow ';
  return new Intl.DateTimeFormat(cfg.locale, { weekday: 'short' }).format(d) + ' ';
}

export function nowNext(programmes, now = Date.now()) {
  if (!programmes || !programmes.length) return { current: null, next: null, later: [] };
  let idx = -1;
  for (let i = 0; i < programmes.length; i++) {
    const p = programmes[i];
    if (p.start <= now && p.stop > now) { idx = i; break; }
    if (p.start > now) break;
  }
  const upcoming = programmes.filter((p) => p.start > now);
  return {
    current: idx >= 0 ? programmes[idx] : null,
    next: upcoming[0] || null,
    later: upcoming.slice(1, 6),
  };
}

function bar(p, now) {
  const span = p.stop - p.start;
  if (span <= 0) return '';
  const pct = Math.min(100, Math.max(0, ((now - p.start) / span) * 100));
  const filled = Math.round(pct / 10);
  return `${'█'.repeat(filled)}${'░'.repeat(10 - filled)} ${Math.round(pct)}%`;
}

function programmeLine(p, cfg) {
  const ep = formatEpisode(p.episode);
  const bits = [p.title];
  if (ep) bits.push(ep);
  if (p.subTitle && p.subTitle !== p.title) bits.push(`“${p.subTitle}”`);
  return bits.join(' · ');
}

/** Short one-liner used in catalog tiles. */
export function shortStatus(ch, cfg, now = Date.now()) {
  const { current } = nowNext(ch.programmes, now);
  if (!current) return ch.group || '';
  return `● ${current.title} · until ${clock(current.stop, cfg)}`;
}

export function catalogItem(ch, cfg, now = Date.now()) {
  const { current } = nowNext(ch.programmes, now);
  const poster = ch.logo || placeholder(ch);
  return {
    id: ch.id,
    type: 'tv',
    name: ch.name,
    poster,
    posterShape: cfg.posterShape,
    logo: ch.logo || undefined,
    background: current?.icon || ch.logo || undefined,
    description: shortStatus(ch, cfg, now),
    genres: [ch.group].filter(Boolean),
    releaseInfo: current ? current.title : undefined,
  };
}

function placeholder(ch) {
  const label = encodeURIComponent(ch.name.slice(0, 18));
  return `https://placehold.co/500x500/101317/8ea0b5/png?text=${label}`;
}

export async function fullMeta(ch, cfg, now = Date.now()) {
  const { current, next, later } = nowNext(ch.programmes, now);
  const art = current && !current.icon ? await lookupArtwork(current.title, current.date, cfg) : null;

  const lines = [];

  if (current) {
    lines.push(`● ON NOW  ${clock(current.start, cfg)} – ${clock(current.stop, cfg)}`);
    lines.push(bar(current, now));
    lines.push('');
    lines.push(programmeLine(current, cfg));
    const tags = [];
    if (current.isNew) tags.push('NEW');
    if (current.date) tags.push(current.date);
    if (current.rating) tags.push(current.rating);
    if (art?.rating) tags.push(`★ ${art.rating}`);
    if (current.categories.length) tags.push(current.categories.slice(0, 3).join(', '));
    if (tags.length) lines.push(tags.join('  ·  '));
    const desc = current.desc || art?.overview || '';
    if (desc) { lines.push(''); lines.push(desc); }
    if (current.credits.length) lines.push(`With ${current.credits.slice(0, 5).join(', ')}`);
  } else if (ch.programmes.length) {
    lines.push('● LIVE  ·  nothing scheduled in the guide right now');
  } else {
    lines.push('● LIVE');
    lines.push(cfg.epg.length ? 'No guide data matched this channel.' : 'No guide configured.');
  }

  if (next) {
    lines.push('');
    lines.push(`NEXT  ${dayLabel(next.start, cfg)}${clock(next.start, cfg)}  ·  ${programmeLine(next, cfg)}`);
    if (next.desc) lines.push(next.desc.slice(0, 220));
  }

  if (later.length) {
    lines.push('');
    lines.push('LATER');
    for (const p of later) {
      lines.push(`  ${dayLabel(p.start, cfg)}${clock(p.start, cfg)}  ${p.title}`);
    }
  }

  const footer = [ch.group, ch.chno ? `Ch ${ch.chno}` : '', ch.language, ch.country]
    .filter(Boolean)
    .join('  ·  ');
  if (footer) { lines.push(''); lines.push(footer); }

  return {
    id: ch.id,
    type: 'tv',
    name: ch.name,
    poster: ch.logo || art?.poster || placeholder(ch),
    posterShape: cfg.posterShape,
    logo: ch.logo || undefined,
    background: current?.icon || art?.background || ch.logo || undefined,
    description: lines.join('\n').trim(),
    genres: [ch.group, ...(current?.categories || [])].filter(Boolean).slice(0, 6),
    releaseInfo: current ? current.title : 'Live',
    country: ch.country || undefined,
    language: ch.language || undefined,
    website: undefined,
    behaviorHints: { defaultVideoId: ch.id, hasScheduledVideos: false },
    streams: buildStreams(ch, cfg, now),
  };
}

export function buildStreams(ch, cfg, now = Date.now()) {
  const { current } = nowNext(ch.programmes, now);
  const isHls = /\.m3u8(\?|$)/i.test(ch.url);
  const hasHeaders = Object.keys(ch.headers || {}).length > 0;

  const title = [
    ch.name,
    current ? `${clock(current.start, cfg)} – ${clock(current.stop, cfg)}  ${current.title}` : 'Live',
    ch.group,
  ]
    .filter(Boolean)
    .join('\n');

  const stream = {
    name: `${cfg.name}${isHls ? ' · HLS' : ''}`,
    title,
    url: ch.url,
    behaviorHints: {
      notWebReady: !isHls || hasHeaders,
      bingeGroup: `iptv-${ch.group}`,
    },
  };

  if (hasHeaders) {
    stream.behaviorHints.proxyHeaders = { request: ch.headers };
  }

  return [stream];
}
