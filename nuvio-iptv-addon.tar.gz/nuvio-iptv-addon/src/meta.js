import { formatEpisode } from './epg.js';
import { lookupArtwork } from './artwork.js';

const timeFmt = new Map();
function clock(ms, cfg) {
  const key = `${cfg.locale}|${cfg.clock24}`;
  let f = timeFmt.get(key);
  if (!f) {
    f = new Intl.DateTimeFormat(cfg.locale, {
      hour: 'numeric',
      minute: '2-digit',
      hour12: !cfg.clock24,
    });
    timeFmt.set(key, f);
  }
  return f.format(new Date(ms));
}

function dayLabel(ms, cfg) {
  const d = new Date(ms);
  const today = new Date();
  if (d.toDateString() === today.toDateString()) return '';
  const tomorrow = new Date(today.getTime() + 86400000);
  if (d.toDateString() === tomorrow.toDateString()) return 'Tomorrow ';
  return new Intl.DateTimeFormat(cfg.locale, { weekday: 'short' }).format(d) + ' ';
}

export function nowNext(programmes, now = Date.now()) {
  if (!programmes || !programmes.length) return { current: null, next: null, later: [] };
  let current = null;
  for (const p of programmes) {
    if (p.start <= now && p.stop > now) { current = p; break; }
    if (p.start > now) break;
  }
  const upcoming = programmes.filter((p) => p.start > now);
  return { current, next: upcoming[0] || null, later: upcoming.slice(1, 9) };
}

/**
 * TV fonts on Android TV and Firestick often have no glyph for the block
 * characters U+2588/U+2591, which renders as a row of empty boxes. ASCII is
 * the default for that reason; `blocks` stays available for phone-only setups.
 */
function progress(p, now, cfg) {
  const span = p.stop - p.start;
  if (span <= 0) return '';
  const pct = Math.min(100, Math.max(0, ((now - p.start) / span) * 100));
  const left = Math.max(0, Math.round((p.stop - now) / 60000));
  const remaining = left >= 60
    ? `${Math.floor(left / 60)}h ${left % 60}m left`
    : `${left} min left`;

  if (cfg.progressStyle === 'none') return remaining;

  const filled = Math.round(pct / 10);
  const bar = cfg.progressStyle === 'blocks'
    ? '█'.repeat(filled) + '░'.repeat(10 - filled)
    : '[' + '='.repeat(filled) + '-'.repeat(10 - filled) + ']';
  return `${bar} ${Math.round(pct)}%  ·  ${remaining}`;
}

function programmeLine(p) {
  const ep = formatEpisode(p.episode);
  const bits = [p.title];
  if (ep) bits.push(ep);
  if (p.subTitle && p.subTitle !== p.title) bits.push(`"${p.subTitle}"`);
  return bits.join(' · ');
}

export function shortStatus(ch, cfg, now = Date.now()) {
  const { current } = nowNext(ch.programmes, now);
  if (!current) return ch.group || '';
  return `${current.title} · until ${clock(current.stop, cfg)}`;
}

function placeholder(ch) {
  const label = encodeURIComponent(ch.name.slice(0, 18));
  return `https://placehold.co/500x500/101317/8ea0b5/png?text=${label}`;
}

/**
 * Point the tile at our own normalizer rather than the provider's logo, so
 * every image arrives at the same dimensions and nothing gets cropped.
 * `base` is the addon's own URL, taken from the incoming request.
 */
function posterUrl(ch, cfg, base) {
  // Our own endpoint handles both cases: it normalizes a real logo, and draws
  // a matching tile when the channel has none or the provider's URL is dead.
  if (cfg.normalizeLogos && base) return `${base}/logo/${encodeURIComponent(ch.id)}.png`;
  return ch.logo || placeholder(ch);
}

export function catalogItem(ch, cfg, now = Date.now(), base = '') {
  const { current } = nowNext(ch.programmes, now);
  return {
    id: ch.id,
    type: 'tv',
    name: ch.name,
    poster: posterUrl(ch, cfg, base),
    posterShape: cfg.posterShape,
    logo: ch.logo || undefined,
    description: shortStatus(ch, cfg, now),
    genres: [ch.group].filter(Boolean),
    // A year here, never a title — players print releaseInfo where a year goes.
    releaseInfo: current?.date || undefined,
  };
}

export async function fullMeta(ch, cfg, now = Date.now(), base = '') {
  const { current, next, later } = nowNext(ch.programmes, now);
  const art = current ? await lookupArtwork(current.title, cfg) : null;

  const lines = [];

  if (current) {
    // Players clamp the description, so the programme leads and the
    // schedule follows.
    lines.push(programmeLine(current));

    const tags = [];
    if (current.isNew) tags.push('NEW');
    if (current.date) tags.push(current.date);
    if (current.categories.length) tags.push(current.categories.slice(0, 2).join(', '));
    if (current.rating) tags.push(current.rating);
    if (art?.rating) tags.push(`IMDb ${art.rating}`);
    if (tags.length) lines.push(tags.join('  ·  '));

    lines.push(`ON NOW  ${clock(current.start, cfg)} – ${clock(current.stop, cfg)}`);
    const bar = progress(current, now, cfg);
    if (bar) lines.push(bar);

    const desc = current.desc || art?.overview || '';
    if (desc) { lines.push(''); lines.push(desc); }
    if (current.credits.length) lines.push(`With ${current.credits.slice(0, 5).join(', ')}`);
  } else if (ch.programmes.length) {
    lines.push('LIVE');
    lines.push('Nothing scheduled in the guide for right now.');
  } else {
    lines.push('LIVE');
    lines.push(cfg.epg.length ? 'No guide data matched this channel.' : 'No guide configured.');
  }

  if (next) {
    lines.push('');
    lines.push(`NEXT  ${dayLabel(next.start, cfg)}${clock(next.start, cfg)}  ·  ${programmeLine(next)}`);
  }

  if (later.length) {
    lines.push('');
    lines.push('LATER');
    for (const p of later) {
      lines.push(`  ${dayLabel(p.start, cfg)}${clock(p.start, cfg)}   ${p.title}`);
    }
  }

  const footer = [ch.group, ch.chno ? `Ch ${ch.chno}` : '', ch.language].filter(Boolean).join('  ·  ');
  if (footer) { lines.push(''); lines.push(footer); }

  // Background priority: the guide's own programme image, then the artwork
  // provider, then nothing. The station logo is deliberately not a fallback —
  // stretching a square logo across the hero is what it looked like before.
  const background = current?.icon || art?.background || undefined;

  const genres = [ch.group, ...(current?.categories || [])].filter(Boolean).slice(0, 5);

  // The details panel renders `links` as labelled rows, so the schedule shows
  // up there too rather than only inside a description the player may clamp.
  const links = [];
  for (const g of genres) {
    links.push({ name: g, category: 'Genres', url: `stremio:///discover/tv?genre=${encodeURIComponent(g)}` });
  }
  for (const p of [next, ...later].filter(Boolean).slice(0, cfg.scheduleItems)) {
    links.push({
      name: `${dayLabel(p.start, cfg)}${clock(p.start, cfg)}  ${programmeLine(p)}`,
      category: 'Up next',
      url: `stremio:///search?search=${encodeURIComponent(p.title)}`,
    });
  }
  for (const person of current?.credits || []) {
    links.push({ name: person, category: 'Cast', url: `stremio:///search?search=${encodeURIComponent(person)}` });
  }

  const runtimeMin = current ? Math.round((current.stop - current.start) / 60000) : 0;

  // `defaultVideoId` is what marks this as a single resumable video, which is
  // what a player keys watch progress against. Dropping it is the only lever
  // the addon protocol gives us here.
  const behaviorHints = cfg.hideFromContinueWatching
    ? { hasScheduledVideos: false }
    : { defaultVideoId: ch.id, hasScheduledVideos: false };

  return {
    id: ch.id,
    type: 'tv',
    name: ch.name,
    poster: posterUrl(ch, cfg, base),
    posterShape: cfg.posterShape,
    logo: ch.logo || undefined,
    background,
    description: lines.join('\n').trim(),
    genres,
    links,
    cast: current?.credits?.length ? current.credits.slice(0, 5) : undefined,
    runtime: runtimeMin ? `${runtimeMin} min` : undefined,
    releaseInfo: current?.date || art?.year || undefined,
    country: ch.country || undefined,
    language: ch.language || undefined,
    behaviorHints,
    streams: buildStreams(ch, cfg, now),
  };
}

export function buildStreams(ch, cfg, now = Date.now()) {
  const { current } = nowNext(ch.programmes, now);
  const isHls = /\.m3u8(\?|$)/i.test(ch.url);
  const hasHeaders = Object.keys(ch.headers || {}).length > 0;

  const title = [
    ch.name,
    current ? `${clock(current.start, cfg)} – ${clock(current.stop, cfg)}  ${current.title}` : 'Live',
    ch.group,
  ].filter(Boolean).join('\n');

  const stream = {
    name: `${cfg.name}${isHls ? ' · HLS' : ''}`,
    title,
    url: ch.url,
    behaviorHints: {
      notWebReady: !isHls || hasHeaders,
    },
  };
  // bingeGroup exists to chain episodes together and carries resume behaviour
  // with it; a live channel has nothing to chain to.
  if (!cfg.hideFromContinueWatching) stream.behaviorHints.bingeGroup = `iptv-${ch.group}`;
  if (hasHeaders) stream.behaviorHints.proxyHeaders = { request: ch.headers };
  return [stream];
}
