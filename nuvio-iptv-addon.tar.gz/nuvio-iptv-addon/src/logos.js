import sharp from 'sharp';

// Station logos arrive in every shape a provider felt like: wide wordmarks,
// tall badges, transparent PNGs, 90x90 JPEGs. A player drops each one into a
// fixed tile and crops to fill, which is why some read as zoomed-in fragments.
// Fitting every logo onto one canvas, with padding rather than cropping, is
// the only way to get a row that looks deliberate.

const cache = new Map(); // key -> { at, buf, type }
const TTL_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_ENTRIES = 1500;
const FETCH_TIMEOUT_MS = 8000;
const MAX_SOURCE_BYTES = 6 * 1024 * 1024;

export function tileSize(cfg) {
  switch (cfg.posterShape) {
    case 'landscape': return { width: 640, height: 360 };
    case 'poster': return { width: 480, height: 720 };
    default: return { width: 480, height: 480 };
  }
}

function parseColor(value) {
  if (!value || value === 'transparent') return { r: 0, g: 0, b: 0, alpha: 0 };
  const m = /^#?([0-9a-f]{6})$/i.exec(value.trim());
  if (!m) return { r: 16, g: 19, b: 23, alpha: 1 };
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255, alpha: 1 };
}

async function fetchImage(url, userAgent) {
  const res = await fetch(url, {
    headers: { 'User-Agent': userAgent, Accept: 'image/*' },
    redirect: 'follow',
    signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
  });
  if (!res.ok) throw new Error(`logo ${res.status}`);
  const len = Number(res.headers.get('content-length') || 0);
  if (len > MAX_SOURCE_BYTES) throw new Error('logo too large');
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length > MAX_SOURCE_BYTES) throw new Error('logo too large');
  return buf;
}

/**
 * Returns a PNG of exactly the tile dimensions, logo centred, aspect intact.
 * `padding` leaves breathing room so wordmarks don't run edge to edge.
 */
export async function normalizeLogo(url, cfg) {
  const { width, height } = tileSize(cfg);
  const key = `${url}|${width}x${height}|${cfg.tileBackground}`;

  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.buf;

  const source = await fetchImage(url, cfg.userAgent);
  const background = parseColor(cfg.tileBackground);
  const inset = 0.84; // logo occupies 84% of the tile, leaving even margins

  // Scale down to fit the inset box, then pad out to the exact tile size.
  // Resizing twice would scale the logo back up to full bleed and undo it.
  const inner = await sharp(source, { animated: false })
    .resize({
      width: Math.round(width * inset),
      height: Math.round(height * inset),
      fit: 'inside',
      withoutEnlargement: false,
    })
    .toBuffer({ resolveWithObject: true });

  const padX = Math.max(0, width - inner.info.width);
  const padY = Math.max(0, height - inner.info.height);

  let pipeline = sharp(inner.data).extend({
    left: Math.floor(padX / 2),
    right: Math.ceil(padX / 2),
    top: Math.floor(padY / 2),
    bottom: Math.ceil(padY / 2),
    background,
  });

  if (background.alpha === 1) pipeline = pipeline.flatten({ background });

  const buf = await pipeline.png({ compressionLevel: 9 }).toBuffer();

  if (cache.size > MAX_ENTRIES) cache.clear();
  cache.set(key, { at: Date.now(), buf });
  return buf;
}

/** Initials for a channel with no usable logo: "CA: CTV Life" -> "CL". */
function initials(name) {
  const words = String(name || '')
    .replace(/^[A-Z]{2,3}\s*[:|]\s*/i, '') // drop a "CA:" style country prefix
    .replace(/[^A-Za-z0-9 ]+/g, ' ')
    .split(/\s+/)
    .filter(Boolean);
  if (!words.length) return 'TV';
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  return (words[0][0] + words[1][0]).toUpperCase();
}

/**
 * A tile in the same dimensions and background as a normalized logo, so a
 * channel with a missing or dead logo still lines up with the rest of the row.
 */
export async function placeholderTile(name, cfg) {
  const { width, height } = tileSize(cfg);
  const key = `placeholder|${name}|${width}x${height}|${cfg.tileBackground}`;
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.buf;

  const bg = parseColor(cfg.tileBackground);
  const fill = bg.alpha === 1 ? `rgb(${bg.r},${bg.g},${bg.b})` : '#101317';
  const size = Math.round(Math.min(width, height) * 0.34);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
    <rect width="100%" height="100%" fill="${fill}"/>
    <text x="50%" y="50%" dy="0.35em" text-anchor="middle"
      font-family="DejaVu Sans, Noto Sans, sans-serif" font-size="${size}"
      font-weight="600" fill="#8ea0b5">${initials(name)}</text>
  </svg>`;

  const buf = await sharp(Buffer.from(svg)).png({ compressionLevel: 9 }).toBuffer();
  if (cache.size > MAX_ENTRIES) cache.clear();
  cache.set(key, { at: Date.now(), buf });
  return buf;
}

export function logoCacheStats() {
  return { cached: cache.size };
}
