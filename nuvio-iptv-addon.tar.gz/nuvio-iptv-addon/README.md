# IPTV addon for Nuvio

A self-hosted addon that turns your own M3U playlist into a proper live TV section in Nuvio: station logos on every tile, and a channel page that shows what is on now, how far through it is, what is next, and what follows after that — read from your XMLTV guide.

Nuvio speaks the Stremio addon protocol, so the same container works in Stremio, Vidi, and anything else that installs addons from a manifest URL.

It hosts nothing itself. You bring the playlist and guide URLs from a service you already pay for.

---

## Quick start

```bash
git clone <this folder>   # or just copy it onto your server
cd nuvio-iptv-addon
cp .env.example .env      # then edit M3U_URL and EPG_URL
docker compose up -d --build
```

Open `http://<your-server>:7000/configure` to check it is alive, then in Nuvio:

**Settings → Addons → Add Addon**, paste `http://<your-server>:7000/manifest.json`, select **Install Addon**.

Your channels show up under **TV**.

Watch the first load to confirm it found things:

```bash
docker compose logs -f
# [load] 1284 channels, 46 groups, 1190 with guide data, 8422 ms
```

`curl http://<your-server>:7000/health` gives the same numbers plus any warnings.

---

## Configuration

Everything lives in `.env`. Only `M3U_URL` is required.

| Variable | Default | What it does |
| --- | --- | --- |
| `M3U_URL` | — | Playlist URL. Comma-separate to merge several. |
| `EPG_URL` | — | XMLTV guide URL, plain or `.xml.gz`. Comma-separate for several. |
| `ADDON_NAME` | `IPTV` | Name shown in Nuvio's addon list and on the catalog row. |
| `POSTER_SHAPE` | `square` | `square` suits station logos; also `landscape` or `poster`. |
| `NORMALIZE_LOGOS` | `true` | Letterboxes every station logo onto one canvas so tiles are the same size and nothing is cropped. |
| `WARM_LOGOS` | `true` | Pre-fetches logos after each load so tiles are instant and fetch problems surface in the log. |
| `INSECURE_TLS` | `false` | Skips certificate checks. Only for logo hosts with broken or self-signed certificates. |
| `TILE_BACKGROUND` | `#101317` | Colour behind the logo on a tile, or `transparent`. |
| `SPLIT_GROUPS` | `false` | `true` gives every playlist group its own row on the home screen. |
| `MAX_SPLIT_GROUPS` | `30` | Cap on those rows. |
| `INCLUDE_GROUPS` | — | Keep only groups whose name contains one of these. |
| `EXCLUDE_GROUPS` | — | Drop groups whose name contains one of these. |
| `REFRESH_HOURS` | `6` | How often the playlist and guide are re-fetched. |
| `EPG_OFFSET_HOURS` | `0` | Shift guide times when a provider publishes the wrong offset. |
| `DISPLAY_LOCALE` | `en-US` | Locale for day and time formatting. |
| `TIME_FORMAT` | `12` | `12` or `24`. |
| `TZ` | container default | Set this, or every time reads in UTC. |
| `USER_AGENT` | a browser string | Sent when fetching the playlist and guide. |
| `ARTWORK` | `cinemeta` | Where the channel-page background comes from when the guide has no image: `cinemeta`, `tmdb`, or `off`. |
| `HIDE_FROM_CONTINUE_WATCHING` | `true` | Omits the hints a player uses to track resumable progress, so channels stay out of Continue Watching. |
| `SCHEDULE_ITEMS` | `5` | How many upcoming programmes appear under "Up next" in the details panel. |
| `PROGRESS_STYLE` | `ascii` | `ascii`, `blocks`, or `none`. Block characters draw as empty boxes in many TV fonts. |
| `TMDB_API_KEY` | — | Only needed when `ARTWORK=tmdb`. |
| `PORT` | `7000` | Listening port. |

Change anything in `.env`, then `docker compose up -d` to apply it.

### Several playlists from one container

Instead of putting a playlist in `.env`, fill in the form at `/configure`. It builds a manifest URL with the settings baked into it:

```
http://your-server:7000/eyJuYW1lIjoi…/manifest.json
```

Install as many of those as you like — one per provider, or one trimmed to just the kids' channels. Each keeps its own cache. The plain `/manifest.json` keeps serving whatever is in `.env`.

---

## Reaching it from outside your network

The addon is plain HTTP with no authentication, so treat the URL as a secret — your playlist credentials are inside it.

On the same LAN, the server's IP is enough. From outside, put it behind a reverse proxy with TLS (Caddy, Traefik, nginx) or a tunnel such as Tailscale, and set `PUBLIC_URL` so the configure page prints the right address. Do not forward port 7000 straight to the internet.

---

## Troubleshooting

**Channels appear, guide is empty.** The playlist's `tvg-id` values do not match the guide's channel ids. The addon already matches loosely — it ignores case, punctuation, and suffixes like HD or FHD, and falls back to `display-name` — but some providers ship guides for a different lineup entirely. Check a channel's `tvg-id` in the playlist against an `<channel id="…">` in the XML. `/health` reports how many channels matched.

**Times are all wrong by a fixed amount.** Set `TZ` first. If they are still off by whole hours, the guide is publishing bad offsets — correct it with `EPG_OFFSET_HOURS`.

**A channel loads then stops.** Providers usually allow one or two connections at a time. If another device or a second Nuvio screen is on the same line, the new stream wins and the old one drops.

**Nothing plays at all.** Some providers only serve their own player. Copy the user agent your working player sends into `USER_AGENT`. Playlists with `#EXTVLCOPT:http-user-agent` lines are handled per channel automatically.

**The background is the station logo, stretched.** That was the behaviour before 1.1.0. Now the background comes from the guide's own programme image, then from `ARTWORK`, and is left empty if neither has one — a blank hero looks better than a blown-up square logo. Nuvio caches metadata per channel, so remove and re-add the addon once after upgrading.

**The progress bar shows empty boxes.** The font on that device has no glyph for the block characters. `PROGRESS_STYLE=ascii` is the default for this reason; if you set it to `blocks` and see boxes, set it back.

**Channels keep appearing in Continue Watching.** `HIDE_FROM_CONTINUE_WATCHING=true` (the default from 1.3.0) removes the `defaultVideoId` and `bingeGroup` hints a player uses to treat something as resumable. That covers what the addon protocol lets a server control, but the row itself is built from the player's own library, so entries added before the upgrade stay until you remove them — long-press an entry in Nuvio and remove it. If channels still land there afterwards, the tracking is happening entirely client-side and the fix has to come from Nuvio's settings, or from turning off Trakt scrobbling if you have it connected.

**Play stopped working after that.** Set `HIDE_FROM_CONTINUE_WATCHING=false`. Some players rely on `defaultVideoId` to know what the Play button should launch.

**Tiles are cropped or zoomed in.** Providers ship logos in every aspect ratio — wide wordmarks, tall badges, tiny squares — and players crop them to fill a fixed frame. With `NORMALIZE_LOGOS=true` the addon serves each logo through `/logo/<id>.png`, scaled to fit and padded onto a tile matching `POSTER_SHAPE`, so nothing is cropped. Channels with a missing or dead logo get a tile of the same size showing their initials. Set `TILE_BACKGROUND` to match your theme.

**Every tile shows initials instead of the logo.** The container could not fetch the logos. From 1.5.0 it tries four combinations per logo — browser user agent, a `Referer` header, a VLC user agent, and the opposite scheme — because logo hosts vary in what they will serve to a server rather than a browser. Anything still failing falls back to the provider's own URL, which the player fetches directly as it did before. The startup log reports the tally:

```
[logos] 1183 fetched, 12 failed — first failure: CA: CTV Life: HTTP 403 (http://...)
```

To dig into a specific failure:

```bash
curl -s http://localhost:7000/health | grep -o '"failures".*'
docker compose logs | grep '\[logo\]'
```

Then try the same fetch from inside the container, using a logo URL from your playlist:

```bash
docker compose exec iptv-addon wget -S -O /dev/null "<logo url>"
```

A DNS error means the container has no working resolver — check the `dns` settings on your Docker network. A certificate error is what `INSECURE_TLS=true` is for. A timeout usually means the logo host is only routable from inside your provider's network, in which case normalization cannot work from that machine and `NORMALIZE_LOGOS=false` is the honest setting.

**Guide loads slowly.** Full-country XMLTV files can be hundreds of megabytes. It is parsed as a stream and only programmes for channels in your playlist are kept, but the first fetch still takes a while. Later requests are served from cache while the refresh happens in the background.

**Too many channels.** `EXCLUDE_GROUPS=adult,ppv,24/7` trims the usual noise; `INCLUDE_GROUPS` is the stricter option when you only want a handful of groups.

---

## How it fits together

```
src/server.js     addon protocol routes: manifest, catalog, meta, stream
src/config.js     env vars and the base64 config carried in the URL
src/m3u.js        playlist parser: attributes, groups, per-channel headers
src/epg.js        streaming XMLTV parser, gzip aware, filters as it reads
src/store.js      per-config cache with background refresh
src/meta.js       now/next assembly, descriptions, stream objects
src/artwork.js    programme artwork via Cinemeta or TMDB
src/logos.js      logo normalizer and placeholder tiles
```

Anything the addon returns is generated on request from the cached playlist and guide, so the progress bar and now/next stay honest without re-fetching anything.

---

## Running without Docker

```bash
npm install
M3U_URL=… EPG_URL=… npm start
```

Node 20 or newer.
