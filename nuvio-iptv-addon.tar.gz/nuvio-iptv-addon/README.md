# IPTV addon for Nuvio

A self-hosted addon that turns your own Xtream Codes login (or M3U playlist) into a proper live TV section in Nuvio: station logos on every tile, and a channel page that shows what is on now, how far through it is, what is next, and what follows after that — read from your XMLTV guide.

Nuvio speaks the Stremio addon protocol, so the same container works in Stremio, Vidi, and anything else that installs addons from a manifest URL.

It hosts nothing itself. You bring the playlist and guide URLs from a service you already pay for.

---

## Quick start

```bash
git clone <this folder>   # or just copy it onto your server
cd nuvio-iptv-addon
cp .env.example .env      # then fill in XTREAM_URL, XTREAM_USERNAME, XTREAM_PASSWORD
docker compose up -d --build
```

Check it is alive with `http://<your-server>:7000/health`, then in Nuvio:

**Settings → Addons → Add Addon**, paste `http://<your-server>:7000/manifest.json`, select **Install Addon**.

Your channels show up under **TV** in one **Live** row. Pushed through the
provisioner you also get a **Live TV** collection: a folder per category that
opens into a square grid of channels.

Watch the first load to confirm it found things:

```bash
docker compose logs -f
# [load] 1284 channels, 46 groups, 1190 with guide data, 8422 ms
```

`curl http://<your-server>:7000/health` gives the same numbers plus any warnings.

---

## Configuration

Everything lives in `.env`. You need an Xtream login (`XTREAM_*`) or an `M3U_URL`.

| Variable | Default | What it does |
| --- | --- | --- |
| `XTREAM_URL` | — | Xtream Codes server, e.g. `https://tv.kohnor.ca`. When set, it is the only panel the addon will use. |
| `API_KEY` | — | Turns on `POST /api/manifest` (personal links). Required to use it. |
| `CONFIG_SECRET` | — | Encrypts the login inside issued links. |
| `TRUST_PROXY` | private ranges | Which proxies to trust for the client address (rate limiting). |
| `XTREAM_USERNAME` | — | Xtream username. |
| `XTREAM_PASSWORD` | — | Xtream password. |
| `XTREAM_OUTPUT` | `ts` | Stream format: `ts` or `m3u8`. |
| `FOLDERS` | `false` | An in-app Categories row of folder tiles. Off because the Live TV collection already gives a folder per category. |
| `FOLDER_CATALOG_NAME` | `Categories` | Heading for the folder row. |
| `CATEGORY_CATALOGS` | `false` | Also publish one catalog per category. Not needed for the collection; each becomes its own row. |
| `COLLECTION_NAME` | `Live TV` | Title of the collection served at `/collection.json`. |
| `SHOW_ALL_CHANNELS` | `true` | Keep the flat all-channels row (used for search) beside the folders. |
| `M3U_URL` | — | Playlist URL. Comma-separate to merge several. Optional with Xtream; both can be used together. |
| `EPG_URL` | — | XMLTV guide URL, plain or `.xml.gz`. Comma-separate for several. Blank with Xtream = the panel's own guide. |
| `ADDON_NAME` | `IPTV` | Name shown in Nuvio's addon list. |
| `CATALOG_NAME` | `Live` | Heading for the row on the home screen. The player appends the content type, so `Live` renders as "Live - TV". |
| `POSTER_SHAPE` | `square` | `square` suits station logos; also `landscape` or `poster`. |
| `NORMALIZE_LOGOS` | `true` | Letterboxes every station logo onto one canvas so tiles are the same size and nothing is cropped. |
| `LOGO_SOURCE` | `playlist` | `playlist` uses your provider's artwork. `repo` prefers the iptv-org database, `repo-only` uses nothing else. |
| `WARM_LOGOS` | `true` | Pre-fetches logos after each load so tiles are instant and fetch problems surface in the log. |
| `INSECURE_TLS` | `false` | Skips certificate checks. Only for logo hosts with broken or self-signed certificates. |
| `TILE_BACKGROUND` | `#101317` | Colour behind the logo on a tile, or `transparent`. |
| `SPLIT_GROUPS` | `false` | `true` gives every playlist group its own row on the home screen. |
| `MAX_SPLIT_GROUPS` | `200` | Cap on category catalogs and split rows. |
| `INCLUDE_GROUPS` | — | Keep only groups whose name contains one of these. |
| `EXCLUDE_GROUPS` | — | Drop groups whose name contains one of these. |
| `REFRESH_HOURS` | `6` | How often the playlist and guide are re-fetched. |
| `EPG_OFFSET_HOURS` | `0` | Shift guide times when a provider publishes the wrong offset. |
| `DISPLAY_LOCALE` | `en-US` | Locale for day and time formatting. |
| `TIME_FORMAT` | `12` | `12` or `24`. |
| `TZ` | container default | Set this, or every time reads in UTC. |
| `USER_AGENT` | a browser string | Sent when fetching the playlist and guide. |
| `BACKGROUND_SOURCE` | `station` | `station` builds a backdrop from the channel logo, `programme` prefers artwork for what's airing, `none` leaves it empty. |
| `ARTWORK` | `cinemeta` | Where the channel-page background comes from when the guide has no image: `cinemeta`, `tmdb`, or `off`. |
| `HIDE_FROM_CONTINUE_WATCHING` | `true` | Omits the hints a player uses to track resumable progress, so channels stay out of Continue Watching. |
| `SCHEDULE_ITEMS` | `5` | How many upcoming programmes appear under "Up next" in the details panel. |
| `PROGRESS_STYLE` | `ascii` | `ascii`, `blocks`, or `none`. Block characters draw as empty boxes in many TV fonts. |
| `TMDB_API_KEY` | — | Only needed when `ARTWORK=tmdb`. |
| `PORT` | `7000` | Listening port. |

Change anything in `.env`, then `docker compose up -d` to apply it.

### Several playlists from one container

Settings can also be carried in the manifest URL itself, as base64url-encoded JSON, so one container can serve several playlists:

```
http://your-server:7000/eyJuYW1lIjoi…/manifest.json
```

Build one with:

```bash
node -e "console.log(Buffer.from(JSON.stringify({name:'Kids',m3u:['<url>'],epg:['<url>'],includeGroups:['kids']})).toString('base64url'))"

# or with an Xtream login
node -e "console.log(Buffer.from(JSON.stringify({name:'Main',xtream:{url:'http://host:8080',username:'U',password:'P'}})).toString('base64url'))"
```

Install as many as you like — each keeps its own cache. The plain `/manifest.json` keeps serving whatever is in `.env`, and that is all most setups need.

---

## Reaching it from outside your network

The addon is plain HTTP with no authentication, so treat the URL as a secret — your playlist credentials are inside it.

On the same LAN, the server's IP is enough. From outside, put it behind a reverse proxy with TLS (Caddy, Traefik, nginx) or a tunnel such as Tailscale, and set `PUBLIC_URL` so generated image URLs point at the right address. Do not forward port 7000 straight to the internet.

---

## Personal manifest links (API)

To give each customer their own link, set `XTREAM_URL`, `API_KEY` and
(recommended) `CONFIG_SECRET`, then call:

```bash
curl -X POST https://redirect.kohnor.ca/api/manifest \
  -H "Authorization: Bearer $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"username":"alice","password":"her-password"}'
```

```json
{
  "ok": true,
  "manifestUrl": "https://redirect.kohnor.ca/enc-.../manifest.json",
  "installUrl": "stremio://redirect.kohnor.ca/enc-.../manifest.json",
  "encrypted": true,
  "account": { "username": "alice", "status": "Active", "expires": "2026-10-30T00:01:56.000Z", "maxConnections": 2, "activeConnections": 0 }
}
```

The login is checked against the panel first, so a wrong password or expired
account never becomes a link:

| Status | Meaning |
| --- | --- |
| `200` | Link created. |
| `400` | Username or password missing. |
| `401` | Missing or wrong `API_KEY`, or (with a `code` of `auth`) the panel rejected the login. |
| `403` | The account is expired or disabled (`code: expired`). |
| `429` | More than 20 requests a minute from one address. |
| `502` | The panel could not be reached. |
| `503` | `API_KEY` or `XTREAM_URL` is not set. |

Notes:

- The panel address never appears in a link. Even a hand-made link naming
  another host is ignored, so the container can only ever talk to `XTREAM_URL`.
- With `CONFIG_SECRET` set, links are AES-256-GCM encrypted (`enc-` prefix). A
  changed character makes the link invalid. Without it, the link is plain
  base64 and the password can be read by anyone holding the link.
- Keep `API_KEY` on the server that calls this endpoint. It lets its holder
  test logins against your panel.
- Each customer's link keeps its own cache, so a wrong guess at someone's
  username cannot affect their real link, and failed logins are never cached.

---

## A Live TV collection in Nuvio

`GET /<your-link>/collection.json` returns a ready-made Nuvio collection: one
folder per category, each bound to that category's catalog, with `SQUARE` tiles
so station logos are not cropped. The provisioner fetches this and pushes it
beside Streaming and Genres, giving you a **Live TV** row whose folders open
into a square grid of channels.

```bash
curl -s https://redirect.kohnor.ca/<your-link>/collection.json | jq '.collection.folders[].title'
```

Folder and collection ids are derived from the addon id and the category name,
so re-pushing updates the same folders rather than duplicating them. Add
`?title=Channels` to rename the collection, or set `COLLECTION_NAME`.

The addon publishes a **single** channels catalog. Each folder points at that
same catalog with its category as the `genre` filter, so there is one catalog
and the folders live inside it. `CATEGORY_CATALOGS=true` additionally publishes
a catalog per category, which is not needed for the collection and shows each
one as its own row, so it is off by default.

---

## Xtream Codes and folders

The addon logs in to `player_api.php`, reads the live categories and streams, and builds the same channel list it would get from an M3U file, so logos, guide and now/next all work as before. Streams play from `<server>/live/<user>/<pass>/<id>.<ext>`.

Each category becomes a folder tile. Opening one shows its channels as a list; choosing a channel plays it. Categories keep the order the provider lists them in. Channels inside a folder are alphabetical.

**Nothing loads.** `docker compose logs` shows a `[warn] Xtream: ...` line saying why: rejected login, expired account, or a server that did not return JSON. `/health` repeats it.

**Folders appear but a channel will not play.** Try `XTREAM_OUTPUT=m3u8`. Some panels only serve one format.

**Folders do not show after upgrading.** Nuvio caches the manifest. Remove and re-add the addon once.

**Many categories.** `EXCLUDE_GROUPS` and `INCLUDE_GROUPS` match on category names and trim folders too.

---

## Troubleshooting

**Channels appear, guide is empty.** The playlist's `tvg-id` values do not match the guide's channel ids. The addon already matches loosely — it ignores case, punctuation, and suffixes like HD or FHD, and falls back to `display-name` — but some providers ship guides for a different lineup entirely. Check a channel's `tvg-id` in the playlist against an `<channel id="…">` in the XML. `/health` reports how many channels matched.

**Times are all wrong by a fixed amount.** Set `TZ` first. If they are still off by whole hours, the guide is publishing bad offsets — correct it with `EPG_OFFSET_HOURS`.

**A channel loads then stops.** Providers usually allow one or two connections at a time. If another device or a second Nuvio screen is on the same line, the new stream wins and the old one drops.

**Nothing plays at all.** Some providers only serve their own player. Copy the user agent your working player sends into `USER_AGENT`. Playlists with `#EXTVLCOPT:http-user-agent` lines are handled per channel automatically.

**The background.** With `BACKGROUND_SOURCE=station` (the default) the channel page shows a backdrop generated from the station logo — the logo enlarged, blurred and darkened as a wash, with the crisp logo centred on top. It is stable, always available, and does not depend on guide artwork. `programme` swaps in artwork for whatever is airing when it can be found, which looks better on channels with a good guide but falls back to the station backdrop otherwise. `ARTWORK` is only consulted in `programme` mode.

**The background used to be the station logo, stretched.** That was the behaviour before 1.1.0. Now the background comes from the guide's own programme image, then from `ARTWORK`, and is left empty if neither has one — a blank hero looks better than a blown-up square logo. Nuvio caches metadata per channel, so remove and re-add the addon once after upgrading.

**The progress bar shows empty boxes.** The font on that device has no glyph for the block characters. `PROGRESS_STYLE=ascii` is the default for this reason; if you set it to `blocks` and see boxes, set it back.

**Channels keep appearing in Continue Watching.** `HIDE_FROM_CONTINUE_WATCHING=true` (the default from 1.3.0) removes the `defaultVideoId` and `bingeGroup` hints a player uses to treat something as resumable. That covers what the addon protocol lets a server control, but the row itself is built from the player's own library, so entries added before the upgrade stay until you remove them — long-press an entry in Nuvio and remove it. If channels still land there afterwards, the tracking is happening entirely client-side and the fix has to come from Nuvio's settings, or from turning off Trakt scrobbling if you have it connected.

**Play stopped working after that.** Set `HIDE_FROM_CONTINUE_WATCHING=false`. Some players rely on `defaultVideoId` to know what the Play button should launch.

**Tiles are cropped or zoomed in.** Providers ship logos in every aspect ratio — wide wordmarks, tall badges, tiny squares — and players crop them to fill a fixed frame. With `NORMALIZE_LOGOS=true` the addon serves each logo through `/logo/<id>.png`, scaled to fit and padded onto a tile matching `POSTER_SHAPE`, so nothing is cropped. Channels with a missing or dead logo get a tile of the same size showing their initials. Set `TILE_BACKGROUND` to match your theme.

**How a tile is chosen.** In order: the logo fitted onto a consistent canvas; failing that, the logo passed through at whatever size and format the host returned; failing that, a redirect so the player fetches it directly. Initials appear only when a channel has no `tvg-logo` at all. A logo that is an odd size is better than no logo, so nothing is rejected for being too small, too large, or served with the wrong content type.

**Every tile shows initials instead of the logo.** The container could not fetch the logos. From 1.5.0 it tries four combinations per logo — browser user agent, a `Referer` header, a VLC user agent, and the opposite scheme — because logo hosts vary in what they will serve to a server rather than a browser. Anything still failing falls back to the provider's own URL, which the player fetches directly as it did before. The startup log reports the tally:

```
[logos] 1183 fetched, 12 failed — first failure: CA: CTV Life: HTTP 403 (http://...)
```

`/health` splits the tile cache so a wall of placeholders cannot masquerade as success:

```bash
curl -s http://localhost:7000/health | grep -o '"logos".*'
# "logos":{"normalized":1183,"placeholder":12,"failures":{...}}
```

A high `placeholder` count means the logos are not being fetched. To see exactly why, for one channel:

```bash
curl -s "http://localhost:7000/logo/<channel-id>/debug" 
```

That reports the fetch status, content type, first bytes, and whether the image decoded — enough to tell a refused request from an unreadable file. To dig further:

```bash
curl -s http://localhost:7000/health | grep -o '"failures".*'
docker compose logs | grep '\[logo\]'
```

Then try the same fetch from inside the container, using a logo URL from your playlist:

```bash
docker compose exec iptv-addon wget -S -O /dev/null "<logo url>"
```

A DNS error means the container has no working resolver — check the `dns` settings on your Docker network. A certificate error is what `INSECURE_TLS=true` is for. A timeout usually means the logo host is only routable from inside your provider's network, in which case normalization cannot work from that machine and `NORMALIZE_LOGOS=false` is the honest setting.

**The description stops partway.** Players commonly render only the first paragraph of a description, so from 1.11.0 the addon emits no blank lines at all and puts the synopsis directly under the title. If your player still shows only the first line or two, that is a clamp on its side — the full text is in the `meta` response either way.

**No description for what's on.** Many provider guides carry only a title and times, with no `<desc>` element. In that case the addon looks the title up with `ARTWORK` (Cinemeta by default) and uses its synopsis, which is why the setting matters even when `BACKGROUND_SOURCE=station`. To see which side is empty:

```bash
curl -s "http://localhost:7000/guide/<channel-id>/debug"
```

That reports how many programmes carry a description and dumps the raw fields for what is airing now. If `programmesWithDescription` is 0, the guide is the gap and the lookup is doing the work; a title the catalog does not recognise (local news, sports fixtures, generic strands like "Movie") will still come up blank.

**Guide loads slowly.** Full-country XMLTV files can be hundreds of megabytes. It is parsed as a stream and only programmes for channels in your playlist are kept, but the first fetch still takes a while. Later requests are served from cache while the refresh happens in the background.

**Too many channels.** `EXCLUDE_GROUPS=adult,ppv,24/7` trims the usual noise; `INCLUDE_GROUPS` is the stricter option when you only want a handful of groups.

---

## How it fits together

```
src/server.js     addon protocol routes: manifest, catalog, meta, stream
src/config.js     env vars and the base64 config carried in the URL
src/m3u.js        playlist parser: attributes, groups, per-channel headers
src/xtream.js     Xtream Codes API loader: categories, live streams, guide URL
src/epg.js        streaming XMLTV parser, gzip aware, filters as it reads
src/store.js      per-config cache with background refresh
src/meta.js       now/next assembly, descriptions, stream objects
src/artwork.js    programme artwork via Cinemeta or TMDB
src/logos.js      logo normalizer, station backdrops, placeholder tiles
src/logodb.js     optional iptv-org logo database (LOGO_SOURCE=repo)
```

Anything the addon returns is generated on request from the cached playlist and guide, so the progress bar and now/next stay honest without re-fetching anything.

---

## Running without Docker

```bash
npm install
M3U_URL=… EPG_URL=… npm start
```

Node 20 or newer.
