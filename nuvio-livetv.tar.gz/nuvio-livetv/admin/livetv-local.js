// Live TV, resolved in-process.
//
// The split build called the addon over HTTP, which meant an API key and a
// container-to-container URL that could silently be wrong. Here the addon is
// the same process, so we call its own functions: nothing to misconfigure, and
// no network hop to fail.
import crypto from 'node:crypto';
import { defaults } from '../src/config.js';
import { checkLogin } from '../src/xtream.js';
import { encodeConfig } from '../src/config.js';
import { buildCollection } from '../src/manifest.js';
import { getData } from '../src/store.js';

export const liveTvApiConfigured = () => Boolean(defaults.xtreamServer);

const TTL_MS = 5 * 60 * 1000;
const memo = new Map();

function fail(message, status) {
  const e = new Error(message);
  e.status = status;
  return e;
}

/** The address customers' players use. Needed for logo and tile URLs. */
function publicBase() {
  return (defaults.publicUrl || '').replace(/\/+$/, '');
}

function linkFor(username, password, output) {
  const token = encodeConfig({ xtream: { username, password, output } });
  return `${publicBase()}/${token}/manifest.json`;
}

/** Returns { url, account, verified, cfg }. Throws a readable message. */
export async function createLiveTvLink({ username, password } = {}) {
  username = String(username ?? '').trim();
  password = String(password ?? '').trim();
  if (!username || !password) throw fail('Enter your IPTV username and password.', 400);
  if (!liveTvApiConfigured()) throw fail('Live TV is not set up — set XTREAM_URL.', 500);
  if (!publicBase()) throw fail('PUBLIC_URL is not set, so the Live TV link would not work outside this server.', 500);

  const key = crypto.createHash('sha256').update(`${username}\0${password}`).digest('hex');
  const hit = memo.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.value;

  const output = defaults.xtream?.output || 'ts';
  let account;
  try {
    account = await checkLogin(
      { url: defaults.xtreamServer, username, password, output },
      defaults.userAgent
    );
  } catch (err) {
    const status = { auth: 400, expired: 403, unreachable: 502 }[err.code] || 500;
    throw fail(
      err.code === 'unreachable' ? 'Could not reach the IPTV service. Try again shortly.' : err.message,
      status
    );
  }

  const value = {
    url: linkFor(username, password, output),
    account,
    verified: true,
    // Kept so the collection can be built without re-deriving it.
    cfg: { username, password, output },
  };
  if (memo.size > 200) memo.clear();
  memo.set(key, { at: Date.now(), value });
  return value;
}

/**
 * Build the Live TV collection for this login. Returns { collection, error };
 * a missing collection never blocks the push, but the reason is reported.
 */
export async function fetchLiveTvCollection(manifestUrl, title, creds) {
  if (!creds) return { collection: null, error: 'no IPTV login to build a collection from' };
  try {
    const cfg = {
      ...defaults,
      xtream: { url: defaults.xtreamServer, ...creds },
    };
    const data = await getData(cfg);
    if (!data.folders?.length) return { collection: null, error: 'no categories found on this IPTV account' };
    const base = publicBase();
    const collection = buildCollection(cfg, data, { title, base });
    // Category tiles are images served by this server. If PUBLIC_URL does not
    // resolve from the viewer's device, every tile renders blank, so say so
    // now rather than leaving someone staring at empty boxes.
    if (!base) {
      return { collection, error: null, warning: 'PUBLIC_URL is not set — category tiles will have no artwork' };
    }
    return { collection, error: null };
  } catch (err) {
    return { collection: null, error: err.message };
  }
}
