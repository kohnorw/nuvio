# Nuvio Live TV stack

Two services:

- **nuvio-iptv-addon** — turns an Xtream Codes login into a Stremio/Nuvio addon
  and builds the **Live TV** collection (one row of category tiles; opening a
  category gives a grid of its channels).
- **nuvio-provisioner** — a page where you pick a Nuvio profile, enter the
  customer's IPTV login, and push the addon plus the collection to it.

## Setup

```bash
cp .env.example .env     # fill in XTREAM_URL, API_KEY, CONFIG_SECRET, AIOSTREAMS_*
docker compose up -d --build
```

`API_KEY` and `CONFIG_SECRET`: `openssl rand -hex 32` for each.

Then open `http://<host>:8080`.

1. Sign in with the Nuvio account.
2. Pick the profiles and stream quality.
3. Tick **Live TV**, enter the IPTV username and password, press **Check login**.
4. **Preview changes**, then push.

Fully close and reopen Nuvio afterwards: collections are cached per profile.

## Layout

The addon contributes **no rows of its own** (`COLLECTION_ONLY=true`). The Live
TV collection is the whole interface. Category tiles are wide banners tinted
from the category name; each opens a grid of square station logos showing what
is on now and next.

## Checking it

```bash
curl -s http://<host>:7000/debug.json          # version, rows, settings
docker compose logs --tail=30 iptv-addon
docker compose logs --tail=30 provisioner      # "[livetv] no collection: ..." if the push skipped it
```

The provisioner reaches the addon at `http://iptv-addon:7000` over the compose
network. Keep it that way — the public hostname may not route back from inside
Docker, which is the usual reason a collection fails to appear.

## Without the provisioner

For a single account, push directly:

```bash
docker compose exec iptv-addon node scripts/push-collection.mjs \
  --manifest 'https://redirect.kohnor.ca/<token>/manifest.json' \
  --email you@example.com --password 'nuvio-password' --dry-run
```

Drop `--dry-run` to write. Get `<token>` from:

```bash
curl -X POST http://<host>:7000/api/manifest \
  -H "Authorization: Bearer $API_KEY" -H "Content-Type: application/json" \
  -d '{"username":"IPTV_USER","password":"IPTV_PASS"}'
```

## Notes

- `config/addons.json` in `nuvio-provisioner/` holds your base addon list
  (Cinemeta, OpenSubtitles, Xperience). Copy `addons.example.json` and add your
  Xperience manifest URL; it is not shipped, since it contains your token.
- Pushing **replaces** a profile's addons and collections with the configured
  set. That is deliberate, but it does mean anything else on the profile goes.
- A failed IPTV login aborts the whole push — nothing is written.
