# Nuvio → VLC

The Nuvio repo says iOS must be built from source, which means macOS, Xcode, and re-signing every seven days on a free account. This is the way around that: a small Docker container that signs into your Nuvio account, reads the addons, library and watch progress already on it, and hands stream URLs to VLC on your iPhone. Nothing to sideload, nothing to re-sign.

## Styling

Built from the app's own values, read out of `NuvioMedia/NuvioMobile` rather than eyeballed:

- **Typography** — `core/ui/Theme.kt`, `Tokens.kt`. JetBrains Sans throughout. Row headers 18/24 SemiBold, poster titles 14/20 Regular, hero titles 32/36 Black, page displays 38/42 at -1.2px tracking.
- **Posters** — `PosterCardStyleRepository.kt`: 126dp wide, 0.675 aspect ratio, 12dp radius. Landscape cards are 126 x 180/110 = 206dp at 1.77.
- **Hero** — `HomeHeroSection.kt`: 82% of viewport height clamped to 360-760dp, 28dp rounded bottom corners, 220dp bottom fade, centred title over dot-separated meta, and a pill "View Details" button at 28/12 padding and 40dp radius.
- **Rows** — `ShelfComponents.kt`: 16dp section padding, 24dp between sections, 8dp between cards, and a 32dp circular chevron pill at the right of each header (the app doesn't print the addon name there).
- **Colour** — all twelve palettes from `ThemeColors.kt` verbatim, switchable in Settings.

Run `scripts/fetch-fonts.sh` once before building to pull JetBrains Sans from the Nuvio repo. The fonts aren't bundled: the copy in that repo carries an "All rights reserved" notice with no license grant, so redistributing it isn't mine to do. Skip the script and the app falls back to the system font; everything still works.

Same four-tab shell (Home, Search, Library, profile tab for Settings), same hero-over-rails home, same profile picker.

## Sign-in

Nuvio's backend is Supabase. Sign-in is GoTrue (`POST /auth/v1/token?grant_type=password`), addons come from a Postgres table, and library and progress come from RPCs like `sync_pull_library`. Every request carries an `apikey` header holding Nuvio's publishable key — that key is built into `src/nuvio.js`, exactly as it is in the official clients and in the provisioner, so there is nothing to configure. People sign in with their Nuvio email and password and that's it.

Set `ALLOW_SIGNUP=true` and the sign-in screen also offers account creation, which posts to `/auth/v1/signup`. If Nuvio has email confirmation on, the app says to check the inbox rather than pretending it worked.

Running your own Nuvio server? Set `NUVIO_SERVER` to its hostname and the container reads the backend URL and key from `/.well-known/nuvio` at startup, exactly as the app does.

## Multi-user

One container serves any number of people. Each signed-in account gets its own record holding its Nuvio tokens, profile selection and theme, addressed by an opaque cookie id — nobody sees anybody else's library, and signing in doesn't evict whoever signed in before.

Records live in the `/data` volume, encrypted with AES-256-GCM. Set `SESSION_SECRET` to control the key; leave it blank and one is generated into the volume on first boot. Access tokens refresh a minute before they expire, no token ever reaches the browser, and idle records are dropped after `SESSION_IDLE_DAYS`. Failed sign-ins are rate limited to ten per IP per fifteen minutes so the endpoint can't be used as a password oracle against Nuvio.

## Run it

```bash
cp .env.example .env      # set PUBLIC_URL
docker compose up -d --build
```

Open `http://<your-server>:8080` on a phone, sign in, pick a profile, and use Share → Add to Home Screen. It runs standalone without Safari's chrome.

| Variable | What it does |
| --- | --- |
| `PUBLIC_URL` | The address phones use to reach the container. VLC returns here after playback. |
| `SESSION_SECRET` | Encrypts stored tokens. Generated into the volume if unset. |
| `ALLOW_SIGNUP` | `true` to offer account creation on the sign-in screen. Default `false`. |
| `NUVIO_BACKEND_URL` | Backend origin. Defaults to `https://api.nuvio.tv`. |
| `NUVIO_ANON_KEY` | Only needed to override the built-in key for another backend. |
| `NUVIO_SERVER` | A self-hosted Nuvio server to auto-discover instead. |

## The iOS Shortcut

Shortcut tokens are per-user now: each person taps **Generate shortcut URL** in Settings and gets their own, which resolves to their account. Regenerating invalidates the previous one.

Two actions:

1. **Get Contents of URL** — the URL from Settings, with `q` set to what you want
2. **Open URLs** — pass it the result

The endpoint searches your addons, picks the best direct stream, and returns a `vlc-x-callback://` URL as plain text. Open URLs fires it and VLC starts playing.

Put a **Text** action with *Ask Each Time* in front to make it prompt for a title. To resume instead, point step 1 at `/api/shortcut/continue?index=0&token=…` — index 0 is the most recent thing you were watching. Drop `index` and that endpoint returns your in-progress list as JSON, ready for a **Choose from List** action. Add `&format=json` to `/api/shortcut/play` for `{ title, stream, source, vlc }` if you want the shortcut to name what it found in a notification.

## Auto-play and binge

The gear icon on any title's page opens a Playback sheet with three settings, stored per user:

**Auto-play best stream** - pressing Play skips the picker entirely and hands the top-ranked playable result straight to VLC. With it off, Play opens a sheet listing every stream your addons returned, with quality badges, so you choose.

**Binge next episode** - when VLC finishes and returns, the next episode starts on its own.

**Preferred quality** - Any, 4K, 1080p or 720p. Auto-play takes the best stream carrying that badge, falling back to the top-ranked one when nothing matches.

Binge works through VLC's `x-success` parameter. Each episode is handed over with `x-success` pointing at the *next* episode's auto-play URL, so when VLC bounces back to Safari it lands on a URL that immediately redirects into VLC again with the following episode. There is no queue on the server - every link only needs to know its successor, so the chain survives restarts and can be picked up from any episode. The next episode comes from the meta addon's own ordering rather than incrementing the episode number, so season boundaries and gaps are handled.

Worth knowing: VLC fires `x-success` when playback ends *or* when you back out manually - it cannot tell the difference. Backing out of episode 3 will start episode 4. Turn binge off, or close Safari when you are done.

## The banner

The top banner is a pager over eight titles, built the way HomeRepository does it: pooled from every catalog row, deduped on type and id, shuffled, capped at eight. Anything without artwork is left out, since a full-bleed banner with no backdrop just looks broken.

Each slide is captioned with the row it came from - "Popular - Movies", "Top Rated - Series" - using the app's own home_catalog_default_title format and its media-type labels, so movie, series, anime, tv and channel read the way they do in the app and anything else falls back to the capitalised type. When a catalog is already named for its type ("Popular Movies") the suffix is dropped rather than repeated. Slides drawn from a collection are captioned with the collection and folder instead.

Swipe it, or tap a dot. It advances on its own every 8 seconds - the same interval as HERO_AUTO_SCROLL_INTERVAL_MS - and paging by hand resets that clock rather than fighting it. It also pauses while a details page is open or the tab is in the background. Tapping the title or **View Details** opens that item.

Paging uses CSS scroll-snap rather than touch handlers, so the gesture gets native momentum and rubber-banding on iOS. The shuffle is seeded per day rather than per request, so the lineup stays put while you browse but changes tomorrow.

## Getting around

Each catalog row's chevron opens the full catalog as a paged grid - addons return roughly twenty at a time, and **Load more** walks forward until a short page comes back. Continue-watching has no catalog behind it, so its chevron is hidden rather than dead.

Play always routes through one place: the stream picker sheet, or straight to VLC when auto-play is on. Movies get a Play button under the description, series get one per episode, and a continue-watching card pointing at a specific episode gets Resume.

## A note on continue-watching

Watch progress and library are separate tables in Nuvio, and plenty of things get watched without ever being added to the library, so joining one against the other leaves gaps. Anything the join cannot resolve is looked up in the meta addons instead - the same source the app uses - which also picks up episode titles, so a card reads "Reacher / S1 E3 - Spoonful" rather than a bare id. Lookups run in parallel against the five-minute cache. If no addon can identify something, the card falls back to initials over a tinted tile and stays tappable rather than rendering blank.

## What VLC can and cannot tell us

VLC cannot be embedded in a Shortcut, and it reports no playback position back to anything. Its x-callback interface takes a URL to open and returns control - that is the whole contract. There is no way to learn that you stopped 34 minutes into an episode.

What this app does with the two signals that do exist:

- **Hand-off** writes a `sync_push_watch_progress` row, which is what makes a title appear in Continue Watching here, in the native app, and on every other device on the account.
- **Return** (VLC's x-success) marks the episode watched via `sync_push_watched_items`, clears its progress row, and starts the next one when binge is on.

That gives working continue-watching, cross-device sync and binge. It does not give resume-at-timestamp, and it never can through VLC. Two consequences: backing out of an episode early still marks it watched, because a return is a return either way; and VLC keeps its own private resume position per URL, so reopening the same stream often does resume - but that is VLC's memory rather than Nuvio's, and debrid links change.

If resume-at-timestamp matters more than codec support, the alternative is an in-browser player, which fires `timeupdate` and can report real positions. Safari plays H.264 in MP4 - fine for many debrid links, useless for the HEVC REMUX files in your stream list. That is the trade, and it is why the hand-off design is the one here.

## Addon support

The addon layer implements the protocol as the Nuvio clients do, which matters for the addons that stray from the simple case:

- **Extras are a path segment in a fixed order** - `search`, then `genre`, then `skip`, joined with `&` (buildCatalogUrl in features/catalog/CatalogData.kt). Sending them as a query string, or in another order, makes some addons silently return the wrong page.
- **Both manifest dialects parse.** Newer addons declare `extra: [{name, isRequired, options}]`; older ones use `extraSupported` / `extraRequired` plus a `genres` array. Both normalise to the same shape.
- **Resource-level types and idPrefixes are respected.** An addon is only asked for a resource it claims to handle for that id, so a Kitsu addon is never asked about `tt` ids and an IMDb addon is never asked about `kitsu:` ones. Beyond correctness this is a speed fix - every irrelevant addon queried is a timeout the page waits on.
- **Catalogs with a required genre** get one supplied automatically, and the catalog page shows genre chips when an addon advertises them.
- **Catalogs requiring some other extra** (an MDBList list id, say) are kept out of home rows, exactly as HomeCatalogDefinitions.kt does, but remain browsable.
- **Addons flagged `configurationRequired`** are dropped rather than queried, since they answer everything with an error.
- **Any type works**, not just movie and series - anime, tv, channels and anything else an addon declares.

**Collections** are pulled from `sync_pull_collections` and rendered above the catalog rows. Each folder merges all of its catalog sources into one deduped row, honouring per-source genres and the landscape tile shape. Non-addon sources inside a collection (Trakt lists, TMDB ids) are skipped - those need provider credentials this bridge doesn't hold.

**Row order** comes from `sync_pull_home_catalog_settings`, so disabled catalogs stay hidden and the ordering matches what you set in the app. With no settings stored, everything shows in install order.

## The one real limitation

VLC opens a URL; it cannot open a torrent. Addons that return a bare `infoHash` — Torrentio and friends in their default configuration — appear in the stream list dimmed and labelled, because there's nothing to hand over. Point those addons at a debrid service (Real-Debrid, TorBox, AllDebrid) so they return HTTPS links and everything works. The native iOS build lives under the same constraint; it just hides it behind a bundled player.

## Layout

```
src/nuvio.js     Supabase auth, profiles, addons table, library and progress RPCs
src/sessions.js  per-user session store, encrypted at rest
src/addons.js    Stremio addon protocol — manifests, catalogs, search, meta, streams
src/vlc.js       URL scheme builders
src/server.js    routes, session, token refresh, shortcut endpoints
public/          the phone UI
```

Nuvio's `addons` table stores only a URL per addon, not a cached manifest, so manifests are fetched on first use and cached for five minutes. Addon calls fan out in parallel and failures are dropped rather than propagated, so one dead addon costs you a 15-second timeout instead of a broken page.
