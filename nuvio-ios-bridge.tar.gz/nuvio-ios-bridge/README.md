# Nuvio → VLC

The Nuvio repo you linked says it plainly: **iOS must be built from source**, and that means macOS, Xcode, and a signing cycle every seven days on a free account. This is the way around that. A small Docker container signs into your Nuvio account, reads the addons and library that are already on it, and hands the stream URL to VLC on your iPhone. Nothing to sideload, nothing to re-sign.

It is a *client*, not a fork. Your account, your addons, your continue-watching row — the app on the server just resolves a stream and gets out of the way.

## What you get

- Sign in with your Nuvio email and password (or paste an authKey if you'd rather not put a password into a self-hosted box)
- Your installed addons' catalogs, search across them, and continue-watching with progress bars
- Streams listed per title, best quality first, each one a tap away from opening in VLC
- Two token-authenticated endpoints built for Shortcuts

## Run it

```bash
cp .env.example .env      # set PUBLIC_URL and SHORTCUT_TOKEN
docker compose up -d
```

Open `http://<your-server>:8080` on your iPhone in Safari, sign in, and add it to the Home Screen. It's built as a standalone web app, so it opens without Safari chrome.

Three environment variables matter:

| Variable | What it does |
| --- | --- |
| `NUVIO_API_BASE` | The Nuvio cloud API host. Defaults to `https://api.nuvio.tv`. |
| `PUBLIC_URL` | The address your phone uses to reach the container. VLC returns here when playback ends. |
| `SHORTCUT_TOKEN` | A long random string (`openssl rand -hex 24`). Leave it blank and the Shortcut routes stay off. |

The `NUVIO_API_BASE` default is the one to check first if login fails. Nuvio's account layer speaks the Stremio dialect (`POST /api/login`, `POST /api/addonCollectionGet`, `POST /api/datastoreGet`) and the hostname has moved between `nuvio.tv` and `nuvioapp.space` over time. If the default bounces, open Nuvio Web with the network tab up, watch where the login POST goes, and put that host in `.env`. Nothing else in the code changes.

Your authKey is stored in the `/data` volume at mode 0600 and never sent to the browser. The browser only ever holds an opaque session id.

## The iOS Shortcut

Two actions:

1. **Get Contents of URL** — `https://<PUBLIC_URL>/api/shortcut/play?q=Dune&token=<SHORTCUT_TOKEN>`
2. **Open URLs** — pass it the result

That's it. The endpoint searches your addons, picks the best direct stream, and returns a `vlc-x-callback://` URL as plain text. Open URLs fires it and VLC starts playing.

To make it ask what to watch, put a **Text** action with *Ask Each Time* in front and URL-encode it into the `q` parameter. To pick up where you left off instead, point step 1 at `/api/shortcut/continue?index=0&token=…` — index 0 is whatever you watched most recently. Drop `index` and the same endpoint returns your in-progress list as JSON, which is what you'd feed a **Choose from List** action if you want a picker.

Add `&format=json` to `/api/shortcut/play` and you get `{ title, stream, source, vlc }` — useful if you want the shortcut to show a notification naming what it found.

## The one real limitation

VLC opens a URL. It cannot open a torrent. Any addon that returns a bare `infoHash` — Torrentio and friends in their default configuration — shows up in the list greyed out and marked as such, because there is nothing this app can hand VLC. Point those addons at a debrid service (Real-Debrid, TorBox, AllDebrid) so they return HTTPS links instead, and everything works. That's the same constraint the native iOS build lives under; it just hides it behind a bundled player.

## Layout

```
src/nuvio.js     account API — login, addon collection, library
src/addons.js    Stremio addon protocol — catalogs, search, meta, streams
src/vlc.js       URL scheme builders
src/server.js    routes, session, shortcut endpoints
public/          the phone UI
```

Addon calls fan out in parallel and failures are dropped rather than propagated, so one dead addon slows a page down by at most the 15-second timeout instead of breaking it. Responses cache for five minutes.
