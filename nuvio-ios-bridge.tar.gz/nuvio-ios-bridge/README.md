# Nuvio → VLC

The Nuvio repo says iOS must be built from source, which means macOS, Xcode, and re-signing every seven days on a free account. This is the way around that: a small Docker container that signs into your Nuvio account, reads the addons, library and watch progress already on it, and hands stream URLs to VLC on your iPhone. Nothing to sideload, nothing to re-sign.

The UI is built from the app's own design tokens — `core/ui/Tokens.kt`, `core/ui/ThemeColors.kt` and `core/ui/TypeScale.kt` — so the spacing, radii, type scale and all twelve themes match rather than approximate. Same four-tab shell (Home, Search, Library, and a profile tab for Settings), same hero-over-rails home, same profile picker.

## Sign-in

Nuvio's backend is Supabase. Sign-in is GoTrue (`POST /auth/v1/token?grant_type=password`), addons come from a Postgres table, and library and progress come from RPCs like `sync_pull_library`. Every request carries an `apikey` header holding Nuvio's publishable key — that key is built into `src/nuvio.js`, exactly as it is in the official clients and in the provisioner, so there is nothing to configure. People sign in with their Nuvio email and password and that's it.

Set `ALLOW_SIGNUP=true` and the sign-in screen also offers account creation, which posts to `/auth/v1/signup`. If Nuvio has email confirmation on, the app says to check the inbox rather than pretending it worked.

Running your own Nuvio server? Set `NUVIO_SERVER` to its hostname and the container reads the backend URL and key from `/.well-known/nuvio` at startup, exactly as the app does.

## Multi-user

One container serves any number of people. Each signed-in account gets its own record holding its Nuvio tokens, profile selection and theme, addressed by an opaque cookie id — nobody sees anybody else's library, and signing in doesn't evict whoever signed in before.

Records live in the `/data` volume, encrypted with AES-256-GCM. Set `SESSION_SECRET` to control the key; leave it blank and one is generated into the volume on first boot. Access tokens refresh a minute before they expire, no token ever reaches the browser, and idle records are dropped after `SESSION_IDLE_DAYS`. Failed sign-ins are rate limited to ten per IP per fifteen minutes so the endpoint can't be used as a password oracle against Nuvio.

## Run it

```bash
cp .env.example .env      # set PUBLIC_URL
docker compose up -d --build
```

Open `http://<your-server>:8080` on a phone, sign in, pick a profile, and use Share → Add to Home Screen. It runs standalone without Safari's chrome.

| Variable | What it does |
| --- | --- |
| `PUBLIC_URL` | The address phones use to reach the container. VLC returns here after playback. |
| `SESSION_SECRET` | Encrypts stored tokens. Generated into the volume if unset. |
| `ALLOW_SIGNUP` | `true` to offer account creation on the sign-in screen. Default `false`. |
| `NUVIO_BACKEND_URL` | Backend origin. Defaults to `https://api.nuvio.tv`. |
| `NUVIO_ANON_KEY` | Only needed to override the built-in key for another backend. |
| `NUVIO_SERVER` | A self-hosted Nuvio server to auto-discover instead. |

## The iOS Shortcut

Shortcut tokens are per-user now: each person taps **Generate shortcut URL** in Settings and gets their own, which resolves to their account. Regenerating invalidates the previous one.

Two actions:

1. **Get Contents of URL** — the URL from Settings, with `q` set to what you want
2. **Open URLs** — pass it the result

The endpoint searches your addons, picks the best direct stream, and returns a `vlc-x-callback://` URL as plain text. Open URLs fires it and VLC starts playing.

Put a **Text** action with *Ask Each Time* in front to make it prompt for a title. To resume instead, point step 1 at `/api/shortcut/continue?index=0&token=…` — index 0 is the most recent thing you were watching. Drop `index` and that endpoint returns your in-progress list as JSON, ready for a **Choose from List** action. Add `&format=json` to `/api/shortcut/play` for `{ title, stream, source, vlc }` if you want the shortcut to name what it found in a notification.

## The one real limitation

VLC opens a URL; it cannot open a torrent. Addons that return a bare `infoHash` — Torrentio and friends in their default configuration — appear in the stream list dimmed and labelled, because there's nothing to hand over. Point those addons at a debrid service (Real-Debrid, TorBox, AllDebrid) so they return HTTPS links and everything works. The native iOS build lives under the same constraint; it just hides it behind a bundled player.

## Layout

```
src/nuvio.js     Supabase auth, profiles, addons table, library and progress RPCs
src/sessions.js  per-user session store, encrypted at rest
src/addons.js    Stremio addon protocol — manifests, catalogs, search, meta, streams
src/vlc.js       URL scheme builders
src/server.js    routes, session, token refresh, shortcut endpoints
public/          the phone UI
```

Nuvio's `addons` table stores only a URL per addon, not a cached manifest, so manifests are fetched on first use and cached for five minutes. Addon calls fan out in parallel and failures are dropped rather than propagated, so one dead addon costs you a 15-second timeout instead of a broken page.
