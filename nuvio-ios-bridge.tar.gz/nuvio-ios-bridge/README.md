# Nuvio → VLC

The Nuvio repo says iOS must be built from source, which means macOS, Xcode, and re-signing every seven days on a free account. This is the way around that: a small Docker container that signs into your Nuvio account, reads the addons, library and watch progress already on it, and hands stream URLs to VLC on your iPhone. Nothing to sideload, nothing to re-sign.

The UI is built from the app's own design tokens — `core/ui/Tokens.kt`, `core/ui/ThemeColors.kt` and `core/ui/TypeScale.kt` — so the spacing, radii, type scale and all twelve themes match rather than approximate. Same four-tab shell (Home, Search, Library, and a profile tab for Settings), same hero-over-rails home, same profile picker.

## You need Nuvio's publishable key

This is the one piece of setup that isn't obvious, and it's why sign-in fails without it.

Nuvio's backend is **Supabase**, not the Stremio-style account API you might expect. Sign-in is Supabase GoTrue (`POST /auth/v1/token?grant_type=password`), addons come from a Postgres table, and library and progress come from RPCs like `sync_pull_library`. Every one of those requests must carry an `apikey` header holding Nuvio's publishable key. Without it Supabase rejects the request before it ever looks at your email and password — so a perfectly correct password still fails.

That key is a build-time secret in the repo (`NUVIO_SUPABASE_ANON_KEY`, injected from GitHub Actions secrets), so it isn't in the source. It is a *publishable* key, designed to ship inside every client, so pulling it out of a copy you already have is fine. Two ways:

**From the official Android APK.** Download it from the Nuvio releases page, then:

```bash
unzip -o Nuvio.apk -d nuvio-apk
grep -rhoE 'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+' nuvio-apk | sort -u
```

Supabase anon keys are JWTs starting `eyJ`. Decode the payload of each hit (`base64 -d`) and take the one whose `role` is `anon`.

**From Nuvio Web.** Open the web app in a desktop browser with the network tab recording, sign in, and look at any request to the backend. The `apikey` request header is the value you want. The same tab also confirms the backend host, which is what `NUVIO_BACKEND_URL` should be set to.

**Running your own Nuvio server?** Skip all of that. Set `NUVIO_SERVER` to your server's hostname and the container reads the backend URL and key from its `/.well-known/nuvio` document at startup, exactly as the app does.

## Run it

```bash
cp .env.example .env      # set NUVIO_ANON_KEY, PUBLIC_URL, SHORTCUT_TOKEN
docker compose up -d --build
```

Open `http://<your-server>:8080` on your iPhone, sign in, pick a profile, and use Share → Add to Home Screen. It runs standalone without Safari's chrome.

| Variable | What it does |
| --- | --- |
| `NUVIO_ANON_KEY` | **Required.** Nuvio's publishable key, as above. |
| `NUVIO_BACKEND_URL` | Backend origin. Defaults to `https://api.nuvio.tv`. |
| `NUVIO_SERVER` | Optional. A self-hosted Nuvio server to auto-discover instead. |
| `PUBLIC_URL` | The address your phone uses to reach the container. VLC returns here after playback. |
| `SHORTCUT_TOKEN` | A long random string (`openssl rand -hex 24`). Blank switches the Shortcut routes off. |

Access and refresh tokens are stored in the `/data` volume at mode 0600 and never sent to the browser; the browser holds only an opaque session id. Access tokens are refreshed a minute before they expire.

## The iOS Shortcut

Two actions:

1. **Get Contents of URL** — `https://<PUBLIC_URL>/api/shortcut/play?q=Dune&token=<SHORTCUT_TOKEN>`
2. **Open URLs** — pass it the result

The endpoint searches your addons, picks the best direct stream, and returns a `vlc-x-callback://` URL as plain text. Open URLs fires it and VLC starts playing.

Put a **Text** action with *Ask Each Time* in front to make it prompt for a title. To resume instead, point step 1 at `/api/shortcut/continue?index=0&token=…` — index 0 is the most recent thing you were watching. Drop `index` and that endpoint returns your in-progress list as JSON, ready for a **Choose from List** action. Add `&format=json` to `/api/shortcut/play` for `{ title, stream, source, vlc }` if you want the shortcut to name what it found in a notification.

## The one real limitation

VLC opens a URL; it cannot open a torrent. Addons that return a bare `infoHash` — Torrentio and friends in their default configuration — appear in the stream list dimmed and labelled, because there's nothing to hand over. Point those addons at a debrid service (Real-Debrid, TorBox, AllDebrid) so they return HTTPS links and everything works. The native iOS build lives under the same constraint; it just hides it behind a bundled player.

## Layout

```
src/nuvio.js     Supabase auth, profiles, addons table, library and progress RPCs
src/addons.js    Stremio addon protocol — manifests, catalogs, search, meta, streams
src/vlc.js       URL scheme builders
src/server.js    routes, session, token refresh, shortcut endpoints
public/          the phone UI
```

Nuvio's `addons` table stores only a URL per addon, not a cached manifest, so manifests are fetched on first use and cached for five minutes. Addon calls fan out in parallel and failures are dropped rather than propagated, so one dead addon costs you a 15-second timeout instead of a broken page.
