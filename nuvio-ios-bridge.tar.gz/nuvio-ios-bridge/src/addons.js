// Talks the Stremio addon protocol, which Nuvio addons implement unchanged.
//
//   <base>/manifest.json
//   <base>/catalog/<type>/<id>.json
//   <base>/catalog/<type>/<id>/<key>=<value>.json      (search, skip, genre)
//   <base>/meta/<type>/<id>.json
//   <base>/stream/<type>/<id>.json

const TIMEOUT_MS = Number(process.env.HTTP_TIMEOUT_MS || 15000);
const cache = new Map();
const CACHE_TTL_MS = Number(process.env.CACHE_TTL_MS || 5 * 60 * 1000);

function baseOf(transportUrl) {
  return transportUrl.replace(/\/manifest\.json.*$/, '').replace(/\/+$/, '');
}

async function getJson(url) {
  const hit = cache.get(url);
  if (hit && hit.expires > Date.now()) return hit.value;

  const res = await fetch(url, {
    headers: { accept: 'application/json' },
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  if (!res.ok) throw new Error(`${res.status} from ${url}`);
  const value = await res.json();

  cache.set(url, { value, expires: Date.now() + CACHE_TTL_MS });
  return value;
}

// Runs a request across every addon that declares support, keeps whatever
// came back, and quietly drops the ones that timed out or 404'd. One broken
// addon should never take down the whole page.
async function fanOut(addons, predicate, build) {
  const eligible = addons.filter(predicate);
  const settled = await Promise.allSettled(
    eligible.map(async (addon) => ({ addon, data: await getJson(build(addon)) })),
  );
  return settled
    .filter((r) => r.status === 'fulfilled')
    .map((r) => r.value);
}

function supportsResource(addon, resource, type) {
  const resources = addon.manifest?.resources || [];
  const types = addon.manifest?.types || [];
  const matchesResource = resources.some((r) =>
    typeof r === 'string' ? r === resource : r.name === resource,
  );
  return matchesResource && (!type || types.includes(type));
}

// Nuvio's `addons` table stores only a URL, a name and a sort order — unlike
// Stremio's account API it does not cache the manifest. So fetch each one.
// Manifests are small and cached, and an addon whose manifest won't load is
// dropped rather than allowed to break the list.
export async function hydrate(rows) {
  const settled = await Promise.allSettled(
    rows.map(async (row) => ({
      transportUrl: row.transportUrl,
      manifest: await getJson(row.transportUrl),
    })),
  );
  return settled
    .filter((r) => r.status === 'fulfilled' && r.value.manifest?.id)
    .map((r) => r.value);
}

export function catalogList(addons) {
  const out = [];
  for (const addon of addons) {
    for (const catalog of addon.manifest?.catalogs || []) {
      out.push({
        addonId: addon.manifest.id,
        addonName: addon.manifest.name,
        transportUrl: addon.transportUrl,
        type: catalog.type,
        id: catalog.id,
        name: catalog.name || catalog.id,
      });
    }
  }
  return out;
}

export async function catalog(addons, { transportUrl, type, id, skip = 0 }) {
  const addon = addons.find((a) => a.transportUrl === transportUrl);
  if (!addon) throw new Error('That addon is not installed on this account.');
  const suffix = skip ? `/skip=${skip}.json` : '.json';
  const url = `${baseOf(transportUrl)}/catalog/${encodeURIComponent(type)}/${encodeURIComponent(id)}${suffix}`;
  const data = await getJson(url);
  return (data.metas || []).map(normalizeMeta);
}

export async function search(addons, query) {
  const results = await fanOut(
    addons,
    (addon) =>
      supportsResource(addon, 'catalog') &&
      (addon.manifest?.catalogs || []).some((c) =>
        (c.extra || []).some((e) => e.name === 'search') ||
        (c.extraSupported || []).includes('search'),
      ),
    (addon) => {
      const catalogDef = addon.manifest.catalogs.find((c) =>
        (c.extra || []).some((e) => e.name === 'search') ||
        (c.extraSupported || []).includes('search'),
      );
      return `${baseOf(addon.transportUrl)}/catalog/${catalogDef.type}/${catalogDef.id}/search=${encodeURIComponent(query)}.json`;
    },
  );

  const seen = new Set();
  const merged = [];
  for (const { data } of results) {
    for (const meta of data.metas || []) {
      if (seen.has(meta.id)) continue;
      seen.add(meta.id);
      merged.push(normalizeMeta(meta));
    }
  }
  return merged;
}

export async function meta(addons, type, id) {
  const results = await fanOut(
    addons,
    (addon) => supportsResource(addon, 'meta', type),
    (addon) => `${baseOf(addon.transportUrl)}/meta/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`,
  );
  const found = results.find((r) => r.data?.meta);
  if (!found) throw new Error('No installed addon has details for this title.');

  const m = found.data.meta;
  return {
    ...normalizeMeta(m),
    description: m.description,
    background: m.background,
    videos: (m.videos || []).map((v) => ({
      id: v.id,
      title: v.title || v.name,
      season: v.season,
      episode: v.episode,
      released: v.released,
    })),
  };
}

export async function streams(addons, type, id) {
  const results = await fanOut(
    addons,
    (addon) => supportsResource(addon, 'stream', type),
    (addon) => `${baseOf(addon.transportUrl)}/stream/${encodeURIComponent(type)}/${encodeURIComponent(id)}.json`,
  );

  const out = [];
  for (const { addon, data } of results) {
    for (const s of data.streams || []) {
      out.push(normalizeStream(s, addon.manifest?.name || 'Addon'));
    }
  }
  return out.sort((a, b) => b.score - a.score);
}

function normalizeMeta(m) {
  return {
    id: m.id,
    type: m.type,
    name: m.name,
    poster: m.poster,
    year: m.year || m.releaseInfo,
    imdbRating: m.imdbRating,
  };
}

// VLC on iOS opens a URL. It cannot open a torrent. So a stream that only
// carries an infoHash is listed but marked unplayable, and ranked last —
// route those through a debrid addon if you want them here.
function normalizeStream(s, addonName) {
  const label = [s.name, s.title, s.description].filter(Boolean).join(' • ');
  const url = s.url || null;
  const playable = Boolean(url) && /^https?:/i.test(url);

  return {
    addon: addonName,
    label: label || 'Untitled stream',
    url,
    infoHash: s.infoHash || null,
    playable,
    filename: s.behaviorHints?.filename || null,
    score: scoreStream(label, playable),
  };
}

function scoreStream(label, playable) {
  if (!playable) return -1000;
  const text = label.toLowerCase();
  let score = 0;
  if (/2160|4k|uhd/.test(text)) score += 40;
  else if (/1080/.test(text)) score += 30;
  else if (/720/.test(text)) score += 15;
  if (/remux/.test(text)) score += 12;
  if (/bluray|blu-ray/.test(text)) score += 8;
  if (/hdr|dolby.?vision|dv\b/.test(text)) score += 6;
  if (/cam|telesync|\bts\b|hdts/.test(text)) score -= 60;
  return score;
}

export function clearCache() {
  cache.clear();
}
