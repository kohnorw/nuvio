import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import * as nuvio from './nuvio.js';
import * as addonsApi from './addons.js';
import * as vlc from './vlc.js';
import * as store from './sessions.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const PUBLIC_URL = (process.env.PUBLIC_URL || '').replace(/\/+$/, '');
const ALLOW_SIGNUP = process.env.ALLOW_SIGNUP === 'true';

const app = express();
app.use(express.json());
app.use(cookieParser());
app.set('trust proxy', true);

// ---------------------------------------------------------------- auth

// Every request resolves to a user record or none. Nothing is global any
// more: two people on the same container each get their own Nuvio session,
// profile selection and theme.
function currentUser(req) {
  return store.get(req.cookies?.nib_sid);
}

function requireUser(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to your Nuvio account.' });
  req.user = user;
  next();
}

// Shortcuts can't hold a cookie, so each user generates a personal token from
// Settings and it identifies them the same way the cookie does.
function requireShortcutToken(req, res, next) {
  const user = store.getByToken(req.query.token || req.get('x-shortcut-token'));
  if (!user) return res.status(401).json({ error: 'Unknown or missing shortcut token.' });
  req.user = user;
  next();
}

// Supabase access tokens last an hour; refresh a minute early so a request
// doesn't fail and need retrying.
async function accessToken(user) {
  if (Date.now() < user.session.expiresAt - 60_000) return user.session.accessToken;
  const refreshed = await nuvio.refresh(user.session.refreshToken);
  await store.update(user, { session: refreshed });
  return refreshed.accessToken;
}

// Failed sign-ins are rate limited per IP. This endpoint proxies to someone
// else's auth server, so it shouldn't be usable as a password oracle.
const attempts = new Map();
function throttle(req, res, next) {
  const ip = req.ip || 'unknown';
  const record = attempts.get(ip) || { count: 0, resetAt: Date.now() + 900_000 };
  if (Date.now() > record.resetAt) { record.count = 0; record.resetAt = Date.now() + 900_000; }
  if (record.count >= 10) {
    return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });
  }
  attempts.set(ip, record);
  req.failedAttempt = () => { record.count += 1; };
  next();
}

app.post('/api/login', throttle, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });

  try {
    const session = await nuvio.signIn(email, password);
    const user = await store.create(session);
    setSessionCookie(res, req, user.sid);
    res.json({ email: session.user.email });
  } catch (err) {
    req.failedAttempt();
    res.status(401).json({ error: err.message });
  }
});

app.post('/api/signup', throttle, async (req, res) => {
  if (!ALLOW_SIGNUP) return res.status(403).json({ error: 'Sign-up is off on this server.' });
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter an email and password.' });

  try {
    const result = await nuvio.signUp(email, password);
    // Nuvio may require email confirmation, in which case there's no session
    // to hand back yet and the person needs to check their inbox.
    if (!result.session) return res.json({ confirmationRequired: true, email });
    const user = await store.create(result.session);
    setSessionCookie(res, req, user.sid);
    res.json({ email: result.session.user.email });
  } catch (err) {
    req.failedAttempt();
    res.status(400).json({ error: err.message });
  }
});

function setSessionCookie(res, req, sid) {
  res.cookie('nib_sid', sid, {
    httpOnly: true,
    sameSite: 'lax',
    secure: req.secure,
    maxAge: 1000 * 60 * 60 * 24 * 365,
  });
}

app.post('/api/logout', async (req, res) => {
  const user = currentUser(req);
  if (user) {
    await nuvio.signOut(user.session.accessToken);
    await store.destroy(user.sid);
  }
  res.clearCookie('nib_sid');
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  const user = currentUser(req);
  res.json({
    signedIn: Boolean(user),
    email: user?.email || null,
    backendUrl: nuvio.config.backendUrl,
    profileIndex: user?.profileIndex ?? null,
    theme: user?.theme || 'White',
    shortcutToken: user?.shortcutToken || null,
    prefs: { ...DEFAULT_PREFS, ...(user?.prefs || {}) },
    signupAllowed: ALLOW_SIGNUP,
  });
});

// ------------------------------------------------------------- profiles

app.get('/api/profiles', requireUser, async (req, res, next) => {
  try {
    res.json(await nuvio.profiles(await accessToken(req.user)));
  } catch (err) { next(err); }
});

app.post('/api/profile', requireUser, async (req, res, next) => {
  try {
    await store.update(req.user, { profileIndex: Number(req.body?.index) });
    addonsApi.clearCache();
    res.json({ profileIndex: req.user.profileIndex });
  } catch (err) { next(err); }
});

app.post('/api/theme', requireUser, async (req, res, next) => {
  try {
    await store.update(req.user, { theme: String(req.body?.theme || 'White') });
    res.json({ theme: req.user.theme });
  } catch (err) { next(err); }
});

app.post('/api/shortcut-token', requireUser, async (req, res, next) => {
  try {
    res.json({ token: await store.rotateShortcutToken(req.user) });
  } catch (err) { next(err); }
});

// ------------------------------------------------------------- browsing

// Profile numbering is decided by the server, not by us — the provisioner
// treats profile_index as 0-based while the app's default is 1, so never
// assume. If nothing is selected yet, use whichever profile comes back first.
async function profileIndex(user) {
  if (user.profileIndex != null) return user.profileIndex;
  const list = await nuvio.profiles(await accessToken(user));
  const first = list[0]?.index ?? 1;
  await store.update(user, { profileIndex: first });
  return first;
}

async function installedAddons(user) {
  return addonsApi.hydrate(await nuvio.addons(await accessToken(user), await profileIndex(user)));
}

app.get('/api/catalogs', requireUser, async (req, res, next) => {
  try {
    res.json(addonsApi.catalogList(await installedAddons(req.user), { includeRequiredExtras: true }));
  } catch (err) { next(err); }
});

app.get('/api/collections', requireUser, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    res.json(await nuvio.collections(token, await profileIndex(req.user)));
  } catch (err) { next(err); }
});

app.get('/api/catalog', requireUser, async (req, res, next) => {
  try {
    const { transportUrl, type, id, skip, genre } = req.query;
    res.json(await addonsApi.catalog(await installedAddons(req.user), {
      transportUrl, type, id, genre: genre || null, skip: Number(skip || 0),
    }));
  } catch (err) { next(err); }
});

// Anything the library join couldn't resolve gets looked up in the meta
// addons — the same place the app gets it. Lookups run in parallel, hit the
// five-minute cache, and a failure just leaves that card sparse rather than
// taking the whole row down.
async function fillMetadata(addons, items) {
  const missing = items.filter((item) => !item.name || !item.poster || !item.background);

  await Promise.all(missing.map(async (item) => {
    try {
      const meta = await addonsApi.meta(addons, item.type, item.parentId);
      item.name = item.name || meta.name;
      item.poster = item.poster || meta.poster || null;
      item.background = item.background || meta.background || meta.poster || null;
      item.year = item.year || meta.year || null;
      item.imdbRating = item.imdbRating || meta.imdbRating || null;

      // Episode titles make a continue row far more readable than "S1 E3".
      if (item.type === 'series') {
        const video = (meta.videos || []).find((v) => v.id === item.id);
        if (video) item.episodeTitle = video.title || null;
      }
    } catch {
      // No addon could identify it. Fall back to the id so the card is at
      // least tappable rather than blank.
      item.name = item.name || item.parentId;
    }
  }));

  return items;
}

// Home mirrors the app: continue-watching, then pinned collections, then
// catalog rows in whatever order the account's home settings specify.
app.get('/api/home', requireUser, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    const index = await profileIndex(req.user);

    const [addons, progress, lib, settings, userCollections] = await Promise.all([
      installedAddons(req.user),
      nuvio.watchProgress(token, index),
      nuvio.library(token, index),
      nuvio.homeCatalogSettings(token, index).catch(() => null),
      nuvio.collections(token, index).catch(() => []),
    ]);

    const rows = orderCatalogs(addonsApi.catalogList(addons), settings).slice(0, ROW_LIMIT);

    const [continueRow, catalogRows, collectionRows] = await Promise.all([
      fillMetadata(addons, nuvio.continueWatching(progress, lib).slice(0, 20)),
      Promise.all(rows.map(async (row) => ({
        ...row,
        items: await addonsApi.catalog(addons, row).catch(() => []),
      }))),
      loadCollections(addons, userCollections),
    ]);

    res.json({
      continueWatching: continueRow,
      hero: buildHeroPool([
        ...catalogRows,
        ...collectionRows.map((row) => ({ ...row, name: row.name, isCollection: true })),
      ]),
      collections: collectionRows,
      rows: catalogRows.filter((row) => row.items.length),
    });
  } catch (err) { next(err); }
});

const HERO_ITEM_LIMIT = 8;

// localizedMediaTypeLabel, ported from core/i18n. Anything not listed falls
// back to the raw type with an initial capital, as the app does.
const TYPE_LABELS = {
  movie: 'Movies',
  series: 'Series',
  anime: 'Anime',
  channel: 'Channels',
  tv: 'TV',
};

function typeLabel(type) {
  if (!type) return null;
  return TYPE_LABELS[type.trim().toLowerCase()]
    || type.charAt(0).toUpperCase() + type.slice(1);
}

// home_catalog_default_title is "%1$s - %2$s" — catalog name, then media type.
// "Popular - Movies", "Top Rated - Series".
function catalogLabel(row) {
  // A collection folder is named by the person, so say where it lives rather
  // than guessing a media type it may not have.
  if (row.isCollection) return row.collection ? `${row.collection} - ${row.name}` : row.name;

  const label = typeLabel(row.type);
  if (!label) return row.name;
  // Don't produce "Popular Movies - Movies" when the name already says it.
  if (row.name.toLowerCase().includes(label.toLowerCase())) return row.name;
  return `${row.name} - ${label}`;
}

// HomeRepository pools items across every catalog row, dedupes on type:id,
// shuffles, and takes eight. The shuffle is seeded per request there; here a
// day-stable seed keeps the banner from reshuffling on every pull-to-refresh
// while still changing over time. Each item keeps the row it came from so the
// banner can say what it is showing.
function buildHeroPool(rows) {
  const seen = new Set();
  const pool = [];

  for (const row of rows) {
    for (const item of row.items) {
      const key = `${item.type}:${item.id}`;
      // A banner needs artwork; a card with no backdrop looks broken at
      // full-bleed size.
      if (seen.has(key) || !(item.background || item.poster)) continue;
      seen.add(key);
      pool.push({
        ...item,
        source: catalogLabel(row),
        sourceAddon: row.addonName || null,
      });
    }
  }

  return shuffle(pool, dailySeed()).slice(0, HERO_ITEM_LIMIT);
}

function dailySeed() {
  return Math.floor(Date.now() / 86_400_000);
}

// Deterministic Fisher-Yates so the same seed gives the same order.
function shuffle(items, seed) {
  const out = [...items];
  let state = seed || 1;
  const next = () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(next() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

const ROW_LIMIT = Number(process.env.HOME_ROW_LIMIT || 10);

// Applies the account's home catalog settings: drop what's disabled, order by
// what's left. No settings means show everything in install order, which is
// the app's own fallback.
function orderCatalogs(catalogs, settings) {
  if (!settings?.length) return catalogs;

  const key = (addonId, type, catalogId) => `${addonId}|${type}|${catalogId}`;
  const rules = new Map(settings.map((s) => [key(s.addonId, s.type, s.catalogId), s]));

  return catalogs
    .map((c) => ({ catalog: c, rule: rules.get(key(c.addonId, c.type, c.id)) }))
    .filter(({ rule }) => !rule || rule.enabled)
    .sort((a, b) => (a.rule?.order ?? 999) - (b.rule?.order ?? 999))
    .map(({ catalog }) => catalog);
}

// A collection folder can draw from several catalogs at once; merge them into
// one row and dedupe, since overlapping sources are common.
async function loadCollections(addons, userCollections) {
  const pinned = userCollections.filter((c) => c.pinToTop);
  const chosen = (pinned.length ? pinned : userCollections).slice(0, 4);

  const rows = await Promise.all(chosen.flatMap((collection) =>
    collection.folders.slice(0, 3).map(async (folder) => {
      const results = await Promise.all(folder.sources.map(async (source) => {
        const addon = addons.find((a) => a.manifest.id === source.addonId);
        if (!addon) return [];
        return addonsApi.catalog(addons, {
          transportUrl: addon.transportUrl,
          type: source.type,
          id: source.catalogId,
          genre: source.genre,
        }).catch(() => []);
      }));

      const seen = new Set();
      const items = [];
      for (const item of results.flat()) {
        const id = `${item.type}:${item.id}`;
        if (seen.has(id)) continue;
        seen.add(id);
        items.push(item);
      }

      return {
        name: folder.title,
        collection: collection.title,
        tileShape: folder.tileShape,
        items,
      };
    })));

  return rows.filter((row) => row.items.length);
}

app.get('/api/library', requireUser, async (req, res, next) => {
  try {
    res.json(await nuvio.library(await accessToken(req.user), await profileIndex(req.user)));
  } catch (err) { next(err); }
});

app.get('/api/search', requireUser, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json([]);
    res.json(await addonsApi.search(await installedAddons(req.user), q, { type: req.query.type }));
  } catch (err) { next(err); }
});

app.get('/api/meta/:type/:id', requireUser, async (req, res, next) => {
  try {
    res.json(await addonsApi.meta(await installedAddons(req.user), req.params.type, req.params.id));
  } catch (err) { next(err); }
});

app.get('/api/streams/:type/:id', requireUser, async (req, res, next) => {
  try {
    const { type, id } = req.params;
    const [list, upcoming] = await Promise.all([
      addonsApi.streams(await installedAddons(req.user), type, id),
      nextEpisodeId(req.user, type, id),
    ]);
    res.json({
      next: upcoming,
      streams: list.map((s) => ({ ...s, vlc: s.playable ? vlc.build(s.url, { filename: s.filename }) : null })),
    });
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- handoff

app.get('/play', async (req, res) => {
  const target = req.query.url;
  if (!target || !/^https?:\/\//i.test(target)) {
    return res.status(400).send('Give me an http(s) stream URL to hand over.');
  }

  // A hand-picked stream gets the same treatment as an auto-played one:
  // recorded as started, and chained to the next episode if binge is on.
  const user = currentUser(req) || store.getByToken(req.query.token);
  const { type, id } = req.query;
  if (user && type && id) await recordStarted(user, type, id);

  let successUrl = originOf(req);
  if (type && id) {
    successUrl = `${originOf(req)}/finished/${encodeURIComponent(type)}/${encodeURIComponent(id)}`;
  }
  if (req.query.next) {
    successUrl = `${originOf(req)}/play/auto/series/${encodeURIComponent(req.query.next)}`
      + (id ? `?done=${encodeURIComponent(id)}` : '');
  }

  res.redirect(302, vlc.xCallback(target, { filename: req.query.filename, successUrl }));
});

app.post('/api/prefs', requireUser, async (req, res, next) => {
  try {
    const prefs = {
      autoplay: Boolean(req.body?.autoplay),
      binge: Boolean(req.body?.binge),
      quality: ['any', '2160p', '1080p', '720p'].includes(req.body?.quality) ? req.body.quality : 'any',
    };
    await store.update(req.user, { prefs });
    res.json(prefs);
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- autoplay

const DEFAULT_PREFS = { autoplay: false, binge: false, quality: 'any' };

// Picks what the person would almost certainly have tapped: playable, matching
// their quality preference if one is set, best-ranked otherwise.
function pickStream(list, quality = 'any') {
  const playable = list.filter((s) => s.playable);
  if (!playable.length) return null;
  if (quality !== 'any') {
    const match = playable.find((s) => (s.badges || []).includes(quality));
    if (match) return match;
  }
  return playable[0];
}

// Series episode ids are `<series>:<season>:<episode>`. The next episode is
// whatever follows in the addon's own ordering, so ask the meta addon rather
// than assuming episode+1 exists.
async function nextEpisodeId(user, type, id) {
  if (type !== 'series') return null;
  const baseId = id.split(':')[0];
  try {
    const meta = await addonsApi.meta(await installedAddons(user), 'series', baseId);
    const videos = meta.videos || [];
    const at = videos.findIndex((v) => v.id === id);
    return at >= 0 && at + 1 < videos.length ? videos[at + 1].id : null;
  } catch {
    return null;
  }
}

function originOf(req) {
  return PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
}

// Either cookie or shortcut token — a binge chain started from a Shortcut has
// no cookie, and one started in Safari has no token.
function requireUserOrToken(req, res, nextFn) {
  const user = currentUser(req) || store.getByToken(req.query.token);
  if (!user) return res.status(401).send('Sign in first.');
  req.user = user;
  nextFn();
}

// The whole binge mechanism: hand VLC this episode, and set x-success to the
// *next* episode's copy of this same route. When VLC finishes and bounces
// back, Safari hits that URL, which redirects straight into VLC again. No
// queue state on the server — each link only needs to know its successor.
// Splits `tt123:2:5` into the parts the progress tables want.
function idParts(type, id) {
  const [contentId, season, episode] = id.split(':');
  return {
    contentId,
    contentType: type,
    videoId: id,
    season: season != null ? Number(season) : null,
    episode: episode != null ? Number(episode) : null,
  };
}

// VLC never reports a playback position back, so the honest thing to record
// on hand-off is "started". That is enough to put the title in Continue
// Watching on every device; it is not enough to resume mid-episode.
async function recordStarted(user, type, id, title) {
  try {
    const parts = idParts(type, id);
    await nuvio.pushProgress(await accessToken(user), await profileIndex(user), {
      ...parts,
      position: 1,
      duration: 0,
      lastWatched: Date.now(),
    });
  } catch (err) {
    console.warn(`Could not record start for ${id}: ${err.message}`);
  }
}

// Called when VLC hands control back. Treating a return as "finished" is an
// assumption — see the README — but it is the only signal available.
async function recordFinished(user, type, id) {
  try {
    const parts = idParts(type, id);
    const token = await accessToken(user);
    const index = await profileIndex(user);
    await nuvio.markWatched(token, index, parts);
    await nuvio.clearProgress(token, index, [nuvio.progressKey(parts.contentId, parts.season, parts.episode)]);
  } catch (err) {
    console.warn(`Could not record finish for ${id}: ${err.message}`);
  }
}

app.get('/play/auto/:type/:id', requireUserOrToken, async (req, res, next) => {
  try {
    const { type, id } = req.params;
    const prefs = { ...DEFAULT_PREFS, ...(req.user.prefs || {}) };

    // `done` names the episode that just finished, carried here by the
    // x-success round trip from VLC.
    if (req.query.done) await recordFinished(req.user, type, req.query.done);

    const list = await addonsApi.streams(await installedAddons(req.user), type, id);
    const best = pickStream(list, prefs.quality);
    if (!best) {
      return res.status(404).send(noStreamPage(originOf(req), 'No playable stream for this episode.'));
    }

    await recordStarted(req.user, type, id);

    const token = req.query.token ? `&token=${encodeURIComponent(req.query.token)}` : '';
    let successUrl = `${originOf(req)}/finished/${encodeURIComponent(type)}/${encodeURIComponent(id)}?x=1${token}`;

    if (prefs.binge && type === 'series') {
      const upcoming = await nextEpisodeId(req.user, type, id);
      if (upcoming) {
        successUrl = `${originOf(req)}/play/auto/series/${encodeURIComponent(upcoming)}`
          + `?done=${encodeURIComponent(id)}${token}`;
      }
    }

    res.redirect(302, vlc.xCallback(best.url, { filename: best.filename, successUrl }));
  } catch (err) { next(err); }
});

// Where VLC lands when there is no next episode: mark this one done, then
// send the person back into the app.
app.get('/finished/:type/:id', requireUserOrToken, async (req, res) => {
  await recordFinished(req.user, req.params.type, req.params.id);
  res.redirect(302, originOf(req));
});

// VLC bounces back into Safari, so a dead end needs to be a readable page
// rather than a JSON blob.
function noStreamPage(origin, message) {
  return `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{background:#0D0D0D;color:#fff;font:15px/22px -apple-system,system-ui;padding:48px 24px;text-align:center}
a{display:inline-block;margin-top:20px;padding:13px 28px;border-radius:40px;background:#fff;color:#0D0D0D;font-weight:700;text-decoration:none}</style>
<p>${message}</p><a href="${origin}">Back to Nuvio</a>`;
}

// ------------------------------------------------------------ shortcuts

app.get('/api/shortcut/play', requireShortcutToken, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).type('text/plain').send('Pass ?q=<title>');

    const addons = await installedAddons(req.user);
    const hits = await addonsApi.search(addons, q);
    if (!hits.length) return res.status(404).type('text/plain').send(`Nothing found for "${q}".`);

    const target = hits[0];
    const list = await addonsApi.streams(addons, target.type, target.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${target.name}". Try a debrid addon.`);

    const url = vlc.xCallback(best.url, { filename: best.filename });
    if (req.query.format === 'json') {
      return res.json({ title: target.name, stream: best.label, source: best.addon, vlc: url });
    }
    res.type('text/plain').send(url);
  } catch (err) { next(err); }
});

app.get('/api/shortcut/continue', requireShortcutToken, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    const [progress, lib] = await Promise.all([
      nuvio.watchProgress(token, await profileIndex(req.user)),
      nuvio.library(token, await profileIndex(req.user)),
    ]);
    const items = await fillMetadata(await installedAddons(req.user), nuvio.continueWatching(progress, lib));
    if (!items.length) return res.status(404).type('text/plain').send('Nothing in progress.');

    if (req.query.index === undefined) {
      return res.json(items.map((i) => ({ name: i.name, type: i.type, id: i.id })));
    }

    const item = items[Number(req.query.index) || 0];
    const list = await addonsApi.streams(await installedAddons(req.user), item.type, item.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${item.name}".`);
    res.type('text/plain').send(vlc.xCallback(best.url, { filename: best.filename }));
  } catch (err) { next(err); }
});

// ---------------------------------------------------------------- misc

app.get('/healthz', (req, res) => res.json({ ok: true, users: store.count() }));

// index.html must never be cached or a stale copy keeps pointing at old
// asset versions; the versioned assets themselves can cache hard.
app.use(express.static(path.join(__dirname, '..', 'public'), {
  etag: true,
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
    else res.setHeader('Cache-Control', 'public, max-age=86400');
  },
}));

app.use((err, req, res, _next) => {
  console.error(err);
  // A refresh token that Nuvio has revoked shouldn't look like a server fault.
  if (/refresh|invalid|expired|JWT/i.test(err.message)) {
    return res.status(401).json({ error: 'Your Nuvio session expired. Sign in again.' });
  }
  res.status(502).json({ error: err.message });
});

await store.init();

if (process.env.NUVIO_SERVER) {
  try {
    const found = await nuvio.discover(process.env.NUVIO_SERVER);
    console.log(`Discovered self-hosted backend at ${found.backendUrl}`);
  } catch (err) {
    console.warn(`Server discovery failed, using configured values: ${err.message}`);
  }
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Nuvio iOS bridge on :${PORT} — backend ${nuvio.config.backendUrl}, ${store.count()} saved session(s)`);
});
