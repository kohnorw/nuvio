import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import * as nuvio from './nuvio.js';
import * as addonsApi from './addons.js';
import * as vlc from './vlc.js';
import * as store from './sessions.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const PUBLIC_URL = (process.env.PUBLIC_URL || '').replace(/\/+$/, '');
const ALLOW_SIGNUP = process.env.ALLOW_SIGNUP === 'true';

const app = express();
app.use(express.json());
app.use(cookieParser());
app.set('trust proxy', true);

// ---------------------------------------------------------------- auth

// Every request resolves to a user record or none. Nothing is global any
// more: two people on the same container each get their own Nuvio session,
// profile selection and theme.
function currentUser(req) {
  return store.get(req.cookies?.nib_sid);
}

function requireUser(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to your Nuvio account.' });
  req.user = user;
  next();
}

// Shortcuts can't hold a cookie, so each user generates a personal token from
// Settings and it identifies them the same way the cookie does.
function requireShortcutToken(req, res, next) {
  const user = store.getByToken(req.query.token || req.get('x-shortcut-token'));
  if (!user) return res.status(401).json({ error: 'Unknown or missing shortcut token.' });
  req.user = user;
  next();
}

// Supabase access tokens last an hour; refresh a minute early so a request
// doesn't fail and need retrying.
async function accessToken(user) {
  if (Date.now() < user.session.expiresAt - 60_000) return user.session.accessToken;
  const refreshed = await nuvio.refresh(user.session.refreshToken);
  await store.update(user, { session: refreshed });
  return refreshed.accessToken;
}

// Failed sign-ins are rate limited per IP. This endpoint proxies to someone
// else's auth server, so it shouldn't be usable as a password oracle.
const attempts = new Map();
function throttle(req, res, next) {
  const ip = req.ip || 'unknown';
  const record = attempts.get(ip) || { count: 0, resetAt: Date.now() + 900_000 };
  if (Date.now() > record.resetAt) { record.count = 0; record.resetAt = Date.now() + 900_000; }
  if (record.count >= 10) {
    return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });
  }
  attempts.set(ip, record);
  req.failedAttempt = () => { record.count += 1; };
  next();
}

app.post('/api/login', throttle, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });

  try {
    const session = await nuvio.signIn(email, password);
    const user = await store.create(session);
    setSessionCookie(res, req, user.sid);
    res.json({ email: session.user.email });
  } catch (err) {
    req.failedAttempt();
    res.status(401).json({ error: err.message });
  }
});

app.post('/api/signup', throttle, async (req, res) => {
  if (!ALLOW_SIGNUP) return res.status(403).json({ error: 'Sign-up is off on this server.' });
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter an email and password.' });

  try {
    const result = await nuvio.signUp(email, password);
    // Nuvio may require email confirmation, in which case there's no session
    // to hand back yet and the person needs to check their inbox.
    if (!result.session) return res.json({ confirmationRequired: true, email });
    const user = await store.create(result.session);
    setSessionCookie(res, req, user.sid);
    res.json({ email: result.session.user.email });
  } catch (err) {
    req.failedAttempt();
    res.status(400).json({ error: err.message });
  }
});

function setSessionCookie(res, req, sid) {
  res.cookie('nib_sid', sid, {
    httpOnly: true,
    sameSite: 'lax',
    secure: req.secure,
    maxAge: 1000 * 60 * 60 * 24 * 365,
  });
}

app.post('/api/logout', async (req, res) => {
  const user = currentUser(req);
  if (user) {
    await nuvio.signOut(user.session.accessToken);
    await store.destroy(user.sid);
  }
  res.clearCookie('nib_sid');
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  const user = currentUser(req);
  res.json({
    signedIn: Boolean(user),
    email: user?.email || null,
    backendUrl: nuvio.config.backendUrl,
    profileIndex: user?.profileIndex ?? null,
    theme: user?.theme || 'White',
    shortcutToken: user?.shortcutToken || null,
    prefs: { ...DEFAULT_PREFS, ...(user?.prefs || {}) },
    signupAllowed: ALLOW_SIGNUP,
  });
});

// ------------------------------------------------------------- profiles

app.get('/api/profiles', requireUser, async (req, res, next) => {
  try {
    res.json(await nuvio.profiles(await accessToken(req.user)));
  } catch (err) { next(err); }
});

app.post('/api/profile', requireUser, async (req, res, next) => {
  try {
    await store.update(req.user, { profileIndex: Number(req.body?.index) });
    addonsApi.clearCache();
    res.json({ profileIndex: req.user.profileIndex });
  } catch (err) { next(err); }
});

app.post('/api/theme', requireUser, async (req, res, next) => {
  try {
    await store.update(req.user, { theme: String(req.body?.theme || 'White') });
    res.json({ theme: req.user.theme });
  } catch (err) { next(err); }
});

app.post('/api/shortcut-token', requireUser, async (req, res, next) => {
  try {
    res.json({ token: await store.rotateShortcutToken(req.user) });
  } catch (err) { next(err); }
});

// ------------------------------------------------------------- browsing

// Profile numbering is decided by the server, not by us — the provisioner
// treats profile_index as 0-based while the app's default is 1, so never
// assume. If nothing is selected yet, use whichever profile comes back first.
async function profileIndex(user) {
  if (user.profileIndex != null) return user.profileIndex;
  const list = await nuvio.profiles(await accessToken(user));
  const first = list[0]?.index ?? 1;
  await store.update(user, { profileIndex: first });
  return first;
}

async function installedAddons(user) {
  return addonsApi.hydrate(await nuvio.addons(await accessToken(user), await profileIndex(user)));
}

app.get('/api/catalogs', requireUser, async (req, res, next) => {
  try {
    res.json(addonsApi.catalogList(await installedAddons(req.user), { includeRequiredExtras: true }));
  } catch (err) { next(err); }
});

app.get('/api/collections', requireUser, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    res.json(await nuvio.collections(token, await profileIndex(req.user)));
  } catch (err) { next(err); }
});

app.get('/api/catalog', requireUser, async (req, res, next) => {
  try {
    const { transportUrl, type, id, skip, genre } = req.query;
    res.json(await addonsApi.catalog(await installedAddons(req.user), {
      transportUrl, type, id, genre: genre || null, skip: Number(skip || 0),
    }));
  } catch (err) { next(err); }
});

app.get('/api/home', requireUser, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    const index = await profileIndex(req.user);

    const [addons, settings, userCollections] = await Promise.all([
      installedAddons(req.user),
      nuvio.homeCatalogSettings(token, index).catch(() => null),
      nuvio.collections(token, index).catch(() => []),
    ]);

    const rows = orderCatalogs(addonsApi.catalogList(addons), settings).slice(0, ROW_LIMIT);

    const catalogRows = await Promise.all(rows.map(async (row) => ({
      ...row,
      items: await addonsApi.catalog(addons, row).catch(() => []),
    })));

    res.json({
      hero: buildHeroPool(catalogRows),
      collections: collectionRows(userCollections),
      rows: catalogRows.filter((row) => row.items.length),
    });
  } catch (err) { next(err); }
});

const HERO_ITEM_LIMIT = 8;

// localizedMediaTypeLabel, ported from core/i18n. Anything not listed falls
// back to the raw type with an initial capital, as the app does.
const TYPE_LABELS = {
  movie: 'Movies',
  series: 'Series',
  anime: 'Anime',
  channel: 'Channels',
  tv: 'TV',
};

function typeLabel(type) {
  if (!type) return null;
  return TYPE_LABELS[type.trim().toLowerCase()]
    || type.charAt(0).toUpperCase() + type.slice(1);
}

// home_catalog_default_title is "%1$s - %2$s" — catalog name, then media type.
// "Popular - Movies", "Top Rated - Series".
function catalogLabel(row) {
  // A collection folder is named by the person, so say where it lives rather
  // than guessing a media type it may not have.
  if (row.isCollection) return row.collection ? `${row.collection} - ${row.name}` : row.name;

  const label = typeLabel(row.type);
  if (!label) return row.name;
  // Don't produce "Popular Movies - Movies" when the name already says it.
  if (row.name.toLowerCase().includes(label.toLowerCase())) return row.name;
  return `${row.name} - ${label}`;
}

// HomeRepository pools items across every catalog row, dedupes on type:id,
// shuffles, and takes eight. The shuffle is seeded per request there; here a
// day-stable seed keeps the banner from reshuffling on every pull-to-refresh
// while still changing over time. Each item keeps the row it came from so the
// banner can say what it is showing.
function buildHeroPool(rows) {
  const seen = new Set();
  const pool = [];

  for (const row of rows) {
    for (const item of row.items) {
      const key = `${item.type}:${item.id}`;
      // A banner needs artwork; a card with no backdrop looks broken at
      // full-bleed size.
      if (seen.has(key) || !(item.background || item.poster)) continue;
      seen.add(key);
      pool.push({
        ...item,
        source: catalogLabel(row),
        sourceAddon: row.addonName || null,
      });
    }
  }

  return shuffle(pool, dailySeed()).slice(0, HERO_ITEM_LIMIT);
}

function dailySeed() {
  return Math.floor(Date.now() / 86_400_000);
}

// Deterministic Fisher-Yates so the same seed gives the same order.
function shuffle(items, seed) {
  const out = [...items];
  let state = seed || 1;
  const next = () => {
    state = (state * 1664525 + 1013904223) % 4294967296;
    return state / 4294967296;
  };
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(next() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}

const ROW_LIMIT = Number(process.env.HOME_ROW_LIMIT || 10);

// Applies the account's home catalog settings: drop what's disabled, order by
// what's left. No settings means show everything in install order, which is
// the app's own fallback.
function orderCatalogs(catalogs, settings) {
  if (!settings?.length) return catalogs;

  const key = (addonId, type, catalogId) => `${addonId}|${type}|${catalogId}`;
  const rules = new Map(settings.map((s) => [key(s.addonId, s.type, s.catalogId), s]));

  return catalogs
    .map((c) => ({ catalog: c, rule: rules.get(key(c.addonId, c.type, c.id)) }))
    .filter(({ rule }) => !rule || rule.enabled)
    .sort((a, b) => (a.rule?.order ?? 999) - (b.rule?.order ?? 999))
    .map(({ catalog }) => catalog);
}

// A collection row's tiles are its *folders*, not the titles inside them —
// HomeCollectionRowSection.kt renders `entries = collection.folders`, each as
// a cover image with the folder name under it. That's the "Streaming" and
// "Genres" rows on desktop. Tapping a folder opens what's inside.
//
// Nothing is fetched from addons here, so collection rows cost one RPC for
// the whole home screen rather than one request per source.
function collectionRows(userCollections) {
  return userCollections
    .filter((collection) => collection.folders.length)
    .map((collection) => ({
      id: collection.id,
      name: collection.title,
      folders: collection.folders.map((folder) => ({
        id: folder.id,
        title: folder.title,
        cover: folder.cover,
        coverEmoji: folder.coverEmoji,
        tileShape: folder.tileShape,
        hideTitle: folder.hideTitle,
      })),
    }));
}

// Opening a folder merges every catalog source it names, deduped. Sources
// often overlap, and one dead addon shouldn't empty the folder.
app.get('/api/collection/:collectionId/:folderId', requireUser, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    const index = await profileIndex(req.user);
    const [addons, all] = await Promise.all([
      installedAddons(req.user),
      nuvio.collections(token, index),
    ]);

    const collection = all.find((c) => c.id === req.params.collectionId);
    const folder = collection?.folders.find((f) => f.id === req.params.folderId);
    if (!folder) return res.status(404).json({ error: 'That folder is no longer in your collections.' });

    const results = await Promise.all(folder.sources.map(async (source) => {
      const addon = addons.find((a) => a.manifest.id === source.addonId);
      if (!addon) return [];
      return addonsApi.catalog(addons, {
        transportUrl: addon.transportUrl,
        type: source.type,
        id: source.catalogId,
        genre: source.genre,
        skip: Number(req.query.skip || 0),
      }).catch(() => []);
    }));

    const seen = new Set();
    const items = [];
    for (const item of results.flat()) {
      const key = `${item.type}:${item.id}`;
      if (seen.has(key)) continue;
      seen.add(key);
      items.push(item);
    }

    res.json({ title: folder.title, collection: collection.title, items });
  } catch (err) { next(err); }
});

app.get('/api/library', requireUser, async (req, res, next) => {
  try {
    res.json(await nuvio.library(await accessToken(req.user), await profileIndex(req.user)));
  } catch (err) { next(err); }
});

app.get('/api/search', requireUser, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json([]);
    res.json(await addonsApi.search(await installedAddons(req.user), q, { type: req.query.type }));
  } catch (err) { next(err); }
});

app.get('/api/meta/:type/:id', requireUser, async (req, res, next) => {
  try {
    res.json(await addonsApi.meta(await installedAddons(req.user), req.params.type, req.params.id));
  } catch (err) { next(err); }
});

app.get('/api/streams/:type/:id', requireUser, async (req, res, next) => {
  try {
    const { type, id } = req.params;
    const [list, upcoming] = await Promise.all([
      addonsApi.streams(await installedAddons(req.user), type, id),
      nextEpisodeId(req.user, type, id),
    ]);
    res.json({
      next: upcoming,
      streams: list.map((s) => ({ ...s, vlc: s.playable ? vlc.build(s.url, { filename: s.filename }) : null })),
    });
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- handoff

app.get('/play', (req, res) => {
  const target = req.query.url;
  if (!target || !/^https?:\/\//i.test(target)) {
    return res.status(400).send('Give me an http(s) stream URL to hand over.');
  }

  // Nothing is written to the account here. Playing something must not put it
  // in Continue Watching, so the hand-off only sets where VLC returns to:
  // the next episode when binge is on, otherwise the app.
  const successUrl = req.query.next
    ? `${originOf(req)}/play/auto/series/${encodeURIComponent(req.query.next)}`
    : originOf(req);

  res.redirect(302, vlc.xCallback(target, { filename: req.query.filename, successUrl }));
});

app.post('/api/prefs', requireUser, async (req, res, next) => {
  try {
    const prefs = {
      autoplay: Boolean(req.body?.autoplay),
      binge: Boolean(req.body?.binge),
      quality: ['any', '2160p', '1080p', '720p'].includes(req.body?.quality) ? req.body.quality : 'any',
    };
    await store.update(req.user, { prefs });
    res.json(prefs);
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- autoplay

const DEFAULT_PREFS = { autoplay: false, binge: false, quality: 'any' };

// Picks what the person would almost certainly have tapped: playable, matching
// their quality preference if one is set, best-ranked otherwise.
function pickStream(list, quality = 'any') {
  const playable = list.filter((s) => s.playable);
  if (!playable.length) return null;
  if (quality !== 'any') {
    const match = playable.find((s) => (s.badges || []).includes(quality));
    if (match) return match;
  }
  return playable[0];
}

// Series episode ids are `<series>:<season>:<episode>`. The next episode is
// whatever follows in the addon's own ordering, so ask the meta addon rather
// than assuming episode+1 exists.
async function nextEpisodeId(user, type, id) {
  if (type !== 'series') return null;
  const baseId = id.split(':')[0];
  try {
    const meta = await addonsApi.meta(await installedAddons(user), 'series', baseId);
    const videos = meta.videos || [];
    const at = videos.findIndex((v) => v.id === id);
    return at >= 0 && at + 1 < videos.length ? videos[at + 1].id : null;
  } catch {
    return null;
  }
}

function originOf(req) {
  return PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
}

// Either cookie or shortcut token — a binge chain started from a Shortcut has
// no cookie, and one started in Safari has no token.
function requireUserOrToken(req, res, nextFn) {
  const user = currentUser(req) || store.getByToken(req.query.token);
  if (!user) return res.status(401).send('Sign in first.');
  req.user = user;
  nextFn();
}

// The whole binge mechanism: hand VLC this episode, and set x-success to the
// *next* episode's copy of this same route. When VLC finishes and bounces
// back, Safari hits that URL, which redirects straight into VLC again. No
// queue state on the server — each link only needs to know its successor.
app.get('/play/auto/:type/:id', requireUserOrToken, async (req, res, next) => {
  try {
    const { type, id } = req.params;
    const prefs = { ...DEFAULT_PREFS, ...(req.user.prefs || {}) };

    const list = await addonsApi.streams(await installedAddons(req.user), type, id);
    const best = pickStream(list, prefs.quality);
    if (!best) {
      return res.status(404).send(noStreamPage(originOf(req), 'No playable stream for this episode.'));
    }

    const token = req.query.token ? `?token=${encodeURIComponent(req.query.token)}` : '';
    let successUrl = originOf(req);

    if (prefs.binge && type === 'series') {
      const upcoming = await nextEpisodeId(req.user, type, id);
      if (upcoming) {
        successUrl = `${originOf(req)}/play/auto/series/${encodeURIComponent(upcoming)}${token}`;
      }
    }

    res.redirect(302, vlc.xCallback(best.url, { filename: best.filename, successUrl }));
  } catch (err) { next(err); }
});

// ------------------------------------------------------------ shortcuts

app.get('/api/shortcut/play', requireShortcutToken, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).type('text/plain').send('Pass ?q=<title>');

    const addons = await installedAddons(req.user);
    const hits = await addonsApi.search(addons, q);
    if (!hits.length) return res.status(404).type('text/plain').send(`Nothing found for "${q}".`);

    const target = hits[0];
    const list = await addonsApi.streams(addons, target.type, target.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${target.name}". Try a debrid addon.`);

    const url = vlc.xCallback(best.url, { filename: best.filename });
    if (req.query.format === 'json') {
      return res.json({ title: target.name, stream: best.label, source: best.addon, vlc: url });
    }
    res.type('text/plain').send(url);
  } catch (err) { next(err); }
});

// ---------------------------------------------------------------- misc

app.get('/healthz', (req, res) => res.json({ ok: true, users: store.count() }));

// index.html must never be cached or a stale copy keeps pointing at old
// asset versions; the versioned assets themselves can cache hard.
app.use(express.static(path.join(__dirname, '..', 'public'), {
  etag: true,
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
    else res.setHeader('Cache-Control', 'public, max-age=86400');
  },
}));

app.use((err, req, res, _next) => {
  console.error(err);
  // A refresh token that Nuvio has revoked shouldn't look like a server fault.
  if (/refresh|invalid|expired|JWT/i.test(err.message)) {
    return res.status(401).json({ error: 'Your Nuvio session expired. Sign in again.' });
  }
  res.status(502).json({ error: err.message });
});

await store.init();

if (process.env.NUVIO_SERVER) {
  try {
    const found = await nuvio.discover(process.env.NUVIO_SERVER);
    console.log(`Discovered self-hosted backend at ${found.backendUrl}`);
  } catch (err) {
    console.warn(`Server discovery failed, using configured values: ${err.message}`);
  }
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Nuvio iOS bridge on :${PORT} — backend ${nuvio.config.backendUrl}, ${store.count()} saved session(s)`);
});
