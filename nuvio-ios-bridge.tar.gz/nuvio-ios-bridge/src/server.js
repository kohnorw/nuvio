import express from 'express';
import cookieParser from 'cookie-parser';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import * as nuvio from './nuvio.js';
import * as addonsApi from './addons.js';
import * as vlc from './vlc.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const STATE_DIR = process.env.STATE_DIR || '/data';
const STATE_FILE = path.join(STATE_DIR, 'state.json');
const SHORTCUT_TOKEN = process.env.SHORTCUT_TOKEN || '';
const PUBLIC_URL = (process.env.PUBLIC_URL || '').replace(/\/+$/, '');

// One Nuvio account per container. Tokens live in the /data volume so a
// restart doesn't sign you out, and never reach the browser.
let state = {
  session: null,       // { accessToken, refreshToken, expiresAt, user }
  profileIndex: 1,
  theme: 'White',
  sessions: [],        // browser session ids
};

async function loadState() {
  try {
    state = { ...state, ...JSON.parse(await fs.readFile(STATE_FILE, 'utf8')) };
  } catch {
    // First boot.
  }
}

async function saveState() {
  await fs.mkdir(STATE_DIR, { recursive: true });
  await fs.writeFile(STATE_FILE, JSON.stringify(state, null, 2), { mode: 0o600 });
}

// Supabase access tokens last an hour. Refresh a minute early rather than
// letting a request fail and having to retry it.
async function accessToken() {
  if (!state.session) throw new Error('Not signed in.');
  if (Date.now() < state.session.expiresAt - 60_000) return state.session.accessToken;

  const refreshed = await nuvio.refresh(state.session.refreshToken);
  state.session = refreshed;
  await saveState();
  return refreshed.accessToken;
}

const app = express();
app.use(express.json());
app.use(cookieParser());
app.set('trust proxy', true);

// ---------------------------------------------------------------- auth

function browserSignedIn(req) {
  const sid = req.cookies?.nib_sid;
  return Boolean(sid && state.sessions.includes(sid));
}

function requireSession(req, res, next) {
  if (!state.session) return res.status(401).json({ error: 'Sign in to your Nuvio account first.' });
  if (!browserSignedIn(req)) return res.status(401).json({ error: 'This browser is not signed in.' });
  next();
}

function requireToken(req, res, next) {
  if (!SHORTCUT_TOKEN) return res.status(403).json({ error: 'Shortcut access is off. Set SHORTCUT_TOKEN.' });
  const supplied = req.query.token || req.get('x-shortcut-token');
  if (supplied !== SHORTCUT_TOKEN) return res.status(401).json({ error: 'Bad token.' });
  if (!state.session) return res.status(401).json({ error: 'Sign in through the web app first.' });
  next();
}

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });

  try {
    const session = await nuvio.signIn(email, password);
    const sid = crypto.randomBytes(24).toString('hex');
    state.session = session;
    state.sessions = [...state.sessions.slice(-4), sid];
    await saveState();
    addonsApi.clearCache();

    res.cookie('nib_sid', sid, {
      httpOnly: true,
      sameSite: 'lax',
      secure: req.secure,
      maxAge: 1000 * 60 * 60 * 24 * 365,
    });
    res.json({ email: session.user.email });
  } catch (err) {
    // Supabase returns 400 for bad credentials and 401 for a bad apikey, and
    // those need very different fixes, so don't flatten them into one message.
    const hint = err.status === 401 && !nuvio.config.anonKey
      ? ' Set NUVIO_ANON_KEY — see the README.'
      : '';
    res.status(err.status === 401 ? 500 : 401).json({ error: err.message + hint });
  }
});

app.post('/api/logout', async (req, res) => {
  if (state.session) await nuvio.signOut(state.session.accessToken);
  state.session = null;
  state.sessions = [];
  await saveState();
  addonsApi.clearCache();
  res.clearCookie('nib_sid');
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  res.json({
    signedIn: Boolean(state.session) && browserSignedIn(req),
    email: state.session?.user?.email || null,
    backendUrl: nuvio.config.backendUrl,
    keyConfigured: Boolean(nuvio.config.anonKey),
    profileIndex: state.profileIndex,
    theme: state.theme,
    shortcutsEnabled: Boolean(SHORTCUT_TOKEN),
  });
});

// ------------------------------------------------------------- profiles

app.get('/api/profiles', requireSession, async (req, res, next) => {
  try {
    res.json(await nuvio.profiles(await accessToken()));
  } catch (err) { next(err); }
});

app.post('/api/profile', requireSession, async (req, res, next) => {
  try {
    state.profileIndex = Number(req.body?.index) || 1;
    await saveState();
    addonsApi.clearCache();
    res.json({ profileIndex: state.profileIndex });
  } catch (err) { next(err); }
});

app.post('/api/theme', requireSession, async (req, res, next) => {
  try {
    state.theme = String(req.body?.theme || 'White');
    await saveState();
    res.json({ theme: state.theme });
  } catch (err) { next(err); }
});

// ------------------------------------------------------------- browsing

async function installedAddons() {
  return addonsApi.hydrate(await nuvio.addons(await accessToken(), state.profileIndex));
}

app.get('/api/catalogs', requireSession, async (req, res, next) => {
  try {
    res.json(addonsApi.catalogList(await installedAddons()));
  } catch (err) { next(err); }
});

app.get('/api/catalog', requireSession, async (req, res, next) => {
  try {
    const { transportUrl, type, id, skip } = req.query;
    res.json(await addonsApi.catalog(await installedAddons(), {
      transportUrl, type, id, skip: Number(skip || 0),
    }));
  } catch (err) { next(err); }
});

app.get('/api/home', requireSession, async (req, res, next) => {
  try {
    const token = await accessToken();
    const [addons, progress, lib] = await Promise.all([
      installedAddons(),
      nuvio.watchProgress(token, state.profileIndex),
      nuvio.library(token, state.profileIndex),
    ]);

    // The app's home is continue-watching followed by a few addon rows. Cap
    // the rows so a phone on cellular isn't waiting on twenty addon calls.
    const rows = addonsApi.catalogList(addons).slice(0, 6);
    const loaded = await Promise.all(rows.map(async (row) => ({
      ...row,
      items: await addonsApi.catalog(addons, row).catch(() => []),
    })));

    res.json({
      continueWatching: nuvio.continueWatching(progress, lib).slice(0, 20),
      rows: loaded.filter((row) => row.items.length),
    });
  } catch (err) { next(err); }
});

app.get('/api/library', requireSession, async (req, res, next) => {
  try {
    res.json(await nuvio.library(await accessToken(), state.profileIndex));
  } catch (err) { next(err); }
});

app.get('/api/search', requireSession, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json([]);
    res.json(await addonsApi.search(await installedAddons(), q));
  } catch (err) { next(err); }
});

app.get('/api/meta/:type/:id', requireSession, async (req, res, next) => {
  try {
    res.json(await addonsApi.meta(await installedAddons(), req.params.type, req.params.id));
  } catch (err) { next(err); }
});

app.get('/api/streams/:type/:id', requireSession, async (req, res, next) => {
  try {
    const list = await addonsApi.streams(await installedAddons(), req.params.type, req.params.id);
    res.json(list.map((s) => ({ ...s, vlc: s.playable ? vlc.build(s.url, { filename: s.filename }) : null })));
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- handoff

app.get('/play', (req, res) => {
  const target = req.query.url;
  if (!target || !/^https?:\/\//i.test(target)) {
    return res.status(400).send('Give me an http(s) stream URL to hand over.');
  }
  const successUrl = PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
  res.redirect(302, vlc.xCallback(target, { filename: req.query.filename, successUrl }));
});

// ------------------------------------------------------------ shortcuts

app.get('/api/shortcut/play', requireToken, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).type('text/plain').send('Pass ?q=<title>');

    const addons = await installedAddons();
    const hits = await addonsApi.search(addons, q);
    if (!hits.length) return res.status(404).type('text/plain').send(`Nothing found for "${q}".`);

    const target = hits[0];
    const list = await addonsApi.streams(addons, target.type, target.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${target.name}". Try a debrid addon.`);

    const url = vlc.xCallback(best.url, { filename: best.filename });
    if (req.query.format === 'json') {
      return res.json({ title: target.name, stream: best.label, source: best.addon, vlc: url });
    }
    res.type('text/plain').send(url);
  } catch (err) { next(err); }
});

app.get('/api/shortcut/continue', requireToken, async (req, res, next) => {
  try {
    const token = await accessToken();
    const [progress, lib] = await Promise.all([
      nuvio.watchProgress(token, state.profileIndex),
      nuvio.library(token, state.profileIndex),
    ]);
    const items = nuvio.continueWatching(progress, lib);
    if (!items.length) return res.status(404).type('text/plain').send('Nothing in progress.');

    if (req.query.index === undefined) {
      return res.json(items.map((i) => ({ name: i.name, type: i.type, id: i.id })));
    }

    const item = items[Number(req.query.index) || 0];
    const list = await addonsApi.streams(await installedAddons(), item.type, item.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${item.name}".`);
    res.type('text/plain').send(vlc.xCallback(best.url, { filename: best.filename }));
  } catch (err) { next(err); }
});

// ---------------------------------------------------------------- misc

app.get('/healthz', (req, res) => res.json({
  ok: true,
  signedIn: Boolean(state.session),
  keyConfigured: Boolean(nuvio.config.anonKey),
}));

app.use(express.static(path.join(__dirname, '..', 'public')));

app.use((err, req, res, _next) => {
  console.error(err);
  res.status(502).json({ error: err.message });
});

await loadState();

if (process.env.NUVIO_SERVER) {
  try {
    const found = await nuvio.discover(process.env.NUVIO_SERVER);
    console.log(`Discovered self-hosted backend at ${found.backendUrl}`);
  } catch (err) {
    console.warn(`Server discovery failed, falling back to configured values: ${err.message}`);
  }
}

if (!nuvio.config.anonKey) {
  console.warn('NUVIO_ANON_KEY is not set — sign-in will fail. See the README.');
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Nuvio iOS bridge on :${PORT} — backend ${nuvio.config.backendUrl}`);
});
