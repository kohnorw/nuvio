import express from 'express';
import cookieParser from 'cookie-parser';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import * as nuvio from './nuvio.js';
import * as addonsApi from './addons.js';
import * as vlc from './vlc.js';
import * as store from './sessions.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const PUBLIC_URL = (process.env.PUBLIC_URL || '').replace(/\/+$/, '');
const ALLOW_SIGNUP = process.env.ALLOW_SIGNUP === 'true';

const app = express();
app.use(express.json());
app.use(cookieParser());
app.set('trust proxy', true);

// ---------------------------------------------------------------- auth

// Every request resolves to a user record or none. Nothing is global any
// more: two people on the same container each get their own Nuvio session,
// profile selection and theme.
function currentUser(req) {
  return store.get(req.cookies?.nib_sid);
}

function requireUser(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: 'Sign in to your Nuvio account.' });
  req.user = user;
  next();
}

// Shortcuts can't hold a cookie, so each user generates a personal token from
// Settings and it identifies them the same way the cookie does.
function requireShortcutToken(req, res, next) {
  const user = store.getByToken(req.query.token || req.get('x-shortcut-token'));
  if (!user) return res.status(401).json({ error: 'Unknown or missing shortcut token.' });
  req.user = user;
  next();
}

// Supabase access tokens last an hour; refresh a minute early so a request
// doesn't fail and need retrying.
async function accessToken(user) {
  if (Date.now() < user.session.expiresAt - 60_000) return user.session.accessToken;
  const refreshed = await nuvio.refresh(user.session.refreshToken);
  await store.update(user, { session: refreshed });
  return refreshed.accessToken;
}

// Failed sign-ins are rate limited per IP. This endpoint proxies to someone
// else's auth server, so it shouldn't be usable as a password oracle.
const attempts = new Map();
function throttle(req, res, next) {
  const ip = req.ip || 'unknown';
  const record = attempts.get(ip) || { count: 0, resetAt: Date.now() + 900_000 };
  if (Date.now() > record.resetAt) { record.count = 0; record.resetAt = Date.now() + 900_000; }
  if (record.count >= 10) {
    return res.status(429).json({ error: 'Too many attempts. Try again in a few minutes.' });
  }
  attempts.set(ip, record);
  req.failedAttempt = () => { record.count += 1; };
  next();
}

app.post('/api/login', throttle, async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });

  try {
    const session = await nuvio.signIn(email, password);
    const user = await store.create(session);
    setSessionCookie(res, req, user.sid);
    res.json({ email: session.user.email });
  } catch (err) {
    req.failedAttempt();
    res.status(401).json({ error: err.message });
  }
});

app.post('/api/signup', throttle, async (req, res) => {
  if (!ALLOW_SIGNUP) return res.status(403).json({ error: 'Sign-up is off on this server.' });
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: 'Enter an email and password.' });

  try {
    const result = await nuvio.signUp(email, password);
    // Nuvio may require email confirmation, in which case there's no session
    // to hand back yet and the person needs to check their inbox.
    if (!result.session) return res.json({ confirmationRequired: true, email });
    const user = await store.create(result.session);
    setSessionCookie(res, req, user.sid);
    res.json({ email: result.session.user.email });
  } catch (err) {
    req.failedAttempt();
    res.status(400).json({ error: err.message });
  }
});

function setSessionCookie(res, req, sid) {
  res.cookie('nib_sid', sid, {
    httpOnly: true,
    sameSite: 'lax',
    secure: req.secure,
    maxAge: 1000 * 60 * 60 * 24 * 365,
  });
}

app.post('/api/logout', async (req, res) => {
  const user = currentUser(req);
  if (user) {
    await nuvio.signOut(user.session.accessToken);
    await store.destroy(user.sid);
  }
  res.clearCookie('nib_sid');
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  const user = currentUser(req);
  res.json({
    signedIn: Boolean(user),
    email: user?.email || null,
    backendUrl: nuvio.config.backendUrl,
    profileIndex: user?.profileIndex ?? null,
    theme: user?.theme || 'White',
    shortcutToken: user?.shortcutToken || null,
    prefs: { ...DEFAULT_PREFS, ...(user?.prefs || {}) },
    signupAllowed: ALLOW_SIGNUP,
  });
});

// ------------------------------------------------------------- profiles

app.get('/api/profiles', requireUser, async (req, res, next) => {
  try {
    res.json(await nuvio.profiles(await accessToken(req.user)));
  } catch (err) { next(err); }
});

app.post('/api/profile', requireUser, async (req, res, next) => {
  try {
    await store.update(req.user, { profileIndex: Number(req.body?.index) });
    addonsApi.clearCache();
    res.json({ profileIndex: req.user.profileIndex });
  } catch (err) { next(err); }
});

app.post('/api/theme', requireUser, async (req, res, next) => {
  try {
    await store.update(req.user, { theme: String(req.body?.theme || 'White') });
    res.json({ theme: req.user.theme });
  } catch (err) { next(err); }
});

app.post('/api/shortcut-token', requireUser, async (req, res, next) => {
  try {
    res.json({ token: await store.rotateShortcutToken(req.user) });
  } catch (err) { next(err); }
});

// ------------------------------------------------------------- browsing

// Profile numbering is decided by the server, not by us — the provisioner
// treats profile_index as 0-based while the app's default is 1, so never
// assume. If nothing is selected yet, use whichever profile comes back first.
async function profileIndex(user) {
  if (user.profileIndex != null) return user.profileIndex;
  const list = await nuvio.profiles(await accessToken(user));
  const first = list[0]?.index ?? 1;
  await store.update(user, { profileIndex: first });
  return first;
}

async function installedAddons(user) {
  return addonsApi.hydrate(await nuvio.addons(await accessToken(user), await profileIndex(user)));
}

app.get('/api/catalogs', requireUser, async (req, res, next) => {
  try {
    res.json(addonsApi.catalogList(await installedAddons(req.user)));
  } catch (err) { next(err); }
});

app.get('/api/catalog', requireUser, async (req, res, next) => {
  try {
    const { transportUrl, type, id, skip } = req.query;
    res.json(await addonsApi.catalog(await installedAddons(req.user), {
      transportUrl, type, id, skip: Number(skip || 0),
    }));
  } catch (err) { next(err); }
});

app.get('/api/home', requireUser, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    const [addons, progress, lib] = await Promise.all([
      installedAddons(req.user),
      nuvio.watchProgress(token, await profileIndex(req.user)),
      nuvio.library(token, await profileIndex(req.user)),
    ]);

    const rows = addonsApi.catalogList(addons).slice(0, 6);
    const loaded = await Promise.all(rows.map(async (row) => ({
      ...row,
      items: await addonsApi.catalog(addons, row).catch(() => []),
    })));

    res.json({
      continueWatching: nuvio.continueWatching(progress, lib).slice(0, 20),
      rows: loaded.filter((row) => row.items.length),
    });
  } catch (err) { next(err); }
});

app.get('/api/library', requireUser, async (req, res, next) => {
  try {
    res.json(await nuvio.library(await accessToken(req.user), await profileIndex(req.user)));
  } catch (err) { next(err); }
});

app.get('/api/search', requireUser, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json([]);
    res.json(await addonsApi.search(await installedAddons(req.user), q));
  } catch (err) { next(err); }
});

app.get('/api/meta/:type/:id', requireUser, async (req, res, next) => {
  try {
    res.json(await addonsApi.meta(await installedAddons(req.user), req.params.type, req.params.id));
  } catch (err) { next(err); }
});

app.get('/api/streams/:type/:id', requireUser, async (req, res, next) => {
  try {
    const { type, id } = req.params;
    const [list, upcoming] = await Promise.all([
      addonsApi.streams(await installedAddons(req.user), type, id),
      nextEpisodeId(req.user, type, id),
    ]);
    res.json({
      next: upcoming,
      streams: list.map((s) => ({ ...s, vlc: s.playable ? vlc.build(s.url, { filename: s.filename }) : null })),
    });
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- handoff

app.get('/play', (req, res) => {
  const target = req.query.url;
  if (!target || !/^https?:\/\//i.test(target)) {
    return res.status(400).send('Give me an http(s) stream URL to hand over.');
  }
  // `next` carries the following episode id, so even a hand-picked stream
  // hands off to the auto-play route when playback ends.
  const successUrl = req.query.next
    ? `${originOf(req)}/play/auto/series/${encodeURIComponent(req.query.next)}`
    : originOf(req);
  res.redirect(302, vlc.xCallback(target, { filename: req.query.filename, successUrl }));
});

app.post('/api/prefs', requireUser, async (req, res, next) => {
  try {
    const prefs = {
      autoplay: Boolean(req.body?.autoplay),
      binge: Boolean(req.body?.binge),
      quality: ['any', '2160p', '1080p', '720p'].includes(req.body?.quality) ? req.body.quality : 'any',
    };
    await store.update(req.user, { prefs });
    res.json(prefs);
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- autoplay

const DEFAULT_PREFS = { autoplay: false, binge: false, quality: 'any' };

// Picks what the person would almost certainly have tapped: playable, matching
// their quality preference if one is set, best-ranked otherwise.
function pickStream(list, quality = 'any') {
  const playable = list.filter((s) => s.playable);
  if (!playable.length) return null;
  if (quality !== 'any') {
    const match = playable.find((s) => (s.badges || []).includes(quality));
    if (match) return match;
  }
  return playable[0];
}

// Series episode ids are `<series>:<season>:<episode>`. The next episode is
// whatever follows in the addon's own ordering, so ask the meta addon rather
// than assuming episode+1 exists.
async function nextEpisodeId(user, type, id) {
  if (type !== 'series') return null;
  const baseId = id.split(':')[0];
  try {
    const meta = await addonsApi.meta(await installedAddons(user), 'series', baseId);
    const videos = meta.videos || [];
    const at = videos.findIndex((v) => v.id === id);
    return at >= 0 && at + 1 < videos.length ? videos[at + 1].id : null;
  } catch {
    return null;
  }
}

function originOf(req) {
  return PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
}

// Either cookie or shortcut token — a binge chain started from a Shortcut has
// no cookie, and one started in Safari has no token.
function requireUserOrToken(req, res, nextFn) {
  const user = currentUser(req) || store.getByToken(req.query.token);
  if (!user) return res.status(401).send('Sign in first.');
  req.user = user;
  nextFn();
}

// The whole binge mechanism: hand VLC this episode, and set x-success to the
// *next* episode's copy of this same route. When VLC finishes and bounces
// back, Safari hits that URL, which redirects straight into VLC again. No
// queue state on the server — each link only needs to know its successor.
app.get('/play/auto/:type/:id', requireUserOrToken, async (req, res, next) => {
  try {
    const { type, id } = req.params;
    const prefs = { ...DEFAULT_PREFS, ...(req.user.prefs || {}) };

    const list = await addonsApi.streams(await installedAddons(req.user), type, id);
    const best = pickStream(list, prefs.quality);
    if (!best) {
      return res.status(404).send(noStreamPage(originOf(req), 'No playable stream for this episode.'));
    }

    let successUrl = originOf(req);
    if (prefs.binge && type === 'series') {
      const upcoming = await nextEpisodeId(req.user, type, id);
      if (upcoming) {
        const token = req.query.token ? `?token=${encodeURIComponent(req.query.token)}` : '';
        successUrl = `${originOf(req)}/play/auto/series/${encodeURIComponent(upcoming)}${token}`;
      }
    }

    res.redirect(302, vlc.xCallback(best.url, { filename: best.filename, successUrl }));
  } catch (err) { next(err); }
});

// VLC bounces back into Safari, so a dead end needs to be a readable page
// rather than a JSON blob.
function noStreamPage(origin, message) {
  return `<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{background:#0D0D0D;color:#fff;font:15px/22px -apple-system,system-ui;padding:48px 24px;text-align:center}
a{display:inline-block;margin-top:20px;padding:13px 28px;border-radius:40px;background:#fff;color:#0D0D0D;font-weight:700;text-decoration:none}</style>
<p>${message}</p><a href="${origin}">Back to Nuvio</a>`;
}

// ------------------------------------------------------------ shortcuts

app.get('/api/shortcut/play', requireShortcutToken, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).type('text/plain').send('Pass ?q=<title>');

    const addons = await installedAddons(req.user);
    const hits = await addonsApi.search(addons, q);
    if (!hits.length) return res.status(404).type('text/plain').send(`Nothing found for "${q}".`);

    const target = hits[0];
    const list = await addonsApi.streams(addons, target.type, target.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${target.name}". Try a debrid addon.`);

    const url = vlc.xCallback(best.url, { filename: best.filename });
    if (req.query.format === 'json') {
      return res.json({ title: target.name, stream: best.label, source: best.addon, vlc: url });
    }
    res.type('text/plain').send(url);
  } catch (err) { next(err); }
});

app.get('/api/shortcut/continue', requireShortcutToken, async (req, res, next) => {
  try {
    const token = await accessToken(req.user);
    const [progress, lib] = await Promise.all([
      nuvio.watchProgress(token, await profileIndex(req.user)),
      nuvio.library(token, await profileIndex(req.user)),
    ]);
    const items = nuvio.continueWatching(progress, lib);
    if (!items.length) return res.status(404).type('text/plain').send('Nothing in progress.');

    if (req.query.index === undefined) {
      return res.json(items.map((i) => ({ name: i.name, type: i.type, id: i.id })));
    }

    const item = items[Number(req.query.index) || 0];
    const list = await addonsApi.streams(await installedAddons(req.user), item.type, item.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${item.name}".`);
    res.type('text/plain').send(vlc.xCallback(best.url, { filename: best.filename }));
  } catch (err) { next(err); }
});

// ---------------------------------------------------------------- misc

app.get('/healthz', (req, res) => res.json({ ok: true, users: store.count() }));

// index.html must never be cached or a stale copy keeps pointing at old
// asset versions; the versioned assets themselves can cache hard.
app.use(express.static(path.join(__dirname, '..', 'public'), {
  etag: true,
  setHeaders(res, filePath) {
    if (filePath.endsWith('.html')) res.setHeader('Cache-Control', 'no-cache');
    else res.setHeader('Cache-Control', 'public, max-age=86400');
  },
}));

app.use((err, req, res, _next) => {
  console.error(err);
  // A refresh token that Nuvio has revoked shouldn't look like a server fault.
  if (/refresh|invalid|expired|JWT/i.test(err.message)) {
    return res.status(401).json({ error: 'Your Nuvio session expired. Sign in again.' });
  }
  res.status(502).json({ error: err.message });
});

await store.init();

if (process.env.NUVIO_SERVER) {
  try {
    const found = await nuvio.discover(process.env.NUVIO_SERVER);
    console.log(`Discovered self-hosted backend at ${found.backendUrl}`);
  } catch (err) {
    console.warn(`Server discovery failed, using configured values: ${err.message}`);
  }
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Nuvio iOS bridge on :${PORT} — backend ${nuvio.config.backendUrl}, ${store.count()} saved session(s)`);
});
