import express from 'express';
import cookieParser from 'cookie-parser';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import * as nuvio from './nuvio.js';
import * as addonsApi from './addons.js';
import * as vlc from './vlc.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 8080);
const STATE_DIR = process.env.STATE_DIR || '/data';
const STATE_FILE = path.join(STATE_DIR, 'state.json');
const SHORTCUT_TOKEN = process.env.SHORTCUT_TOKEN || '';
const PUBLIC_URL = (process.env.PUBLIC_URL || '').replace(/\/+$/, '');

// This is a single-account app: one Nuvio login, persisted so the container can
// restart without you signing in from your phone again. The authKey lives in
// the state file only — it is never handed to the browser.
let state = { authKey: null, email: null, sessions: [] };

async function loadState() {
  try {
    state = { ...state, ...JSON.parse(await fs.readFile(STATE_FILE, 'utf8')) };
  } catch {
    // First boot, or the volume is empty. Nothing to restore.
  }
}

async function saveState() {
  await fs.mkdir(STATE_DIR, { recursive: true });
  await fs.writeFile(STATE_FILE, JSON.stringify(state, null, 2), { mode: 0o600 });
}

const app = express();
app.use(express.json());
app.use(cookieParser());
app.set('trust proxy', true);

// ---------------------------------------------------------------- auth

function sessionOk(req) {
  const sid = req.cookies?.nib_sid;
  return Boolean(sid && state.sessions.includes(sid));
}

function requireSession(req, res, next) {
  if (!state.authKey) return res.status(401).json({ error: 'Sign in to your Nuvio account first.' });
  if (!sessionOk(req)) return res.status(401).json({ error: 'This browser is not signed in.' });
  next();
}

// Shortcuts cannot hold a cookie jar, so they authenticate with a static token
// instead. Leave SHORTCUT_TOKEN unset and these routes stay switched off.
function requireToken(req, res, next) {
  if (!SHORTCUT_TOKEN) return res.status(403).json({ error: 'Shortcut access is disabled. Set SHORTCUT_TOKEN.' });
  const supplied = req.query.token || req.get('x-shortcut-token');
  if (supplied !== SHORTCUT_TOKEN) return res.status(401).json({ error: 'Bad token.' });
  if (!state.authKey) return res.status(401).json({ error: 'Sign in through the web app first.' });
  next();
}

app.post('/api/login', async (req, res) => {
  const { email, password, authKey } = req.body || {};
  try {
    let account;
    if (authKey) {
      const user = await nuvio.whoami(authKey);
      account = { authKey, user };
    } else if (email && password) {
      account = await nuvio.login(email, password);
    } else {
      return res.status(400).json({ error: 'Enter your email and password, or paste an authKey.' });
    }

    const sid = crypto.randomBytes(24).toString('hex');
    state.authKey = account.authKey;
    state.email = account.user?.email || email || null;
    state.sessions = [...state.sessions.slice(-4), sid];
    await saveState();
    addonsApi.clearCache();

    res.cookie('nib_sid', sid, {
      httpOnly: true,
      sameSite: 'lax',
      secure: req.secure,
      maxAge: 1000 * 60 * 60 * 24 * 365,
    });
    res.json({ email: state.email });
  } catch (err) {
    res.status(401).json({ error: err.message });
  }
});

app.post('/api/logout', async (req, res) => {
  if (state.authKey) await nuvio.logout(state.authKey);
  state = { authKey: null, email: null, sessions: [] };
  await saveState();
  addonsApi.clearCache();
  res.clearCookie('nib_sid');
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  res.json({
    signedIn: Boolean(state.authKey) && sessionOk(req),
    email: state.email,
    apiBase: nuvio.NUVIO_API_BASE,
    shortcutsEnabled: Boolean(SHORTCUT_TOKEN),
  });
});

// ------------------------------------------------------------- browsing

async function installedAddons() {
  return nuvio.addonCollection(state.authKey);
}

app.get('/api/catalogs', requireSession, async (req, res, next) => {
  try {
    res.json(addonsApi.catalogList(await installedAddons()));
  } catch (err) { next(err); }
});

app.get('/api/catalog', requireSession, async (req, res, next) => {
  try {
    const { transportUrl, type, id, skip } = req.query;
    res.json(await addonsApi.catalog(await installedAddons(), {
      transportUrl, type, id, skip: Number(skip || 0),
    }));
  } catch (err) { next(err); }
});

app.get('/api/search', requireSession, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json([]);
    res.json(await addonsApi.search(await installedAddons(), q));
  } catch (err) { next(err); }
});

app.get('/api/continue', requireSession, async (req, res, next) => {
  try {
    res.json(nuvio.continueWatching(await nuvio.library(state.authKey)));
  } catch (err) { next(err); }
});

app.get('/api/meta/:type/:id', requireSession, async (req, res, next) => {
  try {
    res.json(await addonsApi.meta(await installedAddons(), req.params.type, req.params.id));
  } catch (err) { next(err); }
});

app.get('/api/streams/:type/:id', requireSession, async (req, res, next) => {
  try {
    const list = await addonsApi.streams(await installedAddons(), req.params.type, req.params.id);
    res.json(list.map((s) => ({ ...s, vlc: s.playable ? vlc.build(s.url, { filename: s.filename }) : null })));
  } catch (err) { next(err); }
});

// -------------------------------------------------------------- handoff

// The browser hits this and iOS takes over: a 302 to a vlc-x-callback:// URL
// makes Safari hand the stream to VLC. Keeping it server-side means the app
// works the same from a link, a bookmark, or a Shortcut.
app.get('/play', (req, res) => {
  const target = req.query.url;
  if (!target || !/^https?:\/\//i.test(target)) {
    return res.status(400).send('Give me an http(s) stream URL to hand over.');
  }
  const successUrl = PUBLIC_URL || `${req.protocol}://${req.get('host')}`;
  res.redirect(302, vlc.xCallback(target, { filename: req.query.filename, successUrl }));
});

// ------------------------------------------------------------ shortcuts

// Returns the VLC URL as plain text. In Shortcuts: Get Contents of URL ->
// Open URLs. That is the whole shortcut.
app.get('/api/shortcut/play', requireToken, async (req, res, next) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.status(400).type('text/plain').send('Pass ?q=<title>');

    const addons = await installedAddons();
    const hits = await addonsApi.search(addons, q);
    if (!hits.length) return res.status(404).type('text/plain').send(`Nothing found for "${q}".`);

    const target = hits[0];
    const list = await addonsApi.streams(addons, target.type, target.id);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${target.name}". Try a debrid addon.`);

    const url = vlc.xCallback(best.url, { filename: best.filename });
    if (req.query.format === 'json') {
      return res.json({ title: target.name, stream: best.label, source: best.addon, vlc: url });
    }
    res.type('text/plain').send(url);
  } catch (err) { next(err); }
});

// Same idea for picking up where you left off. ?index=0 is the most recent.
app.get('/api/shortcut/continue', requireToken, async (req, res, next) => {
  try {
    const items = nuvio.continueWatching(await nuvio.library(state.authKey));
    if (!items.length) return res.status(404).type('text/plain').send('Nothing in progress.');

    if (req.query.index === undefined) {
      return res.json(items.map((i) => ({ name: i.name, type: i.type, id: i.videoId })));
    }

    const item = items[Number(req.query.index) || 0];
    const list = await addonsApi.streams(await installedAddons(), item.type, item.videoId);
    const best = list.find((s) => s.playable);
    if (!best) return res.status(404).type('text/plain').send(`No direct stream for "${item.name}".`);
    res.type('text/plain').send(vlc.xCallback(best.url, { filename: best.filename }));
  } catch (err) { next(err); }
});

// ---------------------------------------------------------------- misc

app.get('/healthz', (req, res) => res.json({ ok: true, signedIn: Boolean(state.authKey) }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.use((err, req, res, _next) => {
  console.error(err);
  res.status(502).json({ error: err.message });
});

await loadState();
app.listen(PORT, '0.0.0.0', () => {
  console.log(`Nuvio iOS bridge on :${PORT} — account API ${nuvio.NUVIO_API_BASE}`);
});
