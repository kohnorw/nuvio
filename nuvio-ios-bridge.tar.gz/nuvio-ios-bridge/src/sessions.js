// Per-user session storage.
//
// The first cut of this app held one Nuvio session in a module variable, which
// meant the second person to sign in evicted the first. This replaces that with
// a keyed store: one record per signed-in user, addressed by an opaque cookie
// id that the browser holds and by a shortcut token the user generates.
//
// Records hold Supabase refresh tokens, which are long-lived credentials for
// someone else's account, so they are encrypted at rest with AES-256-GCM. The
// key comes from SESSION_SECRET, or is generated once into the data volume.

import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';

const STATE_DIR = process.env.STATE_DIR || '/data';
const STORE_FILE = path.join(STATE_DIR, 'sessions.json.enc');
const KEY_FILE = path.join(STATE_DIR, 'secret.key');
const IDLE_EXPIRY_MS = Number(process.env.SESSION_IDLE_DAYS || 60) * 86400_000;

let key = null;
/** @type {Map<string, object>} sid -> record */
const bySid = new Map();
/** @type {Map<string, string>} shortcut token -> sid */
const byToken = new Map();

async function loadKey() {
  if (process.env.SESSION_SECRET) {
    return crypto.createHash('sha256').update(process.env.SESSION_SECRET).digest();
  }
  try {
    return Buffer.from(await fs.readFile(KEY_FILE, 'utf8'), 'hex');
  } catch {
    const generated = crypto.randomBytes(32);
    await fs.mkdir(STATE_DIR, { recursive: true });
    await fs.writeFile(KEY_FILE, generated.toString('hex'), { mode: 0o600 });
    return generated;
  }
}

function encrypt(plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const body = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), body]).toString('base64');
}

function decrypt(payload) {
  const raw = Buffer.from(payload, 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, raw.subarray(0, 12));
  decipher.setAuthTag(raw.subarray(12, 28));
  return Buffer.concat([decipher.update(raw.subarray(28)), decipher.final()]).toString('utf8');
}

export async function init() {
  key = await loadKey();
  try {
    const records = JSON.parse(decrypt(await fs.readFile(STORE_FILE, 'utf8')));
    for (const record of records) index(record);
    prune();
  } catch {
    // No store yet, or the secret changed. Either way everyone signs in again.
  }
}

function index(record) {
  bySid.set(record.sid, record);
  if (record.shortcutToken) byToken.set(record.shortcutToken, record.sid);
}

async function persist() {
  await fs.mkdir(STATE_DIR, { recursive: true });
  await fs.writeFile(STORE_FILE, encrypt(JSON.stringify([...bySid.values()])), { mode: 0o600 });
}

function prune() {
  const cutoff = Date.now() - IDLE_EXPIRY_MS;
  for (const [sid, record] of bySid) {
    if ((record.lastSeen || 0) < cutoff) remove(sid);
  }
}

// ------------------------------------------------------------------- api

export async function create(session) {
  // One record per Nuvio account: signing in again from a new device replaces
  // the tokens rather than accumulating stale rows for the same person.
  const existing = [...bySid.values()].find((r) => r.userId === session.user.id);
  const sid = crypto.randomBytes(24).toString('hex');

  const record = {
    sid,
    userId: session.user.id,
    email: session.user.email,
    session,
    profileIndex: existing?.profileIndex ?? null,
    theme: existing?.theme ?? 'White',
    shortcutToken: existing?.shortcutToken ?? null,
    createdAt: existing?.createdAt ?? Date.now(),
    lastSeen: Date.now(),
  };

  if (existing) remove(existing.sid);
  index(record);
  await persist();
  return record;
}

export function get(sid) {
  if (!sid) return null;
  const record = bySid.get(sid);
  if (!record) return null;
  record.lastSeen = Date.now();
  return record;
}

export function getByToken(token) {
  if (!token) return null;
  return get(byToken.get(token));
}

export async function update(record, changes) {
  Object.assign(record, changes, { lastSeen: Date.now() });
  if (changes.shortcutToken) byToken.set(changes.shortcutToken, record.sid);
  await persist();
  return record;
}

export async function rotateShortcutToken(record) {
  if (record.shortcutToken) byToken.delete(record.shortcutToken);
  const token = crypto.randomBytes(24).toString('hex');
  await update(record, { shortcutToken: token });
  return token;
}

function remove(sid) {
  const record = bySid.get(sid);
  if (!record) return;
  if (record.shortcutToken) byToken.delete(record.shortcutToken);
  bySid.delete(sid);
}

export async function destroy(sid) {
  remove(sid);
  await persist();
}

export function count() {
  return bySid.size;
}
