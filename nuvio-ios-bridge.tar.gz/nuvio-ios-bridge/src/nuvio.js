// Client for the Nuvio cloud account API.
//
// Nuvio's account layer speaks the same JSON-RPC-ish dialect as Stremio's:
// every call is a POST of a JSON body to `<base>/api/<method>`, and the reply
// is `{ result: ... }` or `{ error: { message } }`. The base URL is
// configurable because Nuvio has moved hosts before — set NUVIO_API_BASE if
// your account lives somewhere other than the default.

const DEFAULT_BASE = process.env.NUVIO_API_BASE || 'https://api.nuvio.tv';
const TIMEOUT_MS = Number(process.env.HTTP_TIMEOUT_MS || 15000);

async function call(method, body, base = DEFAULT_BASE) {
  const url = `${base.replace(/\/+$/, '')}/api/${method}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });

  if (!res.ok) {
    throw new Error(`${method} failed: ${res.status} ${res.statusText}`);
  }

  const payload = await res.json();
  if (payload.error) {
    const message = payload.error.message || payload.error;
    throw new Error(`${method} rejected: ${message}`);
  }
  return payload.result;
}

export async function login(email, password, base) {
  const result = await call('login', { type: 'Login', email, password }, base);
  return {
    authKey: result.authKey,
    user: {
      id: result.user?._id,
      email: result.user?.email,
    },
  };
}

// Confirms an authKey pasted in by hand still works, and returns the account.
export async function whoami(authKey, base) {
  const result = await call('getUser', { type: 'GetUser', authKey }, base);
  return { id: result?._id, email: result?.email };
}

export async function logout(authKey, base) {
  try {
    await call('logout', { type: 'Logout', authKey }, base);
  } catch {
    // A dead key is already logged out as far as we care.
  }
}

// The installed addon list. Each entry carries a transportUrl (the addon's
// manifest.json) plus a cached copy of the manifest itself.
export async function addonCollection(authKey, base) {
  const result = await call('addonCollectionGet', {
    type: 'AddonCollectionGet',
    authKey,
    update: true,
  }, base);
  return result?.addons || [];
}

// Library rows: everything the account has added or watched, including
// playback position, which is what "Continue watching" is built from.
export async function library(authKey, base) {
  const result = await call('datastoreGet', {
    type: 'DatastoreGet',
    authKey,
    collection: 'libraryItem',
    all: true,
  }, base);
  return Array.isArray(result) ? result : [];
}

export function continueWatching(items) {
  return items
    .filter((item) => !item.removed && item.state?.timeOffset > 0)
    .filter((item) => {
      const { timeOffset = 0, duration = 0 } = item.state || {};
      // Drop anything effectively finished.
      return duration === 0 || timeOffset / duration < 0.95;
    })
    .sort((a, b) => new Date(b._mtime || 0) - new Date(a._mtime || 0))
    .map((item) => ({
      id: item._id,
      type: item.type,
      name: item.name,
      poster: item.poster,
      videoId: item.state?.video_id || item._id,
      season: item.state?.season,
      episode: item.state?.episode,
      timeOffset: item.state?.timeOffset || 0,
      duration: item.state?.duration || 0,
    }));
}

export { DEFAULT_BASE as NUVIO_API_BASE };
