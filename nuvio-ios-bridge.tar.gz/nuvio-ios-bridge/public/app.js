const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const THEMES = ['White', 'Gold', 'Jade', 'RoseGold', 'ArcticBlue', 'Graphite',
                'Crimson', 'Ocean', 'Violet', 'Emerald', 'Amber', 'Rose'];

const state = { profiles: [], profile: null, session: null, homeLoaded: false, libraryLoaded: false };
let prefs = { autoplay: false, binge: false, quality: 'any' };
const QUALITIES = [['any', 'Any'], ['2160p', '4K'], ['1080p', '1080p'], ['720p', '720p']];

// ------------------------------------------------------------------ util

async function api(path, options) {
  const res = await fetch(path, { credentials: 'same-origin', ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function post(path, body) {
  return api(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
}

function toast(message, ms = 3000) {
  const el = $('#toast');
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(() => { el.hidden = true; }, ms);
}

function screen(which) {
  $('#screen-auth').hidden = which !== 'auth';
  $('#screen-profiles').hidden = which !== 'profiles';
  $('#screen-details').hidden = which !== 'details';
  $('#screen-catalog').hidden = which !== 'catalog';
  $('#shell').hidden = which !== 'shell';
  window.scrollTo(0, 0);
}

function setTheme(name) {
  document.body.dataset.theme = THEMES.includes(name) ? name : 'White';
}

// ------------------------------------------------------------------ auth

let mode = 'login';

$('#signup-toggle').addEventListener('click', () => {
  mode = mode === 'login' ? 'signup' : 'login';
  $('#login-form button[type=submit]').textContent = mode === 'login' ? 'Sign in' : 'Create account';
  $('#signup-toggle').textContent = mode === 'login' ? 'Create an account' : 'I already have an account';
  $('#login-error').hidden = true;
});

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = new FormData(e.target);
  const button = e.target.querySelector('button[type=submit]');
  const error = $('#login-error');
  const label = button.textContent;

  error.hidden = true;
  button.disabled = true;
  button.textContent = mode === 'login' ? 'Signing in…' : 'Creating…';

  try {
    const body = { email: data.get('email'), password: data.get('password') };
    const result = await post(mode === 'login' ? '/api/login' : '/api/signup', body);
    if (result.confirmationRequired) {
      toast('Check your email to confirm the account, then sign in.', 7000);
      return;
    }
    await boot();
  } catch (err) {
    error.textContent = err.message;
    error.hidden = false;
  } finally {
    button.disabled = false;
    button.textContent = label;
  }
});

$('#gen-token').addEventListener('click', async () => {
  const { token } = await post('/api/shortcut-token');
  showShortcut(token);
  toast('New URL generated. Any previous one has stopped working.', 5000);
});

function showShortcut(token) {
  $('#shortcut-box').textContent = token
    ? `${location.origin}/api/shortcut/play?token=${token}&q=Dune`
    : 'Not generated yet.';
}

$('#signout').addEventListener('click', async () => {
  await post('/api/logout');
  location.reload();
});

$('#switch-profile').addEventListener('click', () => showProfiles());

// -------------------------------------------------------------- profiles

async function showProfiles() {
  state.profiles = await api('/api/profiles').catch(() => []);

  // One profile and nothing to choose: don't make them tap through a picker.
  if (state.profiles.length <= 1) return selectProfile(state.profiles[0] || { index: 1, name: 'Profile' });

  const grid = $('#profile-grid');
  grid.innerHTML = '';
  for (const p of state.profiles) {
    const card = document.createElement('button');
    card.className = 'profile-card';
    card.innerHTML = `<span class="avatar"></span><span class="profile-name"></span>`;
    const avatar = card.querySelector('.avatar');
    if (p.avatarUrl) avatar.style.backgroundImage = `url("${p.avatarUrl}")`;
    else { avatar.style.background = p.avatarColor; avatar.textContent = p.name.charAt(0).toUpperCase(); }
    card.querySelector('.profile-name').textContent = p.name;
    card.addEventListener('click', () => selectProfile(p));
    grid.append(card);
  }
  screen('profiles');
}

async function selectProfile(profile) {
  state.profile = profile;
  await post('/api/profile', { index: profile.index });
  state.homeLoaded = false;
  state.libraryLoaded = false;

  const avatar = $('#tab-avatar');
  if (profile.avatarUrl) avatar.style.backgroundImage = `url("${profile.avatarUrl}")`;
  else { avatar.style.background = profile.avatarColor || '#1E88E5'; avatar.textContent = (profile.name || '?').charAt(0).toUpperCase(); }

  $('#settings-profile').textContent = profile.name || `Profile ${profile.index}`;
  screen('shell');
  goto('Home');
}

// ------------------------------------------------------------------ tabs

function goto(tab) {
  $$('.tab').forEach((el) => { el.hidden = el.dataset.tab !== tab; });
  $$('.tab-item').forEach((el) => el.setAttribute('aria-selected', String(el.dataset.goto === tab)));
  window.scrollTo(0, 0);

  if (tab === 'Home' && !state.homeLoaded) loadHome();
  if (tab === 'Library' && !state.libraryLoaded) loadLibrary();
  if (tab === 'Search') $('#search-form input').focus();
}

$$('.tab-item').forEach((el) => el.addEventListener('click', () => goto(el.dataset.goto)));

// ------------------------------------------------------------------ home

async function loadHome() {
  const rows = $('#home-rows');
  rows.innerHTML = '<p class="empty">Loading your catalogs…</p>';

  try {
    const data = await api('/api/home');
    state.homeLoaded = true;
    rows.innerHTML = '';

    // The app's hero features a catalog title; continue-watching keeps its own
    // row, so don't show the same card twice.
    const featured = data.rows[0]?.items[0] || data.continueWatching[0];
    renderHero(featured);

    if (data.continueWatching.length) {
      rows.append(renderRow({ name: 'Continue watching', addonName: '' }, data.continueWatching, true));
    }
    for (const row of data.rows) rows.append(renderRow(row, row.items));

    if (!data.continueWatching.length && !data.rows.length) {
      rows.innerHTML = '<p class="empty">No addons returned anything. Check that this profile has addons installed in Nuvio.</p>';
    }
  } catch (err) {
    rows.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

function renderHero(item) {
  const hero = $('#hero');
  if (!item) { hero.hidden = true; return; }
  hero.hidden = false;
  hero.style.backgroundImage = `url("${item.background || item.poster || ''}")`;
  hero.innerHTML = `
    <h2 class="hero-title"></h2>
    <div class="hero-meta"></div>
    <div class="hero-actions"><button class="hero-play">View Details</button></div>
  `;
  hero.querySelector('.hero-title').textContent = item.name;

  // Meta is a dot-separated row of short facts, centred, as in HeroContentBlock.
  const meta = hero.querySelector('.hero-meta');
  const facts = [
    item.type ? item.type.charAt(0).toUpperCase() + item.type.slice(1) : null,
    item.year,
    item.imdbRating ? `★ ${item.imdbRating}` : null,
  ].filter(Boolean);
  facts.forEach((text, i) => {
    if (i) meta.insertAdjacentHTML('beforeend', '<span class="dot"></span>');
    const span = document.createElement('span');
    span.textContent = text;
    meta.append(span);
  });

  hero.querySelector('.hero-play').addEventListener('click', () => openDetails(item));
}

function renderRow(row, items, wide = false) {
  const section = document.createElement('section');
  section.className = 'row';
  // The app puts a circular chevron pill here, not the addon name. It opens
  // the full catalog — and is hidden when the row has no catalog behind it,
  // which is what the app does with an alpha-0 placeholder.
  section.innerHTML = `<div class="row-head">
      <h2 class="row-title"></h2>
      <button class="row-source" aria-label="View all"><svg viewBox="0 0 24 24"><path d="M9 5.5 15.5 12 9 18.5 7.6 17.1 12.7 12 7.6 6.9z"/></svg></button>
    </div><div class="rail${wide ? ' wide' : ''}"></div>`;
  section.querySelector('.row-title').textContent = row.name;

  const pill = section.querySelector('.row-source');
  if (row.transportUrl) {
    pill.addEventListener('click', () => openCatalog(row));
    section.querySelector('.row-head').addEventListener('click', (e) => {
      if (e.target.closest('.row-source')) return;
      openCatalog(row);
    });
  } else {
    pill.hidden = true;
  }
  const rail = section.querySelector('.rail');
  for (const item of items) rail.append(poster(item, wide));
  return section;
}

function poster(item, wide = false) {
  const b = document.createElement('button');
  b.className = 'poster';
  const art = wide ? (item.background || item.poster) : (item.poster || item.background);

  b.innerHTML = `<div class="art">${art ? '<img loading="lazy" alt="">' : '<span class="art-fallback"></span>'}${
    item.progress ? `<div class="bar"><span style="width:${Math.round(item.progress * 100)}%"></span></div>` : ''
  }</div><div class="label"></div>`;

  const title = item.name || item.parentId || item.id;
  b.querySelector('.label').textContent = title;

  if (art) {
    // A dead poster URL should leave initials behind, not a broken-image icon.
    const img = b.querySelector('img');
    img.src = art;
    img.addEventListener('error', () => {
      img.replaceWith(Object.assign(document.createElement('span'), {
        className: 'art-fallback', textContent: initialsOf(title),
      }));
    }, { once: true });
  } else {
    b.querySelector('.art-fallback').textContent = initialsOf(title);
  }

  // Continue-watching cards say which episode they'll resume.
  if (wide) {
    const sub = document.createElement('div');
    sub.className = 'sublabel';
    sub.textContent = [
      item.season != null ? `S${item.season} E${item.episode}` : null,
      item.episodeTitle,
    ].filter(Boolean).join(' · ');
    if (sub.textContent) b.append(sub);
  }

  b.addEventListener('click', () => openDetails(item));
  return b;
}

function initialsOf(text) {
  return String(text).replace(/^tt\d+$/, '?')
    .split(/\s+/).slice(0, 2).map((w) => w.charAt(0).toUpperCase()).join('');
}

// --------------------------------------------------------------- library

async function loadLibrary() {
  const grid = $('#library-grid');
  grid.innerHTML = '<p class="empty">Loading…</p>';
  try {
    const items = await api('/api/library');
    state.libraryLoaded = true;
    grid.innerHTML = '';
    if (!items.length) { grid.innerHTML = '<p class="empty">Your library is empty.</p>'; return; }
    for (const item of items) grid.append(poster(item));
  } catch (err) {
    grid.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

// ---------------------------------------------------------------- search

$('#search-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const q = new FormData(e.target).get('q').trim();
  if (!q) return;
  document.activeElement?.blur();

  const grid = $('#search-results');
  grid.innerHTML = '<p class="empty">Searching your addons…</p>';
  try {
    const items = await api(`/api/search?q=${encodeURIComponent(q)}`);
    grid.innerHTML = '';
    if (!items.length) { grid.innerHTML = '<p class="empty">Nothing found.</p>'; return; }
    for (const item of items) grid.append(poster(item));
  } catch (err) {
    grid.innerHTML = `<p class="empty">${err.message}</p>`;
  }
});

// ---------------------------------------------------------------- catalog

// "View all" opens the catalog as a paged grid. Addons return one page at a
// time, so `skip` walks forward and the button retires once a page comes
// back short of a full batch.
let catalogCursor = null;

async function openCatalog(row) {
  catalogCursor = { row, skip: 0 };
  $('#catalog-title').textContent = row.name;
  $('#catalog-grid').innerHTML = '<p class="empty">Loading…</p>';
  $('#catalog-more').hidden = true;
  screen('catalog');
  await loadCatalogPage(true);
}

async function loadCatalogPage(replace = false) {
  const { row, skip } = catalogCursor;
  const grid = $('#catalog-grid');
  const more = $('#catalog-more');
  more.disabled = true;

  try {
    const query = new URLSearchParams({
      transportUrl: row.transportUrl, type: row.type, id: row.id, skip: String(skip),
    });
    const items = await api(`/api/catalog?${query}`);
    if (replace) grid.innerHTML = '';
    if (!items.length) {
      if (replace) grid.innerHTML = '<p class="empty">This catalog came back empty.</p>';
      more.hidden = true;
      return;
    }
    for (const item of items) grid.append(poster(item));

    catalogCursor.skip = skip + items.length;
    more.hidden = items.length < 20;
  } catch (err) {
    if (replace) grid.innerHTML = `<p class="empty">${err.message}</p>`;
    else toast(err.message);
  } finally {
    more.disabled = false;
  }
}

$('#catalog-back').addEventListener('click', () => screen('shell'));
$('#catalog-more').addEventListener('click', () => loadCatalogPage(false));

// --------------------------------------------------------------- details

$('#details-back').addEventListener('click', () => screen('shell'));
$('#details-desc').addEventListener('click', (e) => e.currentTarget.classList.toggle('open'));

async function openDetails(item) {
  const type = item.type || 'movie';
  const baseId = (item.parentId || item.id).split(':')[0];

  screen('details');
  setBackdrop(item.background, item.poster);
  $('#details-title').textContent = item.name || baseId;
  $('#details-meta').textContent = '';
  $('#details-desc').textContent = '';
  $('#season-picker').innerHTML = '';
  $('#episode-list').innerHTML = '';
  $('#details-actions').innerHTML = '';

  // A movie has one thing to play, so it gets a Play button. A series shows
  // its episode list instead — except when a continue-watching card handed
  // us an exact episode id, which is already playable on its own.
  const isEpisode = type === 'series' && item.id.split(':').length >= 3;
  if (type !== 'series' || isEpisode) {
    const play = document.createElement('button');
    play.className = 'play-button';
    play.textContent = item.progress ? 'Resume' : 'Play';
    play.addEventListener('click', () => start(type, item.id, item.name));
    $('#details-actions').append(play);
  }

  try {
    const meta = await api(`/api/meta/${encodeURIComponent(type)}/${encodeURIComponent(baseId)}`);
    $('#details-title').textContent = meta.name;
    $('#details-meta').textContent = [meta.year, meta.imdbRating ? `★ ${meta.imdbRating}` : null]
      .filter(Boolean).join('  ·  ');
    $('#details-desc').textContent = meta.description || '';
    $('#details-desc').classList.remove('open');
    setBackdrop(meta.background, meta.poster || item.poster);
    if (meta.videos?.length) renderSeasons(meta.videos, item.id);
  } catch {
    // Details are a nicety; playing the thing is the point.
  }
}

// A portrait poster stretched to a landscape box looks wrong, so flag it and
// let CSS fill the sides with a blurred copy instead.
function setBackdrop(background, poster) {
  const el = $('#details-backdrop');
  const src = background || poster || '';
  el.style.backgroundImage = src ? `url("${src}")` : '';
  el.classList.toggle('poster-only', !background && Boolean(poster));
}

function renderSeasons(videos, activeId) {
  const seasons = [...new Set(videos.map((v) => v.season).filter((s) => s != null))].sort((a, b) => a - b);
  const picker = $('#season-picker');
  picker.innerHTML = '';

  const activeVideo = videos.find((v) => v.id === activeId);
  let currentSeason = activeVideo?.season ?? seasons[0];

  for (const season of seasons) {
    const chip = document.createElement('button');
    chip.className = 'chip';
    chip.textContent = season === 0 ? 'Specials' : `Season ${season}`;
    chip.setAttribute('aria-pressed', String(season === currentSeason));
    chip.addEventListener('click', () => {
      currentSeason = season;
      picker.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', String(c === chip)));
      renderEpisodes(videos.filter((v) => v.season === season), activeId);
    });
    picker.append(chip);
  }
  renderEpisodes(videos.filter((v) => v.season === currentSeason), activeId);
}

function renderEpisodes(videos, activeId) {
  const list = $('#episode-list');
  list.innerHTML = '';
  for (const v of videos) {
    const row = document.createElement('button');
    row.className = 'episode';
    row.setAttribute('aria-current', String(v.id === activeId));
    row.innerHTML = `<span class="num"></span><span class="ep-title"></span>`;
    row.querySelector('.num').textContent = v.episode ?? '';
    row.querySelector('.ep-title').textContent = v.title || `Episode ${v.episode}`;
    row.addEventListener('click', () => {
      list.querySelectorAll('.episode').forEach((e) => e.setAttribute('aria-current', String(e === row)));
      start('series', v.id, `${v.season != null ? `S${v.season} E${v.episode}` : ''} ${v.title || ''}`.trim());
    });
    list.append(row);
  }
}

// Every play action funnels through here: straight to VLC when auto-play is
// on, otherwise the stream picker sheet.
function start(type, id, label = '') {
  if (prefs.autoplay) return autoPlay(type, id);
  openStreamSheet(type, id, label);
}

function openStreamSheet(type, id, label) {
  $('#stream-sheet-sub').textContent = label || '';
  $('#sheet-backdrop').hidden = false;
  $('#stream-sheet').hidden = false;
  loadStreams(type, id);
}

function closeStreamSheet() {
  $('#stream-sheet').hidden = true;
  if ($('#playback-sheet').hidden) $('#sheet-backdrop').hidden = true;
}

async function loadStreams(type, id) {
  const box = $('#stream-list');
  box.innerHTML = '<p class="empty">Asking your addons…</p>';
  try {
    const { streams: list, next } = await api(`/api/streams/${encodeURIComponent(type)}/${encodeURIComponent(id)}`);
    box.innerHTML = '';
    if (!list.length) { box.innerHTML = '<p class="empty">No addon returned a stream for this.</p>'; return; }

    if (prefs.binge && next) {
      const note = document.createElement('p');
      note.className = 'autoplay-note';
      note.textContent = 'Binge is on — the next episode starts when VLC returns.';
      box.append(note);
    }
    for (const s of list) box.append(streamRow(s, prefs.binge ? next : null));
  } catch (err) {
    box.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

function streamRow(s, nextId) {
  const el = document.createElement(s.playable ? 'a' : 'div');
  el.className = `stream${s.playable ? '' : ' unplayable'}`;
  el.innerHTML = `
    <div class="info">
      <div class="stream-name"></div>
      <div class="badges"></div>
      <div class="from"></div>
    </div>
    <div class="go">${s.playable ? 'Play' : 'Torrent'}</div>`;

  el.querySelector('.stream-name').textContent = s.headline || s.label;

  const badges = el.querySelector('.badges');
  for (const text of s.badges || []) {
    const chip = document.createElement('span');
    chip.className = 'badge';
    chip.textContent = text;
    badges.append(chip);
  }
  if (!badges.childElementCount) badges.remove();

  el.querySelector('.from').textContent = s.playable ? s.addon : `${s.addon} — needs debrid`;

  // The full release name is long and rarely what you're scanning for, so it
  // sits behind a tap rather than taking six lines in every row.
  if (s.detail) {
    const detail = document.createElement('div');
    detail.className = 'stream-detail';
    detail.textContent = s.detail;
    el.querySelector('.info').append(detail);
    el.querySelector('.stream-name').addEventListener('click', (e) => {
      e.preventDefault();
      detail.classList.toggle('open');
    });
  }

  if (s.playable) {
    // With binge on, go through /play so the server can set x-success to the
    // next episode. Otherwise the direct vlc:// URL is one hop fewer.
    el.href = nextId
      ? `/play?url=${encodeURIComponent(s.url)}&next=${encodeURIComponent(nextId)}`
      : s.vlc.open;
    el.addEventListener('click', () => {
      closeStreamSheet();
      toast(nextId ? 'Opening in VLC — next episode queued' : 'Opening in VLC…');
    });
  }
  return el;
}

// The server resolves the best stream and redirects into VLC, so this is a
// plain navigation rather than a fetch — Safari needs to follow the 302 for
// the vlc:// hand-off to fire.
function autoPlay(type, id) {
  toast('Finding the best stream…');
  location.href = `/play/auto/${encodeURIComponent(type)}/${encodeURIComponent(id)}`;
}

// ------------------------------------------------------- playback sheet

function openSheet() {
  closeStreamSheet();
  $('#pref-autoplay').checked = prefs.autoplay;
  $('#pref-binge').checked = prefs.binge;
  renderQualityChips();
  $('#sheet-backdrop').hidden = false;
  $('#playback-sheet').hidden = false;
}

function closeSheet() {
  $('#playback-sheet').hidden = true;
  if ($('#stream-sheet').hidden) $('#sheet-backdrop').hidden = true;
}

function renderQualityChips() {
  const row = $('#pref-quality');
  row.innerHTML = '';
  for (const [value, label] of QUALITIES) {
    const chip = document.createElement('button');
    chip.className = 'chip';
    chip.textContent = label;
    chip.setAttribute('aria-pressed', String(prefs.quality === value));
    chip.addEventListener('click', () => {
      prefs.quality = value;
      renderQualityChips();
      savePrefs();
    });
    row.append(chip);
  }
}

async function savePrefs() {
  try {
    prefs = await post('/api/prefs', prefs);
  } catch (err) {
    toast(err.message);
  }
}

$('#playback-gear').addEventListener('click', openSheet);
$('#sheet-done').addEventListener('click', closeSheet);
$('#sheet-backdrop').addEventListener('click', () => { closeSheet(); closeStreamSheet(); });
$('#pref-autoplay').addEventListener('change', (e) => { prefs.autoplay = e.target.checked; savePrefs(); });
$('#pref-binge').addEventListener('change', (e) => { prefs.binge = e.target.checked; savePrefs(); });

// -------------------------------------------------------------- settings

function renderThemes(active) {
  const grid = $('#theme-grid');
  grid.innerHTML = '';
  for (const name of THEMES) {
    const probe = document.createElement('body');
    const swatch = document.createElement('button');
    swatch.className = 'swatch';
    swatch.dataset.theme = name;
    swatch.setAttribute('aria-label', name);
    swatch.setAttribute('aria-pressed', String(name === active));
    // Read the palette's accent straight from the stylesheet rather than
    // duplicating twelve hex values in here.
    probe.dataset.theme = name;
    probe.style.display = 'none';
    document.documentElement.append(probe);
    swatch.style.background = getComputedStyle(probe).getPropertyValue('--accent') || '#F5F5F5';
    probe.remove();

    swatch.addEventListener('click', async () => {
      setTheme(name);
      grid.querySelectorAll('.swatch').forEach((s) => s.setAttribute('aria-pressed', String(s === swatch)));
      await post('/api/theme', { theme: name });
    });
    grid.append(swatch);
  }
}

// ------------------------------------------------------------------ boot

async function boot() {
  const session = await api('/api/session').catch(() => ({ signedIn: false }));
  state.session = session;
  setTheme(session.theme);

  if (!session.signedIn) {
    $('#signup-toggle').hidden = !session.signupAllowed;
    screen('auth');
    return;
  }

  $('#signup-toggle').hidden = !session.signupAllowed;
  prefs = { ...prefs, ...(session.prefs || {}) };
  showShortcut(session.shortcutToken);
  $('#settings-email').textContent = session.email || '';
  $('#settings-backend').textContent = session.backendUrl.replace(/^https?:\/\//, '');
  renderThemes(session.theme);
  await showProfiles();
}

boot();
