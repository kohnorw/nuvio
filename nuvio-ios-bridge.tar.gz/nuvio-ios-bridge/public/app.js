const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];

const THEMES = ['White', 'Gold', 'Jade', 'RoseGold', 'ArcticBlue', 'Graphite',
                'Crimson', 'Ocean', 'Violet', 'Emerald', 'Amber', 'Rose'];

const state = { profiles: [], profile: null, session: null, homeLoaded: false, libraryLoaded: false };

// ------------------------------------------------------------------ util

async function api(path, options) {
  const res = await fetch(path, { credentials: 'same-origin', ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

function post(path, body) {
  return api(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
}

function toast(message, ms = 3000) {
  const el = $('#toast');
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toast.t);
  toast.t = setTimeout(() => { el.hidden = true; }, ms);
}

function screen(which) {
  $('#screen-auth').hidden = which !== 'auth';
  $('#screen-profiles').hidden = which !== 'profiles';
  $('#screen-details').hidden = which !== 'details';
  $('#shell').hidden = which !== 'shell';
  if (which !== 'details') window.scrollTo(0, 0);
}

function setTheme(name) {
  document.body.dataset.theme = THEMES.includes(name) ? name : 'White';
}

// ------------------------------------------------------------------ auth

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const data = new FormData(e.target);
  const button = e.target.querySelector('button');
  const error = $('#login-error');

  error.hidden = true;
  button.disabled = true;
  button.textContent = 'Signing in…';

  try {
    await post('/api/login', { email: data.get('email'), password: data.get('password') });
    await boot();
  } catch (err) {
    error.textContent = err.message;
    error.hidden = false;
  } finally {
    button.disabled = false;
    button.textContent = 'Sign in';
  }
});

$('#signout').addEventListener('click', async () => {
  await post('/api/logout');
  location.reload();
});

$('#switch-profile').addEventListener('click', () => showProfiles());

// -------------------------------------------------------------- profiles

async function showProfiles() {
  state.profiles = await api('/api/profiles').catch(() => []);

  // One profile and nothing to choose: don't make them tap through a picker.
  if (state.profiles.length <= 1) return selectProfile(state.profiles[0] || { index: 1, name: 'Profile' });

  const grid = $('#profile-grid');
  grid.innerHTML = '';
  for (const p of state.profiles) {
    const card = document.createElement('button');
    card.className = 'profile-card';
    card.innerHTML = `<span class="avatar"></span><span class="profile-name"></span>`;
    const avatar = card.querySelector('.avatar');
    if (p.avatarUrl) avatar.style.backgroundImage = `url("${p.avatarUrl}")`;
    else { avatar.style.background = p.avatarColor; avatar.textContent = p.name.charAt(0).toUpperCase(); }
    card.querySelector('.profile-name').textContent = p.name;
    card.addEventListener('click', () => selectProfile(p));
    grid.append(card);
  }
  screen('profiles');
}

async function selectProfile(profile) {
  state.profile = profile;
  await post('/api/profile', { index: profile.index });
  state.homeLoaded = false;
  state.libraryLoaded = false;

  const avatar = $('#tab-avatar');
  if (profile.avatarUrl) avatar.style.backgroundImage = `url("${profile.avatarUrl}")`;
  else { avatar.style.background = profile.avatarColor || '#1E88E5'; avatar.textContent = (profile.name || '?').charAt(0).toUpperCase(); }

  $('#settings-profile').textContent = profile.name || `Profile ${profile.index}`;
  screen('shell');
  goto('Home');
}

// ------------------------------------------------------------------ tabs

function goto(tab) {
  $$('.tab').forEach((el) => { el.hidden = el.dataset.tab !== tab; });
  $$('.tab-item').forEach((el) => el.setAttribute('aria-selected', String(el.dataset.goto === tab)));
  window.scrollTo(0, 0);

  if (tab === 'Home' && !state.homeLoaded) loadHome();
  if (tab === 'Library' && !state.libraryLoaded) loadLibrary();
  if (tab === 'Search') $('#search-form input').focus();
}

$$('.tab-item').forEach((el) => el.addEventListener('click', () => goto(el.dataset.goto)));

// ------------------------------------------------------------------ home

async function loadHome() {
  const rows = $('#home-rows');
  rows.innerHTML = '<p class="empty">Loading your catalogs…</p>';

  try {
    const data = await api('/api/home');
    state.homeLoaded = true;
    rows.innerHTML = '';

    const featured = data.continueWatching[0] || data.rows[0]?.items[0];
    renderHero(featured);

    if (data.continueWatching.length) {
      rows.append(renderRow({ name: 'Continue watching', addonName: '' }, data.continueWatching));
    }
    for (const row of data.rows) rows.append(renderRow(row, row.items));

    if (!data.continueWatching.length && !data.rows.length) {
      rows.innerHTML = '<p class="empty">No addons returned anything. Check that this profile has addons installed in Nuvio.</p>';
    }
  } catch (err) {
    rows.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

function renderHero(item) {
  const hero = $('#hero');
  if (!item) { hero.hidden = true; return; }
  hero.hidden = false;
  hero.style.backgroundImage = `url("${item.background || item.poster || ''}")`;
  hero.innerHTML = `
    <h2 class="hero-title"></h2>
    <p class="hero-meta"></p>
    <div class="hero-actions"><button class="hero-play">${item.progress ? 'Resume' : 'View'}</button></div>
  `;
  hero.querySelector('.hero-title').textContent = item.name;
  hero.querySelector('.hero-meta').textContent = [
    item.season != null ? `S${item.season} E${item.episode}` : null,
    item.year,
    item.imdbRating ? `★ ${item.imdbRating}` : null,
  ].filter(Boolean).join('  ·  ');
  hero.querySelector('.hero-play').addEventListener('click', () => openDetails(item));
}

function renderRow(row, items) {
  const section = document.createElement('section');
  section.className = 'row';
  section.innerHTML = `<div class="row-head"><h2 class="row-title"></h2><span class="row-source"></span></div><div class="rail"></div>`;
  section.querySelector('.row-title').textContent = row.name;
  section.querySelector('.row-source').textContent = row.addonName || '';
  const rail = section.querySelector('.rail');
  for (const item of items) rail.append(poster(item));
  return section;
}

function poster(item) {
  const b = document.createElement('button');
  b.className = 'poster';
  b.innerHTML = `<div class="art"><img loading="lazy" alt="" src="${item.poster || ''}">${
    item.progress ? `<div class="bar"><span style="width:${Math.round(item.progress * 100)}%"></span></div>` : ''
  }</div><div class="label"></div>`;
  b.querySelector('.label').textContent = item.name || item.id;
  b.addEventListener('click', () => openDetails(item));
  return b;
}

// --------------------------------------------------------------- library

async function loadLibrary() {
  const grid = $('#library-grid');
  grid.innerHTML = '<p class="empty">Loading…</p>';
  try {
    const items = await api('/api/library');
    state.libraryLoaded = true;
    grid.innerHTML = '';
    if (!items.length) { grid.innerHTML = '<p class="empty">Your library is empty.</p>'; return; }
    for (const item of items) grid.append(poster(item));
  } catch (err) {
    grid.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

// ---------------------------------------------------------------- search

$('#search-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const q = new FormData(e.target).get('q').trim();
  if (!q) return;
  document.activeElement?.blur();

  const grid = $('#search-results');
  grid.innerHTML = '<p class="empty">Searching your addons…</p>';
  try {
    const items = await api(`/api/search?q=${encodeURIComponent(q)}`);
    grid.innerHTML = '';
    if (!items.length) { grid.innerHTML = '<p class="empty">Nothing found.</p>'; return; }
    for (const item of items) grid.append(poster(item));
  } catch (err) {
    grid.innerHTML = `<p class="empty">${err.message}</p>`;
  }
});

// --------------------------------------------------------------- details

$('#details-back').addEventListener('click', () => screen('shell'));

async function openDetails(item) {
  const type = item.type || 'movie';
  const baseId = (item.parentId || item.id).split(':')[0];

  screen('details');
  $('#details-backdrop').style.backgroundImage = `url("${item.background || item.poster || ''}")`;
  $('#details-title').textContent = item.name || baseId;
  $('#details-meta').textContent = '';
  $('#details-desc').textContent = '';
  $('#season-picker').innerHTML = '';
  $('#episode-list').innerHTML = '';

  // Load streams for what was tapped straight away — for a continue-watching
  // card that's the exact episode, so there's nothing more to choose.
  loadStreams(type, item.id);

  try {
    const meta = await api(`/api/meta/${encodeURIComponent(type)}/${encodeURIComponent(baseId)}`);
    $('#details-title').textContent = meta.name;
    $('#details-meta').textContent = [meta.year, meta.imdbRating ? `★ ${meta.imdbRating}` : null]
      .filter(Boolean).join('  ·  ');
    $('#details-desc').textContent = meta.description || '';
    if (meta.background) $('#details-backdrop').style.backgroundImage = `url("${meta.background}")`;
    if (meta.videos?.length) renderSeasons(meta.videos, item.id);
  } catch {
    // Details are a nicety; the streams below are the point.
  }
}

function renderSeasons(videos, activeId) {
  const seasons = [...new Set(videos.map((v) => v.season).filter((s) => s != null))].sort((a, b) => a - b);
  const picker = $('#season-picker');
  picker.innerHTML = '';

  const activeVideo = videos.find((v) => v.id === activeId);
  let currentSeason = activeVideo?.season ?? seasons[0];

  for (const season of seasons) {
    const chip = document.createElement('button');
    chip.className = 'chip';
    chip.textContent = season === 0 ? 'Specials' : `Season ${season}`;
    chip.setAttribute('aria-pressed', String(season === currentSeason));
    chip.addEventListener('click', () => {
      currentSeason = season;
      picker.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', String(c === chip)));
      renderEpisodes(videos.filter((v) => v.season === season), activeId);
    });
    picker.append(chip);
  }
  renderEpisodes(videos.filter((v) => v.season === currentSeason), activeId);
}

function renderEpisodes(videos, activeId) {
  const list = $('#episode-list');
  list.innerHTML = '';
  for (const v of videos) {
    const row = document.createElement('button');
    row.className = 'episode';
    row.setAttribute('aria-current', String(v.id === activeId));
    row.innerHTML = `<span class="num"></span><span class="ep-title"></span>`;
    row.querySelector('.num').textContent = v.episode ?? '';
    row.querySelector('.ep-title').textContent = v.title || `Episode ${v.episode}`;
    row.addEventListener('click', () => {
      list.querySelectorAll('.episode').forEach((e) => e.setAttribute('aria-current', String(e === row)));
      loadStreams('series', v.id);
      $('.section-label')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
    list.append(row);
  }
}

async function loadStreams(type, id) {
  const box = $('#stream-list');
  box.innerHTML = '<p class="empty">Asking your addons…</p>';
  try {
    const list = await api(`/api/streams/${encodeURIComponent(type)}/${encodeURIComponent(id)}`);
    box.innerHTML = '';
    if (!list.length) { box.innerHTML = '<p class="empty">No addon returned a stream for this.</p>'; return; }
    for (const s of list) box.append(streamRow(s));
  } catch (err) {
    box.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

function streamRow(s) {
  const el = document.createElement(s.playable ? 'a' : 'div');
  el.className = `stream${s.playable ? '' : ' unplayable'}`;
  el.innerHTML = `<div class="info"><div class="name"></div><div class="from"></div></div>
                  <div class="go">${s.playable ? 'Play' : 'Torrent'}</div>`;
  el.querySelector('.name').textContent = s.label;
  el.querySelector('.from').textContent = s.playable ? s.addon : `${s.addon} — needs debrid`;
  if (s.playable) {
    el.href = s.vlc.open;
    el.addEventListener('click', () => toast('Opening in VLC…'));
  }
  return el;
}

// -------------------------------------------------------------- settings

function renderThemes(active) {
  const grid = $('#theme-grid');
  grid.innerHTML = '';
  for (const name of THEMES) {
    const probe = document.createElement('body');
    const swatch = document.createElement('button');
    swatch.className = 'swatch';
    swatch.dataset.theme = name;
    swatch.setAttribute('aria-label', name);
    swatch.setAttribute('aria-pressed', String(name === active));
    // Read the palette's accent straight from the stylesheet rather than
    // duplicating twelve hex values in here.
    probe.dataset.theme = name;
    probe.style.display = 'none';
    document.documentElement.append(probe);
    swatch.style.background = getComputedStyle(probe).getPropertyValue('--accent') || '#F5F5F5';
    probe.remove();

    swatch.addEventListener('click', async () => {
      setTheme(name);
      grid.querySelectorAll('.swatch').forEach((s) => s.setAttribute('aria-pressed', String(s === swatch)));
      await post('/api/theme', { theme: name });
    });
    grid.append(swatch);
  }
}

// ------------------------------------------------------------------ boot

async function boot() {
  const session = await api('/api/session').catch(() => ({ signedIn: false }));
  state.session = session;
  setTheme(session.theme);

  if (!session.signedIn) {
    screen('auth');
    if (!session.keyConfigured) {
      toast('NUVIO_ANON_KEY is not set on the server — sign-in will fail.', 8000);
    }
    return;
  }

  $('#settings-email').textContent = session.email || '';
  $('#settings-backend').textContent = session.backendUrl.replace(/^https?:\/\//, '');
  renderThemes(session.theme);
  await showProfiles();
}

boot();
