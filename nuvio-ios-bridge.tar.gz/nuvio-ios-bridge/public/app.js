const $ = (sel) => document.querySelector(sel);
const views = {
  login: $('#view-login'),
  browse: $('#view-browse'),
  title: $('#view-title'),
};

let catalogs = [];
let current = null; // { type, id } of the open title

function show(name) {
  for (const [key, el] of Object.entries(views)) el.hidden = key !== name;
  $('#signout').hidden = name === 'login';
  window.scrollTo(0, 0);
}

function toast(message, ms = 3200) {
  const el = $('#toast');
  el.textContent = message;
  el.hidden = false;
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => { el.hidden = true; }, ms);
}

async function api(path, options) {
  const res = await fetch(path, { credentials: 'same-origin', ...options });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

// ------------------------------------------------------------------ login

$('#login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  const button = e.target.querySelector('button');
  const error = $('#login-error');
  error.hidden = true;
  button.disabled = true;
  button.textContent = 'Signing in…';

  try {
    await api('/api/login', {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        email: form.get('email') || undefined,
        password: form.get('password') || undefined,
        authKey: form.get('authKey') || undefined,
      }),
    });
    await openBrowse();
  } catch (err) {
    error.textContent = err.message;
    error.hidden = false;
  } finally {
    button.disabled = false;
    button.textContent = 'Sign in';
  }
});

$('#signout').addEventListener('click', async () => {
  await api('/api/logout', { method: 'POST' });
  show('login');
});

// ----------------------------------------------------------------- browse

async function openBrowse() {
  show('browse');
  try {
    catalogs = await api('/api/catalogs');
  } catch (err) {
    toast(err.message);
    catalogs = [];
  }
  renderChips();
  loadContinue();
}

function renderChips() {
  const nav = $('#catalog-picker');
  nav.innerHTML = '';

  const add = (text, onClick, key) => {
    const b = document.createElement('button');
    b.className = 'chip';
    b.textContent = text;
    b.dataset.key = key;
    b.addEventListener('click', () => {
      nav.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', c === b));
      onClick();
    });
    nav.append(b);
    return b;
  };

  const first = add('Continue', loadContinue, 'continue');
  first.setAttribute('aria-pressed', 'true');

  for (const cat of catalogs.slice(0, 24)) {
    add(`${cat.name}`, () => loadCatalog(cat), `${cat.addonId}:${cat.id}`);
  }
}

async function loadContinue() {
  $('#grid-heading').textContent = 'Continue watching';
  await fill(() => api('/api/continue'), (item) => ({
    ...item,
    id: item.videoId,
    progress: item.duration ? item.timeOffset / item.duration : 0,
  }));
}

async function loadCatalog(cat) {
  $('#grid-heading').textContent = `${cat.name} · ${cat.addonName}`;
  const query = new URLSearchParams({ transportUrl: cat.transportUrl, type: cat.type, id: cat.id });
  await fill(() => api(`/api/catalog?${query}`));
}

async function fill(loader, map = (x) => x) {
  const grid = $('#grid');
  grid.innerHTML = '<p class="empty">Loading…</p>';
  try {
    const items = (await loader()).map(map);
    grid.innerHTML = '';
    if (!items.length) {
      grid.innerHTML = '<p class="empty">Nothing here yet.</p>';
      return;
    }
    for (const item of items) grid.append(card(item));
  } catch (err) {
    grid.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

function card(item) {
  const b = document.createElement('button');
  b.className = 'card';
  b.innerHTML = `
    <img loading="lazy" alt="" src="${item.poster || ''}">
    <div class="name"></div>
    ${item.progress ? `<div class="progress"><span style="width:${Math.round(item.progress * 100)}%"></span></div>` : ''}
  `;
  b.querySelector('.name').textContent = item.name || item.id;
  b.addEventListener('click', () => openTitle(item.type, item.id, item));
  return b;
}

$('#search-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const q = new FormData(e.target).get('q').trim();
  if (!q) return;
  document.activeElement?.blur();
  $('#grid-heading').textContent = `Results for “${q}”`;
  $('#catalog-picker').querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', 'false'));
  await fill(() => api(`/api/search?q=${encodeURIComponent(q)}`));
});

// ------------------------------------------------------------------ title

$('#back').addEventListener('click', () => show('browse'));

async function openTitle(type, id, hint = {}) {
  current = { type, id };
  show('title');
  $('#title-head').innerHTML = `<img alt="" src="${hint.poster || ''}"><div><h1></h1><p>Loading details…</p></div>`;
  $('#title-head h1').textContent = hint.name || id;
  $('#episodes').innerHTML = '';
  $('#streams').innerHTML = '<p class="empty">Asking your addons…</p>';

  // An episode id like tt123:1:4 already points at a video, so go straight to
  // streams. A series id needs the episode list first.
  const isEpisode = type === 'series' && id.split(':').length >= 3;
  loadStreams(type, id);

  try {
    const baseId = id.split(':')[0];
    const details = await api(`/api/meta/${encodeURIComponent(type)}/${encodeURIComponent(baseId)}`);
    $('#title-head').innerHTML = `<img alt="" src="${details.poster || hint.poster || ''}"><div><h1></h1><p></p></div>`;
    $('#title-head h1').textContent = details.name;
    $('#title-head p').textContent = [details.year, details.imdbRating && `★ ${details.imdbRating}`]
      .filter(Boolean).join(' · ');

    if (details.videos?.length) renderEpisodes(details.videos, isEpisode ? id : null);
  } catch {
    $('#title-head p').textContent = '';
  }
}

function renderEpisodes(videos, activeId) {
  const wrap = $('#episodes');
  wrap.innerHTML = '<h2 class="eyebrow">Episodes</h2>';
  const strip = document.createElement('div');
  strip.className = 'episode-picker';

  for (const v of videos) {
    const b = document.createElement('button');
    b.className = 'chip';
    b.textContent = v.season != null ? `S${v.season}E${v.episode}` : (v.title || v.id);
    b.setAttribute('aria-pressed', String(v.id === activeId));
    b.addEventListener('click', () => {
      strip.querySelectorAll('.chip').forEach((c) => c.setAttribute('aria-pressed', c === b));
      loadStreams('series', v.id);
    });
    strip.append(b);
  }
  wrap.append(strip);
}

async function loadStreams(type, id) {
  const box = $('#streams');
  box.innerHTML = '<p class="empty">Asking your addons…</p>';
  try {
    const list = await api(`/api/streams/${encodeURIComponent(type)}/${encodeURIComponent(id)}`);
    box.innerHTML = '';
    if (!list.length) {
      box.innerHTML = '<p class="empty">No addon returned a stream for this one.</p>';
      return;
    }
    for (const s of list) box.append(streamRow(s));
  } catch (err) {
    box.innerHTML = `<p class="empty">${err.message}</p>`;
  }
}

function streamRow(s) {
  const el = document.createElement(s.playable ? 'a' : 'div');
  el.className = `stream${s.playable ? '' : ' dead'}`;
  el.innerHTML = `<div class="body"><div class="label"></div><div class="source"></div></div>
                  <div class="send">${s.playable ? 'Open in VLC' : 'Torrent'}</div>`;
  el.querySelector('.label').textContent = s.label;
  el.querySelector('.source').textContent = s.playable
    ? s.addon
    : `${s.addon} — needs a debrid addon to play here`;

  if (s.playable) {
    el.href = s.vlc.open;
    el.addEventListener('click', () => toast('Handing off to VLC…'));
  }
  return el;
}

// ------------------------------------------------------------------ boot

const session = await api('/api/session').catch(() => ({ signedIn: false }));
if (session.signedIn) await openBrowse();
else show('login');
