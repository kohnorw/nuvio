#!/usr/bin/env node
/**
 * Builds config/collections.genre.json from the Xperience addon's own manifest.
 *
 * The genre catalogs are specific to your Xperience profile, so they can't be
 * hardcoded — this reads the manifest URL out of config/addons.json, asks the
 * addon what it actually offers, and writes a Genre collection with one folder
 * per genre (movies + series in each).
 *
 *   node scripts/build-genre-collection.mjs                # auto-pick catalogs
 *   node scripts/build-genre-collection.mjs --list         # just show what's there
 *   node scripts/build-genre-collection.mjs \
 *     --movie-catalog=<id> --series-catalog=<id>           # pick them yourself
 *   node scripts/build-genre-collection.mjs --genres="Action,Comedy,Horror"
 *
 * Re-run it whenever your Xperience config changes. Nothing else in the app
 * needs touching: config/layout.json already slots "Genre" between Streaming
 * and Live TV.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = process.env.CONFIG_DIR || path.join(__dirname, '..', 'config');
const OUT = path.join(CONFIG_DIR, 'collections.genre.json');

/* ------------------------------------------------------------------ args -- */

const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, ...v] = a.replace(/^--/, '').split('=');
    return [k, v.length ? v.join('=') : true];
  })
);

const die = (msg) => {
  console.error(`\n✗ ${msg}\n`);
  process.exit(1);
};

/* -------------------------------------------------------------- manifest -- */

async function xperienceManifestUrl() {
  if (typeof args['manifest'] === 'string') return args['manifest'];

  let addons;
  try {
    addons = JSON.parse(await fs.readFile(path.join(CONFIG_DIR, 'addons.json'), 'utf8'));
  } catch {
    die('Could not read config/addons.json. Pass --manifest=<url> instead.');
  }

  const hit = addons.find((a) => /xperience/i.test(`${a?.name} ${a?.url}`));
  if (!hit?.url)
    die('No Xperience addon found in config/addons.json. Pass --manifest=<url>.');
  return hit.url;
}

async function fetchManifest(url) {
  const res = await fetch(url, { headers: { accept: 'application/json' } });
  if (!res.ok) die(`Manifest fetch failed: ${res.status} ${res.statusText}`);
  return res.json();
}

/* --------------------------------------------------------------- picking -- */

const genresOf = (cat) =>
  (cat?.extra || []).find((e) => e?.name === 'genre')?.options ||
  cat?.genres ||
  [];

/**
 * A good genre source is a broad catalog that exposes a genre filter and isn't
 * scoped to one streaming service. Prefer the one offering the most genres.
 */
function pick(catalogs, type, explicitId) {
  const ofType = catalogs.filter((c) => c?.type === type);

  if (explicitId) {
    const hit = ofType.find((c) => c.id === explicitId);
    if (!hit) die(`No ${type} catalog with id "${explicitId}".`);
    return hit;
  }

  const scored = ofType
    .filter((c) => genresOf(c).length > 0)
    .map((c) => {
      let score = genresOf(c).length;
      // Service-scoped catalogs make a "Genre" row that's really a Netflix row.
      if (/^(streaming|snoak|kb)_/.test(c.id)) score -= 100;
      if (/genre/i.test(`${c.id} ${c.name}`)) score += 50;
      return { c, score };
    })
    .sort((a, b) => b.score - a.score);

  return scored[0]?.c || null;
}

/* ---------------------------------------------------------------- output -- */

const uuid = () => crypto.randomUUID();

// Matches the shape of the folders in config/collections.json: catalogSources
// with a null genre, and a mirrored `sources` array using the string "None".
function folder(genre, addonId, movieCat, seriesCat) {
  const src = (cat) =>
    cat && { addonId, type: cat.type, catalogId: cat.id, genre };
  const catalogSources = [src(movieCat), src(seriesCat)].filter(Boolean);

  return {
    id: uuid(),
    title: genre,
    hideTitle: false,
    coverImageUrl: null,
    coverEmoji: null,
    focusGifUrl: null,
    focusGifEnabled: false,
    heroBackdropUrl: null,
    heroVideoUrl: null,
    titleLogoUrl: null,
    tileShape: 'LANDSCAPE',
    catalogSources,
    sources: catalogSources.map((s) => ({ provider: 'addon', ...s })),
  };
}

/* ------------------------------------------------------------------ main -- */

const url = await xperienceManifestUrl();
const manifest = await fetchManifest(url);
const addonId = manifest.id;
const catalogs = manifest.catalogs || [];

if (args.list) {
  console.log(`\n${manifest.name} (${addonId}) — ${catalogs.length} catalogs\n`);
  for (const c of catalogs) {
    const g = genresOf(c);
    console.log(
      `  ${c.type.padEnd(6)} ${c.id.padEnd(38)} ${g.length ? `${g.length} genres` : '—'}`
    );
  }
  console.log('');
  process.exit(0);
}

const movieCat = pick(catalogs, 'movie', args['movie-catalog']);
const seriesCat = pick(catalogs, 'series', args['series-catalog']);

if (!movieCat && !seriesCat)
  die(
    'No catalog in this Xperience manifest exposes a genre filter.\n' +
      '  Run with --list to see what it does offer, then pass\n' +
      '  --movie-catalog=<id> --series-catalog=<id> explicitly.'
  );

const genres =
  typeof args.genres === 'string'
    ? args.genres.split(',').map((g) => g.trim()).filter(Boolean)
    : [...new Set([...genresOf(movieCat), ...genresOf(seriesCat)])];

if (!genres.length) die('Picked catalogs advertise no genres.');

const collection = [
  {
    id: uuid(),
    title: 'Genre',
    pinToTop: false,
    focusGlowEnabled: true,
    viewMode: 'FOLLOW_LAYOUT',
    showAllTab: true,
    backdropImageUrl: null,
    folders: genres.map((g) => folder(g, addonId, movieCat, seriesCat)),
  },
];

await fs.writeFile(OUT, JSON.stringify(collection, null, 2) + '\n');

console.log(`\n✓ Wrote ${path.relative(process.cwd(), OUT)}`);
console.log(`  addon    ${addonId}`);
console.log(`  movies   ${movieCat ? movieCat.id : '(none)'}`);
console.log(`  series   ${seriesCat ? seriesCat.id : '(none)'}`);
console.log(`  folders  ${genres.length} — ${genres.join(', ')}`);
console.log('\n  Restart the container to pick it up: docker compose restart\n');
