#!/usr/bin/env node
/**
 * Rebuilds config/collections.genre.json from the Xperience addon's manifest.
 *
 * You do NOT need to run this — a working Genres collection is committed. It's
 * here for when your Xperience config changes and new genres appear, or when
 * the addon id changes and every folder needs rebinding.
 *
 * Xperience exposes one catalog per genre per variant, named
 * `genre_<genre>_<variant>_<type>`:
 *
 *   genre_action_movies            genre_action_series
 *   genre_action_latest_movies     genre_action_latest_series
 *   genre_action_toprated_movies   genre_action_toprated_series
 *
 * This groups them by genre, one folder each, ordering the sources
 * base → latest → toprated with movies before series, which is the order the
 * committed file uses.
 *
 *   node scripts/build-genre-collection.mjs            # rebuild
 *   node scripts/build-genre-collection.mjs --list     # show what's on offer
 *   node scripts/build-genre-collection.mjs --genres="Action,Comedy"
 *   node scripts/build-genre-collection.mjs --title="Browse by Genre"
 *   node scripts/build-genre-collection.mjs --no-layout   # leave layout.json alone
 *
 * It also keeps config/layout.json in step, so the collection order can never
 * drift from the title actually written here. A hand-tuned order is preserved;
 * only stale or missing titles are touched.
 *
 * Artwork: the committed collection uses Xperience's own genre covers
 * (cdn.xperience-app.com/covers/default/genres.<slug>.webp). This script keeps
 * that convention for genres it recognises and leaves artwork null otherwise,
 * so a brand-new genre gets a plain tile until you point it at a cover.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = process.env.CONFIG_DIR || path.join(__dirname, '..', 'config');
const OUT = path.join(CONFIG_DIR, 'collections.genre.json');
const ART = 'https://cdn.xperience-app.com/covers/default';
const ART_VERSION = process.env.XPERIENCE_ART_VERSION || '7';

const args = Object.fromEntries(
  process.argv.slice(2).map((a) => {
    const [k, ...v] = a.replace(/^--/, '').split('=');
    return [k, v.length ? v.join('=') : true];
  })
);

const die = (msg) => {
  console.error(`\n✗ ${msg}\n`);
  process.exit(1);
};

/* -------------------------------------------------------------- manifest -- */

async function manifestUrl() {
  if (typeof args.manifest === 'string') return args.manifest;
  let addons;
  try {
    addons = JSON.parse(await fs.readFile(path.join(CONFIG_DIR, 'addons.json'), 'utf8'));
  } catch {
    die('Could not read config/addons.json. Pass --manifest=<url> instead.');
  }
  const hit = addons.find((a) => /xperience/i.test(`${a?.name} ${a?.url}`));
  if (!hit?.url) die('No Xperience addon in config/addons.json. Pass --manifest=<url>.');
  return hit.url;
}

/* -------------------------------------------------------------- grouping -- */

// genre_action_toprated_movies -> { genre: 'action', variant: 'toprated', type: 'movies' }
function parse(id) {
  const m = /^genre_(.+?)(?:_(latest|toprated))?_(movies|series)$/.exec(id);
  return m ? { genre: m[1], variant: m[2] || 'base', type: m[3] } : null;
}

const VARIANTS = ['base', 'latest', 'toprated'];
const TYPES = ['movies', 'series'];

/**
 * Xperience's catalog slugs don't map 1:1 to the folder names it ships with,
 * and two of them fold into another folder rather than standing alone
 * (kdrama_popular joins K-Drama; limited joins History). These aliases keep a
 * rebuild matching the committed collection. Anything not listed is titleized
 * and gets its own folder.
 */
const ALIAS = {
  scifi: 'Sci-Fi',
  thriller: 'Thrillers',
  documentary: 'Documentaries',
  animation: 'Animated',
  spy: 'Spy Thrillers',
  kdrama: 'K-Drama',
  kdrama_popular: 'K-Drama',
  limited: 'History',
  romantic_comedy: 'Romantic Comedy',
};

// The order the folders ship in. Unlisted genres are appended alphabetically.
const ORDER = [
  'Action', 'Comedy', 'Drama', 'Sci-Fi', 'Horror', 'Crime', 'Fantasy',
  'Mystery', 'Romance', 'Thrillers', 'Documentaries', 'Animated', 'Bollywood',
  'Westerns', 'Sports', 'Musicals', 'K-Drama', 'Anime', 'Spy Thrillers', 'War',
  'Adventure', 'Family', 'History', 'Romantic Comedy',
];

const titleize = (slug) =>
  ALIAS[slug] ||
  slug.split('_').map((w) => w[0].toUpperCase() + w.slice(1)).join(' ');

const uuid = () => crypto.randomUUID();

function folder(slug, title, addonId, catalogs) {
  // base → latest → toprated, movies before series within each.
  const ordered = [];
  for (const v of VARIANTS)
    for (const t of TYPES) {
      const hit = catalogs.find((c) => c.variant === v && c.type === t);
      if (hit) ordered.push(hit);
    }

  const catalogSources = ordered.map((c) => ({
    addonId,
    type: c.type === 'movies' ? 'movie' : 'series',
    catalogId: c.id,
    genre: null,
  }));

  const art = (kind) =>
    `${ART}/genres.${slug}${kind}.webp?v=${ART_VERSION}`;

  return {
    id: uuid(),
    title,
    hideTitle: true,
    coverImageUrl: art(''),
    coverEmoji: null,
    focusGifUrl: null,
    focusGifEnabled: false,
    heroBackdropUrl: art('.backdrop'),
    heroVideoUrl: null,
    titleLogoUrl: art('.logo'),
    tileShape: 'LANDSCAPE',
    catalogSources,
    // Mirrors catalogSources; Nuvio wants the string "None", not null, here.
    sources: catalogSources.map((s) => ({ provider: 'addon', ...s, genre: 'None' })),
  };
}

/* ---------------------------------------------------------------- layout -- */

// Titles the layout may legitimately name without a collection file backing
// them — Live TV is an addon-only toggle, so it never appears on disk.
const RESERVED = ['Live TV'];

async function readConfig(name, fallback) {
  try {
    return JSON.parse(await fs.readFile(path.join(CONFIG_DIR, name), 'utf8'));
  } catch {
    return fallback;
  }
}

/**
 * Keep config/layout.json in step with the collections that actually exist.
 *
 * Deliberately conservative: an order you've hand-tuned is preserved. A title
 * that's gone stale (renamed collection) is substituted in place rather than
 * left behind, and a genuinely new collection is appended so you can move it
 * where you want.
 */
async function syncLayout(genreTitle) {
  const file = path.join(CONFIG_DIR, 'layout.json');
  const layout = await readConfig('layout.json', {});
  const before = Array.isArray(layout.collectionOrder) ? layout.collectionOrder : [];

  const base = (await readConfig('collections.json', []))
    .map((c) => c?.title ?? c?.name)
    .filter(Boolean);
  const known = [...new Set([...base, genreTitle])];

  const eq = (a, b) => String(a).trim().toLowerCase() === String(b).trim().toLowerCase();
  const isKnown = (t) => known.some((k) => eq(k, t));
  const isReserved = (t) => RESERVED.some((r) => eq(r, t));

  const order = [...before];
  const missing = known.filter((k) => !order.some((t) => eq(t, k)));
  const stale = order.filter((t) => !isKnown(t) && !isReserved(t));

  const notes = [];

  // One rename in, one out — swap it in place so the position survives.
  if (missing.length === 1 && stale.length === 1) {
    order[order.findIndex((t) => eq(t, stale[0]))] = missing[0];
    notes.push(`renamed "${stale[0]}" → "${missing[0]}"`);
  } else {
    for (const t of stale) {
      order.splice(
        order.findIndex((x) => eq(x, t)),
        1
      );
      notes.push(`dropped stale "${t}"`);
    }
    for (const m of missing) {
      // New collections go ahead of the reserved tail, not after it.
      const tail = order.findIndex((t) => isReserved(t));
      if (tail === -1) order.push(m);
      else order.splice(tail, 0, m);
      notes.push(`added "${m}"`);
    }
  }

  const changed = JSON.stringify(before) !== JSON.stringify(order);
  if (changed) {
    layout.collectionOrder = order;
    await fs.writeFile(file, JSON.stringify(layout, null, 2) + '\n');
  }
  return { order, changed, notes };
}

/* ------------------------------------------------------------------ main -- */

const url = await manifestUrl();
const res = await fetch(url, { headers: { accept: 'application/json' } });
if (!res.ok) die(`Manifest fetch failed: ${res.status} ${res.statusText}`);
const manifest = await res.json();

const addonId = manifest.id;

// Keyed by folder title so aliased slugs merge into one folder.
const grouped = new Map();
for (const cat of manifest.catalogs || []) {
  const p = parse(cat.id);
  if (!p) continue;
  const title = titleize(p.genre);
  if (!grouped.has(title)) grouped.set(title, { slug: p.genre, catalogs: [] });
  grouped.get(title).catalogs.push({ id: cat.id, variant: p.variant, type: p.type });
}

if (!grouped.size)
  die(
    `No genre_* catalogs in this manifest (${manifest.catalogs?.length || 0} total).\n` +
      '  Run with --list to see what it offers.'
  );

if (args.list) {
  console.log(`\n${manifest.name} (${addonId})\n`);
  for (const [title, g] of grouped)
    console.log(`  ${title.padEnd(20)} ${g.catalogs.length} catalogs`);
  console.log('');
  process.exit(0);
}

let entries = [...grouped.entries()].sort(([a], [b]) => {
  const ia = ORDER.indexOf(a);
  const ib = ORDER.indexOf(b);
  if (ia !== -1 || ib !== -1) return (ia === -1 ? 1e6 : ia) - (ib === -1 ? 1e6 : ib);
  return a.localeCompare(b);
});

if (typeof args.genres === 'string') {
  const want = args.genres.split(',').map((g) => g.trim().toLowerCase());
  entries = entries.filter(([title]) => want.includes(title.toLowerCase()));
  if (!entries.length) die('None of the requested genres exist in the manifest.');
}

const GENRE_TITLE = typeof args.title === 'string' ? args.title : 'Genres';

const collection = [
  {
    id: uuid(),
    title: GENRE_TITLE,
    pinToTop: true,
    focusGlowEnabled: true,
    viewMode: 'FOLLOW_LAYOUT',
    showAllTab: true,
    backdropImageUrl: null,
    folders: entries.map(([title, g]) => folder(g.slug, title, addonId, g.catalogs)),
  },
];

await fs.writeFile(OUT, JSON.stringify(collection, null, 2) + '\n');

const sources = collection[0].folders.reduce((n, f) => n + f.catalogSources.length, 0);
console.log(`\n✓ Wrote ${path.relative(process.cwd(), OUT)}`);
console.log(`  addon    ${addonId}`);
console.log(`  folders  ${collection[0].folders.length}`);
console.log(`  sources  ${sources}`);
console.log(`  genres   ${collection[0].folders.map((f) => f.title).join(', ')}`);

if (args['no-layout']) {
  console.log('\n  Skipped layout.json (--no-layout).');
} else {
  const l = await syncLayout(GENRE_TITLE);
  console.log(
    `\n${l.changed ? '✓' : '·'} layout.json  ${l.order.join(' → ')}` +
      (l.notes.length ? `\n  ${l.notes.join(', ')}` : '  (already in step)')
  );
}

console.log('\n  Reload the page to pick it up.\n');
