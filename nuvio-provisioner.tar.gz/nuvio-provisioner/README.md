# Nuvio Provisioner

A self-hosted page that signs in to one or more Nuvio accounts and resets the
profiles you choose to a known-good setup.

After a push, each selected profile has **exactly** these addons and nothing else:

| Addon | Source |
| --- | --- |
| Cinemeta | Official Stremio addon |
| OpenSubtitles v3 | Official Stremio addon |
| Xperience | Your manifest URL |
| AIOStreams | Your 4K **or** 1080p build |
| Live TV (IPTV) | Only when the Live TV toggle is on |

…and these collections:

- **Streaming** (`config/collections.json`) — 17 folders (Netflix, Prime Video,
  Disney+, HBO Max, Apple TV+, Paramount+, Hulu, Peacock, Crunchyroll, MGM+,
  Discovery+, Criterion Channel, Crave, CBC Gem, Hayu, Tubi, Pluto TV).
- **Genres** (`config/collections.genre.json`) — 24 folders (Action, Comedy,
  Drama, Sci-Fi, Horror, Crime, Fantasy, Mystery, Romance, Thrillers,
  Documentaries, Animated, Bollywood, Westerns, Sports, Musicals, K-Drama,
  Anime, Spy Thrillers, War, Adventure, Family, History, Romantic Comedy),
  111 catalog sources.

- **Live TV** — only when the Live TV toggle is on. Built fresh from the
  customer's own IPTV categories, one folder each, with square tiles: open a
  category and its channels fill the grid. All folders draw on the addon's
  single channels catalog, filtered per category. Nothing to configure here;
  the addon supplies it.

Collections are pushed in the order set by `config/layout.json`:
**Streaming → Genres → Live TV**.

## Run it

```bash
cp .env.example .env                                # AIOStreams URLs
cp config/addons.example.json config/addons.json    # Xperience URL
docker compose up -d
```

Open <http://localhost:8080>. Both copied files are gitignored — see
[Secrets](#secrets).

## How it works

1. **Accounts** — sign in to each Nuvio account. Credentials are forwarded
   straight to `api.nuvio.tv` for a token and are never written to disk or
   logged. Tokens live only in the browser tab.
2. **Profiles** — every profile on every account is listed. Tick the ones to
   reset.
3. **Stream quality** — 4K or 1080p. This decides which AIOStreams build gets
   installed; only one is ever present.
4. **Live TV** — off by default. Switch it on, enter the customer's IPTV
   username and password, and use **Check login** to confirm they work. The
   push then installs the IPTV addon with a manifest link made for that login
   (see [Live TV logins](#live-tv-logins)). No collection is created; the
   channels show up under the addon's own catalog. Off, the addon is removed
   like anything else outside the bundle.
5. **Review & push** — "Preview changes" lists exactly what would be removed,
   per profile, without writing anything. "Push to selected" applies it.

## Live TV logins

Each customer has their own IPTV account at `https://tv.kohnor.ca`. They enter
the username and password on the page, and the provisioner asks the IPTV addon
for a personal manifest link:

```
POST https://redirect.kohnor.ca/api/manifest
Authorization: Bearer <API_KEY>
{ "username": "...", "password": "..." }
```

The addon checks the login with the panel and replies with the link (or a clear
error: wrong password, expired account, panel unreachable). The provisioner
then asks the addon for that customer's categories and pushes them as the
**Live TV** collection. The panel address is
fixed on the addon side by `XTREAM_URL`, so this side never handles it. The
link is then installed on every selected profile as the **Live TV** addon.

Set up:

1. On the addon: `XTREAM_URL=https://tv.kohnor.ca`, a long random `API_KEY`,
   optionally `CONFIG_SECRET` (encrypts the links so the password is not
   readable in the URL) and `PUBLIC_URL=https://redirect.kohnor.ca`.
2. Here, in `.env`: `LIVETV_API_URL=https://redirect.kohnor.ca` and
   `LIVETV_API_KEY=` the same value as the addon's `API_KEY`.

Logins are held in the browser tab and sent to this server only for the check
and the push. They are not written to disk or logged. If `LIVETV_API_URL` is not
set, the page falls back to the old behaviour: one shared `LIVETV_URL` for every
profile, no login asked for.

**The Live TV addon is only ever installed after the login is accepted by the
panel.** A wrong password, an expired account or an unreachable panel aborts
the whole push before anything is written — no addons, no collections, nothing
half-applied. Use **Check login** first to see the reason on its own.

**No Live TV collection appeared.** The addon is asked for it at
`<LIVETV_API_URL>/<token>/collection.json`. If that call fails the push still
completes (the addon is installed, the collection is skipped) and the reason is
reported: in the preview line on the page, in the push log, and in
`docker compose logs` as `[livetv] no collection: …`. The usual causes:

| Reason shown | Fix |
| --- | --- |
| `could not reach …` | `LIVETV_API_URL` is wrong, or the addon is not reachable from this container. From a LAN deployment use the addon's internal address, not the public hostname. |
| `addon has no /collection.json — it is an older build` | Update the IPTV addon and restart it. |
| `no categories found on this IPTV account` | The panel returned no live categories, or `EXCLUDE_GROUPS` on the addon filtered them all out. |

Nuvio also caches collections per profile, so after a successful push you may
need to reopen the app to see the new row.

Set `LIVETV_COLLECTION=false` to install the addon without the collection, or
`LIVETV_COLLECTION_TITLE` to rename it. If the addon is too old to offer a
collection, the push still works and installs the addon alone.

Most IPTV plans allow one or two screens at a time. Every profile that gets the
same link shares that limit.

## This is destructive by design

Nuvio's write endpoints (`sync_push_addons`, `sync_push_collections`) are
full-replace, and this tool uses that deliberately: it pushes the exact desired
set, so **anything not in the bundle is deleted**.

That means any other addon a profile had — Torrentio, Comet, a debrid addon,
anything — is removed, and any collection the user built by hand is replaced.
There is no undo.

Two guards: the preview names every addon that would be removed before you
commit, and the push asks for confirmation.

Re-running is safe and idempotent. Switching quality swaps the AIOStreams build
rather than stacking both.

## Configuration

`config/` is mounted read-only into the container. Edit on the host and
`docker compose restart` to pick up changes.

- **`config/addons.json`** (gitignored) — the fixed addon set. Copy from
  `config/addons.example.json`; Cinemeta and OpenSubtitles v3 are already
  filled in, add your Xperience URL.
- **`config/collections.json`** — the collections to apply.
- **`config/collections.genre.json`** — the Genres collection. Committed and
  ready to use; regenerate only if your Xperience config changes.
- **`config/layout.json`** — `collectionOrder`, the display order matched on
  collection title (case-insensitive). Defaults to
  `["Streaming", "Genres", "Live TV"]`. Any collection whose title isn't listed
  is appended after the named ones, keeping its file order. Maintained by
  `npm run build:genre`; edit by hand only to reorder.
- **`.env`** (gitignored) — `AIOSTREAMS_4K_URL` and `AIOSTREAMS_1080P_URL`, plus
  `LIVETV_API_URL` / `LIVETV_API_KEY` for personal Live TV logins (or a shared
  `LIVETV_URL`), and optional `LIVETV_NAME`.

A quality with no URL set shows as disabled in the UI rather than failing at
push time.

The AIOStreams URLs are read server-side and sent to Nuvio directly. They are
never included in the page source, so the tokens don't leak to the browser.

## Regenerating the Genres collection

You shouldn't need to. `config/collections.genre.json` is committed and current.

Xperience exposes one catalog per genre per variant — `genre_action_movies`,
`genre_action_latest_series`, `genre_action_toprated_movies` and so on — and the
collection groups them into a folder per genre. If your Xperience config gains
new genres, or the addon id changes and every folder needs rebinding:

```bash
npm run build:genre
```

That fetches the manifest, regroups the `genre_*` catalogs, rewrites the file,
and updates `config/layout.json` so the order can't drift from the title it just
wrote. A hand-tuned order is left alone — it only substitutes a stale title in
place (a renamed collection keeps its position), drops titles nothing backs, and
inserts a new collection ahead of `Live TV`. It prints the resulting order and
what it changed. It reproduces the committed collection exactly, including the two folders
that merge more than one slug (`kdrama_popular` joins **K-Drama**, `limited`
joins **History**) — those live in an alias table at the top of the script, so a
genuinely new genre lands as its own folder and you may want to fold it in by
hand.

```bash
node scripts/build-genre-collection.mjs --list              # genres + catalog counts
node scripts/build-genre-collection.mjs --genres="Action,Comedy"
node scripts/build-genre-collection.mjs --title="Browse by Genre"
node scripts/build-genre-collection.mjs --no-layout         # leave layout.json alone
```

`--title` renames the collection and carries the rename into `layout.json` in
the same run, which is the drift this is meant to prevent: the order list
matches on title, so a title the layout doesn't name silently sorts to the end.

Run it on the host, not inside the container — `config/` is mounted read-only
there. No restart needed; config is read fresh on every request.

To check what the server will actually push:

```bash
curl -s localhost:8080/api/collections | jq
```

That shows which files were found and the final ordered list with folder and
catalog-source counts.

## The collections depend on the addons

All 103 catalog sources in the `Streaming` collection — and all 111 in
`Genres` — are bound to the Xperience addon by id (`app.xperience.fefdfe63-…`),
which is why that exact manifest URL has to be the one installed. Swap in a
different Xperience link and the folders will render empty; re-run
`npm run build:genre` after any such swap.

## Hosting the code on GitHub

### Secrets

Two files carry credentials and are gitignored. Never commit them:

| File | Contains |
| --- | --- |
| `.env` | AIOStreams manifest URLs, which embed access tokens |
| `config/addons.json` | The Xperience manifest URL, which embeds a token |

Each has a committed `.example` counterpart with placeholders. Before your first
push, confirm the real ones are excluded:

```bash
git status --porcelain          # neither file should appear
git check-ignore -v .env config/addons.json
```

If you've already pushed either, rotate immediately — deleting a file in a later
commit does **not** remove it from history. Regenerate the Xperience manifest
link and reissue the AIOStreams configs.

`config/collections.json` has no tokens, so it's committed by default. It does
embed your Xperience addon id. If you'd rather not publish that, gitignore it
too.

### Publishing the image

`.github/workflows/docker-publish.yml` builds on every push to `main` and on
`v*` tags, then pushes to GitHub Container Registry. It needs no secrets — the
built-in `GITHUB_TOKEN` is enough. Make sure Actions has package write
permission (Settings → Actions → General → Workflow permissions).

Images land at `ghcr.io/<you>/nuvio-provisioner`. To deploy from that instead of
building locally, swap `build:` for `image:` in `docker-compose.yml`.

The image ships without your real config — mount it at runtime, as the compose
file already does, and pass the env vars.

### GitHub Pages won't work

Pages only serves static files. This is a Node server, and it needs to be: it
proxies the Nuvio API so your password isn't subject to browser CORS rules, and
it keeps your manifest URLs out of the page source. Use the container on any
host that runs Docker, or a platform like Fly, Render, or Railway that builds
from a Dockerfile.

## What this tool can't set

Player preferences — including **auto-play first source** — are device-side
settings in Nuvio. The cloud API this tool uses only exposes profiles, addons,
collections and library sync (`sync_pull_profiles`, `sync_push_addons`,
`sync_push_collections`), with no settings endpoint, and cross-device settings
sync is still an open feature request upstream. Auto-play has to be turned on
per device under Nuvio's playback settings.

## Notes

- Both addon URLs embed a token tied to one subscription. Installing them across
  several accounts means those accounts share your Xperience profile and your
  AIOStreams instance.
- Point AIOStreams at a publicly reachable hostname, not a LAN address like
  `192.168.x.x` — a LAN IP only resolves on your own network.
- Access tokens expire after roughly 60 minutes. If a push fails with an auth
  error after the page has been open a while, re-add the account.
- The container runs as the unprivileged `node` user and exposes `/healthz`.
- Not affiliated with Nuvio. Uses the documented public API at
  <https://nuvio.tv/docs>.
