# Nuvio Provisioner

A self-hosted page that signs in to one or more Nuvio accounts and applies a
fixed setup to whichever profiles you pick:

- **Xperience** addon
- **AIOStreams** addon
- **Streaming** collection — 17 folders (Netflix, Prime Video, Disney+, HBO Max,
  Apple TV+, Paramount+, Hulu, Peacock, Crunchyroll, MGM+, Discovery+, Criterion
  Channel, Crave, CBC Gem, Hayu, Tubi, Pluto TV)

## Run it

```bash
cp .env.example .env                          # add your TMDB key
cp config/addons.example.json config/addons.json   # add your manifest URLs
docker compose up -d
```

Open <http://localhost:8080>.

Both of those files are gitignored — see [Secrets](#secrets) below.

## How it works

1. **Add accounts** — sign in to each Nuvio account. Credentials are forwarded
   straight to `api.nuvio.tv` for a token and are never written to disk or logged.
   Tokens live only in the browser tab.
2. **Choose profiles** — every profile on every account is listed with a
   checkbox. Tick the ones that should receive the setup.
3. **Review and push** — "Preview changes" shows what would happen per profile
   without writing anything. "Push to selected" applies it.
4. **TMDB enrichment** — manual, see below.

## The full-replace problem

Nuvio's write endpoints (`sync_push_addons`, `sync_push_collections`) are
**full replace**. Sending just the Xperience addon would delete every other
addon on that profile.

So for each profile this tool:

- reads the current addon list
- appends anything from `config/addons.json` that isn't already there
  (matching ignores `stremio://` vs `https://` and trailing slashes)
- pushes the **complete** merged list back

Collections are merged by `id`: a bundle collection with a matching id replaces
that one, anything else is appended, and collections already on the account that
aren't in the bundle are left untouched.

Running a push twice is a no-op. Nothing is ever removed.

## Hosting the code on GitHub

### Secrets

Two files carry credentials and are gitignored. Never commit them:

| File | Contains |
| --- | --- |
| `.env` | Your TMDB API key |
| `config/addons.json` | Manifest URLs with embedded subscription tokens |

Each has a committed `.example` counterpart with placeholders. Before your first
push, confirm the real ones are excluded:

```bash
git status --porcelain          # neither file should appear
git check-ignore -v .env config/addons.json
```

If you've already pushed either file, rotate immediately — deleting the file in
a later commit does **not** remove it from history. Regenerate the Xperience
manifest link, reissue the AIOStreams config, and create a new TMDB key.

`config/collections.json` has no tokens, so it's committed by default. It does
embed your Xperience addon id (`app.xperience.<uuid>`). If you'd rather not
publish that, add it to `.gitignore` too and ship an example instead.

### Publishing the image

`.github/workflows/docker-publish.yml` builds on every push to `main` and on
`v*` tags, then pushes to GitHub Container Registry. It needs no secrets — the
built-in `GITHUB_TOKEN` is enough. Just make sure Actions has package write
permission (Settings → Actions → General → Workflow permissions).

Images land at `ghcr.io/<you>/nuvio-provisioner`. To deploy from that instead of
building locally, swap `build:` for `image:` in `docker-compose.yml`.

The image deliberately ships without your real config — mount it at runtime, as
the compose file already does.

### GitHub Pages won't work

Pages only serves static files. This is a Node server, and it needs to be:
it proxies the Nuvio API so your password isn't subject to browser CORS rules,
and it keeps the TMDB key server-side. Use the container on any host that runs
Docker, or a platform like Fly, Render, or Railway that builds from a Dockerfile.

## Configuration

`config/` is mounted read-only into the container. Edit on the host and
`docker compose restart` to pick up changes.

- **`config/addons.json`** — addons to install (gitignored). Copy from
  `config/addons.example.json` and paste your real manifest URLs.
- **`config/collections.json`** — the collections to apply. Holds the
  `Streaming` collection and its 17 folders.
- **`.env`** — `TMDB_API_KEY`.

## TMDB enrichment is manual

There is no API for this. Nuvio stores integration settings in local device
storage (MMKV) rather than in your cloud account — this is also why the
community account-cloning tools don't copy settings. Nothing this page does can
set it remotely.

Step 4 of the page verifies the key against TMDB's API so you know it's valid,
then gives you a copy button and the exact path:
**Settings → Integrations → TMDB Enrichment**, toggle on, paste, save.

That has to be done once per device, per account.

## The collections depend on the addons

All 103 catalog sources in the `Streaming` collection are bound to the Xperience
addon by id (`app.xperience.fefdfe63-…`), which is why that exact manifest URL
has to be the one installed. If you push collections to a profile without
installing the addons, you get 17 empty folders — the page warns before letting
you do that.

## Shared credentials

Both addon URLs embed a token tied to one subscription. Installing them across
several accounts means those accounts all share your Xperience profile and your
AIOStreams instance. That's usually the intent for a household; it's worth
knowing if you're setting up people outside it.

The AIOStreams addon is pointed at `https://aio.kohnor.ca/…`, not the
`192.168.1.193:3000` LAN address — the LAN IP only resolves on your own network,
so it would break for every device outside it.

## Notes

- Access tokens expire after roughly 60 minutes. If a push fails with an auth
  error after the page has been open a while, re-add the account.
- The container runs as the unprivileged `node` user and exposes `/healthz`.
- Not affiliated with Nuvio. Uses the documented public API at
  <https://nuvio.tv/docs>.
