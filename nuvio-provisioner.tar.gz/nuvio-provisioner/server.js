import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  signIn,
  getProfiles,
  getAddons,
  getCollections,
  pushAddons,
  pushCollections,
  mergeAddons,
  mergeCollections,
} from './lib/nuvio.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_DIR = process.env.CONFIG_DIR || path.join(__dirname, 'config');
const PORT = process.env.PORT || 8080;

const app = express();
app.use(express.json({ limit: '10mb' }));
app.disable('x-powered-by');

/* ---------------------------------------------------------------- bundle -- */

async function readJson(file, fallback) {
  try {
    return JSON.parse(await fs.readFile(path.join(CONFIG_DIR, file), 'utf8'));
  } catch (e) {
    if (e.code === 'ENOENT') return fallback;
    throw new Error(`${file} is not valid JSON: ${e.message}`);
  }
}

async function exists(file) {
  try {
    await fs.access(path.join(CONFIG_DIR, file));
    return true;
  } catch {
    return false;
  }
}

async function loadBundle() {
  const addons = await readJson('addons.json', []);
  const collections = await readJson('collections.json', []);
  return {
    addons: Array.isArray(addons) ? addons : [],
    collections: Array.isArray(collections) ? collections : [],
    tmdbKey: process.env.TMDB_API_KEY || '',
    // addons.json is gitignored, so a fresh clone won't have it yet.
    addonsFilePresent: await exists('addons.json'),
  };
}

app.get('/api/bundle', async (req, res) => {
  try {
    const b = await loadBundle();
    res.json({
      addons: b.addons,
      collections: b.collections.map((c) => ({
        id: c?.id ?? null,
        name: c?.title ?? c?.name ?? '(unnamed)',
        folders: Array.isArray(c?.folders) ? c.folders.length : 0,
      })),
      collectionsCount: b.collections.length,
      addonsFilePresent: b.addonsFilePresent,
      tmdbConfigured: Boolean(b.tmdbKey),
      tmdbKeyMasked: b.tmdbKey
        ? `${b.tmdbKey.slice(0, 4)}…${b.tmdbKey.slice(-4)}`
        : null,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// The UI needs the real key once, to show/copy during the manual step.
app.get('/api/tmdb-key', async (req, res) => {
  res.json({ key: process.env.TMDB_API_KEY || '' });
});

// Verifies the key actually works before we tell anyone to type it in.
app.get('/api/tmdb-verify', async (req, res) => {
  const key = process.env.TMDB_API_KEY;
  if (!key) return res.json({ ok: false, reason: 'No TMDB_API_KEY set.' });
  try {
    const r = await fetch(
      `https://api.themoviedb.org/3/configuration?api_key=${encodeURIComponent(key)}`
    );
    if (r.ok) return res.json({ ok: true });
    const body = await r.json().catch(() => ({}));
    res.json({
      ok: false,
      reason: body?.status_message || `TMDB returned ${r.status}`,
    });
  } catch (e) {
    res.json({ ok: false, reason: e.message });
  }
});

/* ------------------------------------------------------------------ auth -- */

app.post('/api/signin', async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password)
    return res.status(400).json({ error: 'Enter an email and password.' });
  try {
    const session = await signIn(email, password);
    const profiles = await getProfiles(session.accessToken);
    res.json({
      accessToken: session.accessToken,
      email: session.email,
      profiles,
    });
  } catch (e) {
    res
      .status(e.status === 400 ? 401 : e.status || 500)
      .json({ error: e.message });
  }
});

/* --------------------------------------------------------------- preview -- */

app.post('/api/preview', async (req, res) => {
  const { accessToken, profileId } = req.body || {};
  try {
    const bundle = await loadBundle();
    const [existingAddons, existingCollections] = await Promise.all([
      getAddons(accessToken, profileId),
      getCollections(accessToken, profileId),
    ]);
    const a = mergeAddons(existingAddons, bundle.addons);
    const c = mergeCollections(existingCollections, bundle.collections);
    res.json({
      existingAddons: existingAddons.length,
      existingCollections: existingCollections.length,
      addonsToAdd: a.added,
      addonsAlreadyPresent: a.alreadyPresent,
      collectionsToAdd: c.added,
      collectionsToReplace: c.replaced,
      finalAddonCount: a.addons.length,
      finalCollectionCount: c.collections.length,
    });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message });
  }
});

/* ----------------------------------------------------------------- apply -- */

app.post('/api/apply', async (req, res) => {
  const {
    accessToken,
    profileId,
    applyAddons = true,
    applyCollections = true,
  } = req.body || {};

  const log = [];
  try {
    const bundle = await loadBundle();

    if (applyAddons && bundle.addons.length) {
      const existing = await getAddons(accessToken, profileId);
      const { addons, added, alreadyPresent } = mergeAddons(
        existing,
        bundle.addons
      );
      if (added.length) {
        // Full-replace RPC: `addons` is the complete post-merge list.
        await pushAddons(accessToken, profileId, addons);
        log.push(`Installed ${added.length} addon(s): ${added.join(', ')}`);
      }
      if (alreadyPresent.length)
        log.push(`Already installed: ${alreadyPresent.join(', ')}`);
    }

    if (applyCollections && bundle.collections.length) {
      const existing = await getCollections(accessToken, profileId);
      const { collections, added, replaced } = mergeCollections(
        existing,
        bundle.collections
      );
      // Full-replace RPC: `collections` includes everything already there.
      await pushCollections(accessToken, profileId, collections);
      if (added.length) log.push(`Added ${added.length} collection(s)`);
      if (replaced.length)
        log.push(`Updated ${replaced.length} existing collection(s)`);
      if (!added.length && !replaced.length)
        log.push('Collections already up to date');
    }

    if (!log.length) log.push('Nothing to change — already set up');
    res.json({ ok: true, log });
  } catch (e) {
    res.status(e.status || 500).json({ error: e.message, log });
  }
});

/* ---------------------------------------------------------------- static -- */

app.use(express.static(path.join(__dirname, 'public')));
app.get('/healthz', (_req, res) => res.send('ok'));

app.listen(PORT, '0.0.0.0', () =>
  console.log(`Nuvio provisioner listening on http://localhost:${PORT}`)
);
