const $ = (id) => document.getElementById(id);
const accounts = []; // { email, accessToken, profiles:[{profileId,name,selected,status,statusKind}] }

async function post(url, body) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `Request failed (${r.status})`);
  return data;
}

/* --------------------------------------------------------------- progress -- */

function setProgress(n) {
  [...$('dots').children].forEach((li, i) => li.classList.toggle('on', i <= n));
}

$('heroCta').addEventListener('click', () => {
  $('email').focus({ preventScroll: true });
  $('step-accounts').scrollIntoView({ behavior: 'smooth', block: 'start' });
});

/* ----------------------------------------------------------------- bundle -- */

let bundle = null;

async function loadBundle() {
  try {
    bundle = await (await fetch('/api/bundle')).json();

    if (!bundle.addonsFilePresent) {
      $('bundleSummary').textContent =
        'No addons configured yet. Copy config/addons.example.json to ' +
        'config/addons.json, add your manifest URLs, then restart.';
      $('bundleSummary').classList.add('warn');
      return;
    }

    const folders = bundle.collections.reduce((n, c) => n + (c.folders || 0), 0);
    const addons = bundle.addons.map((a) => a.name).join(' and ') || 'no addons';
    const colls = bundle.collections.length
      ? `${bundle.collections.map((c) => c.name).join(', ')} (${folders} folders)`
      : 'no collections';
    $('bundleSummary').textContent =
      `Installs ${addons}, plus ${colls}, on whichever profiles you choose.`;
    if (!bundle.collectionsCount)
      $('bundleSummary').textContent += ' config/collections.json is empty.';
  } catch {
    $('bundleSummary').textContent = 'Could not read the bundle config.';
  }
}

/* ------------------------------------------------------------------- auth -- */

$('signinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = $('signinBtn');
  const err = $('signinError');
  err.hidden = true;
  btn.disabled = true;
  btn.textContent = 'Signing in…';

  try {
    const email = $('email').value.trim();
    if (accounts.some((a) => a.email.toLowerCase() === email.toLowerCase()))
      throw new Error('That account is already added.');

    const r = await post('/api/signin', { email, password: $('password').value });
    accounts.push({
      email: r.email || email,
      accessToken: r.accessToken,
      profiles: r.profiles.map((p) => ({ ...p, selected: true, status: null })),
    });
    $('email').value = '';
    $('password').value = '';
    render();
    setProgress(1);
  } catch (e2) {
    err.textContent = e2.message;
    err.hidden = false;
  } finally {
    btn.disabled = false;
    btn.textContent = 'Add account';
  }
});

/* ------------------------------------------------------------------ board -- */

const CHECK =
  '<svg viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">' +
  '<path d="M1.5 6.3 4.4 9.2 10.5 3" stroke="#000" stroke-width="2.2" ' +
  'stroke-linecap="round" stroke-linejoin="round"/></svg>';

function render() {
  const board = $('board');
  board.innerHTML = '';

  accounts.forEach((acct, ai) => {
    const card = document.createElement('div');
    card.className = 'acct';

    const head = document.createElement('div');
    head.className = 'acct-head';

    const av = document.createElement('span');
    av.className = 'avatar';
    av.textContent = (acct.email[0] || '?').toUpperCase();

    const em = document.createElement('span');
    em.className = 'acct-email';
    em.textContent = acct.email;

    const ct = document.createElement('span');
    ct.className = 'acct-count';
    ct.textContent = `${acct.profiles.length} profile${acct.profiles.length === 1 ? '' : 's'}`;

    head.append(av, em, ct);
    card.appendChild(head);

    const grid = document.createElement('div');
    grid.className = 'profs';

    acct.profiles.forEach((p, pi) => {
      const tile = document.createElement('label');
      tile.className = 'prof' + (p.selected ? ' sel' : '');

      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.checked = p.selected;
      cb.addEventListener('change', () => {
        p.selected = cb.checked;
        tile.classList.toggle('sel', cb.checked);
      });

      const tick = document.createElement('span');
      tick.className = 'tick';
      tick.innerHTML = CHECK;

      const name = document.createElement('span');
      name.className = 'prof-name';
      name.textContent = p.name;

      const badge = document.createElement('span');
      badge.className = 'badge' + (p.statusKind ? ' ' + p.statusKind : '');
      badge.textContent = p.status || '';
      badge.id = `st-${ai}-${pi}`;
      badge.title = p.status || '';

      tile.append(cb, tick, name, badge);
      grid.appendChild(tile);
    });

    card.appendChild(grid);
    board.appendChild(card);
  });

  $('step-targets').hidden = accounts.length === 0;
  $('step-apply').hidden = accounts.length === 0;
}

function setStatus(ai, pi, text, kind) {
  const p = accounts[ai].profiles[pi];
  p.status = text;
  p.statusKind = kind;
  const el = $(`st-${ai}-${pi}`);
  if (el) {
    el.textContent = text;
    el.title = text;
    el.className = 'badge' + (kind ? ' ' + kind : '');
  }
}

function selectedTargets() {
  const out = [];
  accounts.forEach((a, ai) =>
    a.profiles.forEach((p, pi) => {
      if (p.selected) out.push({ ai, pi, acct: a, prof: p });
    })
  );
  return out;
}

/* ----------------------------------------------------------- preview/push -- */

async function runAcross(fn, label) {
  const targets = selectedTargets();
  const err = $('applyError');
  err.hidden = true;

  if (!targets.length) {
    err.textContent = 'Select at least one profile.';
    err.hidden = false;
    return;
  }

  // Every catalog source in the bundled collections is served by a bundled
  // addon. Pushing collections alone leaves the folders empty.
  if ($('optCollections').checked && !$('optAddons').checked) {
    const go = confirm(
      'The collections pull their catalogs from the bundled addons.\n\n' +
        'Pushing collections without addons will create empty folders on any ' +
        'profile that does not already have those addons installed.\n\n' +
        'Push anyway?'
    );
    if (!go) return;
  }

  $('previewBtn').disabled = true;
  $('applyBtn').disabled = true;
  setProgress(2);

  // Sequential: keeps the board readable and avoids hammering the API.
  for (const t of targets) {
    setStatus(t.ai, t.pi, label, 'run');
    try {
      await fn(t);
    } catch (e) {
      setStatus(t.ai, t.pi, e.message, 'err');
    }
  }

  $('previewBtn').disabled = false;
  $('applyBtn').disabled = false;
}

$('previewBtn').addEventListener('click', () =>
  runAcross(async (t) => {
    const r = await post('/api/preview', {
      accessToken: t.acct.accessToken,
      profileId: t.prof.profileId,
    });
    const bits = [];
    if (r.addonsToAdd.length) bits.push(`+${r.addonsToAdd.length} addon`);
    if (r.collectionsToAdd.length) bits.push(`+${r.collectionsToAdd.length} coll`);
    if (r.collectionsToReplace.length) bits.push(`~${r.collectionsToReplace.length} coll`);
    setStatus(t.ai, t.pi, bits.length ? bits.join(' · ') : 'no changes needed', 'info');
  }, 'reading…')
);

$('applyBtn').addEventListener('click', () =>
  runAcross(async (t) => {
    const r = await post('/api/apply', {
      accessToken: t.acct.accessToken,
      profileId: t.prof.profileId,
      applyAddons: $('optAddons').checked,
      applyCollections: $('optCollections').checked,
    });
    setStatus(t.ai, t.pi, r.log.join(' · '), 'ok');
    setProgress(3);
  }, 'pushing…')
);

/* ------------------------------------------------------------------- tmdb -- */

let revealed = false;
let realKey = '';

async function key() {
  if (!realKey) realKey = (await (await fetch('/api/tmdb-key')).json()).key || '';
  return realKey;
}

$('revealBtn').addEventListener('click', async () => {
  const k = await key();
  if (!k) {
    $('tmdbKey').textContent = 'TMDB_API_KEY not set';
    return;
  }
  revealed = !revealed;
  $('tmdbKey').textContent = revealed ? k : '••••••••';
  $('revealBtn').textContent = revealed ? 'Hide' : 'Reveal';
});

$('copyBtn').addEventListener('click', async () => {
  const k = await key();
  if (!k) return;
  await navigator.clipboard.writeText(k);
  $('copyBtn').textContent = 'Copied';
  setTimeout(() => ($('copyBtn').textContent = 'Copy'), 1400);
});

(async () => {
  await loadBundle();
  try {
    const v = await (await fetch('/api/tmdb-verify')).json();
    const el = $('tmdbStatus');
    el.textContent = v.ok ? 'key verified' : v.reason;
    el.className = 'badge ' + (v.ok ? 'ok' : 'err');
  } catch {
    $('tmdbStatus').textContent = '';
  }
})();
